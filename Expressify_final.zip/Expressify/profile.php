<?php
require 'session.php';
require 'config.php';
require 'theme.php';

$user_id = $_SESSION['user_id'];
$message = '';

// Get unread notifications count
$stmt = $conn->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$unread_count = $stmt->get_result()->fetch_assoc()['count'];

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_profile'])) {
        $username = trim($_POST['username']);
        $bio = trim($_POST['bio']);
        $email = trim($_POST['email']);
        
        // Handle profile picture upload
        if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === 0) {
            $allowed = ['jpg', 'jpeg', 'png', 'gif'];
            $filename = $_FILES['profile_picture']['name'];
            $filetype = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
            
            if (in_array($filetype, $allowed)) {
                $temp_name = $_FILES['profile_picture']['tmp_name'];
                $new_filename = "profile_" . $user_id . "." . $filetype;
                $upload_path = "uploads/profiles/";
                
                // Create directory if it doesn't exist
                if (!file_exists($upload_path)) {
                    mkdir($upload_path, 0777, true);
                }
                
                if (move_uploaded_file($temp_name, $upload_path . $new_filename)) {
                    $profile_picture = $upload_path . $new_filename;
                    
                    // Delete old profile picture if it exists
                    $stmt = $conn->prepare("SELECT profile_picture FROM users WHERE id = ?");
                    $stmt->bind_param("i", $user_id);
                    $stmt->execute();
                    $old_picture = $stmt->get_result()->fetch_assoc()['profile_picture'];
                    
                    if ($old_picture && file_exists($old_picture) && $old_picture != 'assets/default-avatar.png') {
                        unlink($old_picture);
                    }
                    
                    // Update profile picture in database
                    $stmt = $conn->prepare("UPDATE users SET profile_picture = ? WHERE id = ?");
                    $stmt->bind_param("si", $profile_picture, $user_id);
                    $stmt->execute();
                }
            } else {
                $message = '<div class="alert error">Invalid file type. Please upload JPG, JPEG, PNG, or GIF.</div>';
                goto skip_profile_update;
            }
        }
        
        // Update profile information
        $stmt = $conn->prepare("UPDATE users SET username = ?, bio = ?, email = ? WHERE id = ?");
        $stmt->bind_param("sssi", $username, $bio, $email, $user_id);
        
        if ($stmt->execute()) {
            $message = '<div class="alert success">Profile updated successfully!</div>';
        } else {
            $message = '<div class="alert error">Failed to update profile.</div>';
        }
        
        skip_profile_update:
    }
}

// Get user information
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// Get user's posts with media, like counts and comment counts
$stmt = $conn->prepare("
    SELECT 
        posts.*,
        users.username,
        users.profile_picture,
        media.file_path,
        media.file_type,
        COUNT(DISTINCT likes.id) as like_count,
        COUNT(DISTINCT comments.id) as comment_count,
        MAX(CASE WHEN likes.user_id = ? THEN 1 ELSE 0 END) as user_liked
    FROM posts 
    JOIN users ON posts.user_id = users.id
    LEFT JOIN media ON posts.media_id = media.id
    LEFT JOIN likes ON posts.id = likes.post_id
    LEFT JOIN comments ON posts.id = comments.post_id
    WHERE posts.user_id = ?
    GROUP BY posts.id
    ORDER BY posts.created_at DESC
");
$stmt->bind_param("ii", $user_id, $user_id);
$stmt->execute();
$posts_result = $stmt->get_result();

// Get posts count
$stmt = $conn->prepare("SELECT COUNT(*) as posts_count FROM posts WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$posts_result_count = $stmt->get_result();
$posts_count = $posts_result_count->fetch_assoc()['posts_count'];

// Get friend count
$friendCountQuery = "SELECT COUNT(*) as friend_count 
                    FROM friend_requests 
                    WHERE (sender_id = ? OR receiver_id = ?) 
                    AND status = 'accepted'";
$friendStmt = $conn->prepare($friendCountQuery);
$friendStmt->bind_param("ii", $user_id, $user_id);
$friendStmt->execute();
$friendResult = $friendStmt->get_result();
$friendCount = $friendResult->fetch_assoc()['friend_count'];

// Get mutual friends count if viewing another user's profile
$mutualFriendsCount = 0;
if ($user_id !== $_SESSION['user_id']) {
    $mutualQuery = "SELECT COUNT(*) as mutual_count
                   FROM (
                       SELECT IF(sender_id = ?, receiver_id, sender_id) as friend_id
                       FROM friend_requests
                       WHERE status = 'accepted' AND (sender_id = ? OR receiver_id = ?)
                   ) AS my_friends
                   JOIN (
                       SELECT IF(sender_id = ?, receiver_id, sender_id) as friend_id
                       FROM friend_requests
                       WHERE status = 'accepted' AND (sender_id = ? OR receiver_id = ?)
                   ) AS their_friends
                   ON my_friends.friend_id = their_friends.friend_id";
    $mutualStmt = $conn->prepare($mutualQuery);
    $mutualStmt->bind_param("iiiiii", 
        $_SESSION['user_id'], $_SESSION['user_id'], $_SESSION['user_id'],
        $user_id, $user_id, $user_id
    );
    $mutualStmt->execute();
    $mutualResult = $mutualStmt->get_result();
    $mutualFriendsCount = $mutualResult->fetch_assoc()['mutual_count'];
}
?>
<!DOCTYPE html>
<html data-theme="<?php echo htmlspecialchars($current_theme); ?>">
<head>
    <title>Profile - Expressify</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
<div class="container">
    <nav class="navbar">
        <div class="nav-brand">
            <h2>Expressify</h2>
        </div>
        <div class="nav-links">
            <a href="home.php" class="nav-item"><i class="fas fa-home"></i> Home</a>
            <a href="posts.php" class="nav-item"><i class="fas fa-pen"></i> Create Post</a>
            <a href="explore.php" class="nav-item"><i class="fas fa-compass"></i> Explore</a>
            <a href="notifications.php" class="nav-item" style="position: relative;">
                <i class="fas fa-bell"></i> Notifications
                <?php if ($unread_count > 0): ?>
                    <span class="notification-badge"><?php echo $unread_count; ?></span>
                <?php endif; ?>
            </a>
            <a href="profile.php" class="nav-item active"><i class="fas fa-user"></i> My Profile</a>
            <a href="friends.php" class="nav-item"><i class="fas fa-users"></i> Friends</a>
            <a href="settings.php" class="nav-item"><i class="fas fa-cog"></i> Settings</a>
            <a href="logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
        <div class="nav-toggle">
            <i class="fas fa-bars"></i>
        </div>
    </nav>

    <div class="content">
        <div class="profile-container">
            <?php echo $message; ?>
            
            <div class="profile-header">
                <div class="profile-left">
                    <div class="profile-picture-container">
                        <div class="profile-picture">
                            <img src="<?php echo !empty($user['profile_picture']) ? htmlspecialchars($user['profile_picture']) : 'assets/default-avatar.png'; ?>" 
                                 alt="Profile Picture" id="profilePreview">
                        </div>
                    </div>
                    
                    <div class="profile-stats">
                        <div class="stat-item">
                            <span class="stat-value"><?php echo $posts_count; ?></span>
                            <span class="stat-label">Posts</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-value"><?php echo $friendCount; ?></span>
                            <span class="stat-label">Friends</span>
                        </div>
                        <?php if ($user_id !== $_SESSION['user_id']): ?>
                        <div class="stat-item">
                            <span class="stat-value"><?php echo $mutualFriendsCount; ?></span>
                            <span class="stat-label">Mutual Friends</span>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="profile-right">
                    <div class="profile-details">
                        <h3><i class="fas fa-user-circle"></i> Profile Details</h3>
                        <div class="details-content">
                            <div class="detail-item">
                                <span class="detail-label"><i class="fas fa-user"></i> Username</span>
                                <span class="detail-value"><?php echo htmlspecialchars($user['username']); ?></span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label"><i class="fas fa-envelope"></i> Email</span>
                                <span class="detail-value"><?php echo htmlspecialchars($user['email']); ?></span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label"><i class="fas fa-info-circle"></i> Bio</span>
                                <div class="detail-value bio-text"><?php echo !empty($user['bio']) ? nl2br(htmlspecialchars($user['bio'])) : '<em>No bio added yet</em>'; ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Add this button in the profile header section, after the user info -->
            <?php if ($user_id !== $_SESSION['user_id']): ?>
                <button onclick="submitReport('profile', null, <?php echo $user_id; ?>)" 
                        class="btn-report" title="Report User">
                    <i class="fas fa-flag"></i> Report User
                </button>
            <?php endif; ?>

            <div class="user-posts">
                <h3><i class="fas fa-pencil-alt"></i> My Posts</h3>
                <div class="posts-grid">
                    <?php if ($posts_result->num_rows > 0): ?>
                        <?php while ($post = $posts_result->fetch_assoc()): ?>
                            <div class="post" data-post-id="<?php echo $post['id']; ?>">
                                <div class="post-header">
                                    <div class="post-user">
                                        <img src="<?php echo !empty($post['profile_picture']) ? htmlspecialchars($post['profile_picture']) : 'assets/default-avatar.png'; ?>" 
                                             alt="Profile Picture" class="post-avatar">
                                        <div class="post-info">
                                            <span class="username"><?php echo htmlspecialchars($post['username']); ?></span>
                                            <span class="post-date"><?php echo date('M d, Y', strtotime($post['created_at'])); ?></span>
                                        </div>
                                    </div>
                                    <button class="delete-post-btn" data-post-id="<?php echo $post['id']; ?>">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>

                                <div class="post-content">
                                    <p><?php echo nl2br(htmlspecialchars($post['content'])); ?></p>
                                    <?php if (!empty($post['file_path'])): ?>
                                        <div class="post-media">
                                            <?php if (strpos($post['file_type'], 'image/') !== false || in_array($post['file_type'], ['jpg', 'jpeg', 'png', 'gif'])): ?>
                                                <img src="<?php echo htmlspecialchars($post['file_path']); ?>" alt="Post image" class="post-image">
                                            <?php elseif (strpos($post['file_type'], 'video/') !== false || in_array($post['file_type'], ['mp4', 'mov'])): ?>
                                                <video controls class="post-video">
                                                    <source src="<?php echo htmlspecialchars($post['file_path']); ?>" type="video/<?php echo $post['file_type']; ?>">
                                                    Your browser does not support the video tag.
                                                </video>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <div class="post-actions">
                                    <button class="action-btn like-btn <?php echo $post['user_liked'] ? 'liked' : ''; ?>" 
                                            data-post-id="<?php echo $post['id']; ?>"
                                            data-liked="<?php echo $post['user_liked']; ?>">
                                        <i class="<?php echo $post['user_liked'] ? 'fas' : 'far'; ?> fa-heart"></i>
                                        <span class="like-count"><?php echo $post['like_count']; ?></span>
                                    </button>
                                    <button class="action-btn comment-btn" data-post-id="<?php echo $post['id']; ?>">
                                        <i class="far fa-comment"></i>
                                        <span class="comment-count"><?php echo $post['comment_count']; ?></span>
                                    </button>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="no-posts">
                            <i class="fas fa-pencil-alt"></i>
                            <p>No posts yet</p>
                            <a href="posts.php" class="create-post-btn">Create your first post</a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="profile-edit">
                <h3><i class="fas fa-edit"></i> Edit Profile</h3>
                <form method="POST" class="edit-form" enctype="multipart/form-data">
                    <div class="form-group profile-picture-edit">
                        <label>Profile Picture</label>
                        <div class="picture-preview">
                            <img src="<?php echo !empty($user['profile_picture']) ? htmlspecialchars($user['profile_picture']) : 'assets/default-avatar.png'; ?>" 
                                 alt="Profile Picture Preview" id="picturePreview">
                            <div class="picture-overlay">
                                <label for="profile_picture" class="upload-btn">
                                    <i class="fas fa-camera"></i>
                                    <span>Change Picture</span>
                                </label>
                            </div>
                        </div>
                        <input type="file" id="profile_picture" name="profile_picture" accept="image/*" style="display: none;">
                        <small class="form-text">Allowed formats: JPG, JPEG, PNG, GIF. Max size: 5MB</small>
                    </div>

                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="bio">Bio</label>
                        <textarea id="bio" name="bio" rows="4"><?php echo htmlspecialchars($user['bio']); ?></textarea>
                    </div>
                    
                    <button type="submit" name="update_profile" class="save-button">
                        <i class="fas fa-save"></i> Save Changes
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<style>
/* Update profile header layout */
.profile-header {
    display: grid;
    grid-template-columns: minmax(200px, 300px) 1fr;
    gap: 30px;
    margin-bottom: 30px;
    padding: 20px;
    background: var(--bg-secondary);
    border-radius: 8px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.profile-left {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.profile-picture-container {
    width: 100%;
}

.profile-picture {
    position: relative;
    width: 100%;
    padding-bottom: 100%;
    border-radius: 8px;
    overflow: hidden;
}

.profile-picture img {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: 8px;
}

.profile-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
    gap: 10px;
    padding: 15px;
    background: var(--bg-primary);
    border-radius: 8px;
}

.stat {
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
    gap: 5px;
}

.stat i {
    font-size: 1.2em;
    color: var(--primary-color);
}

.profile-right {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.profile-details {
    height: 100%;
    padding: 0;
    margin: 0;
    box-shadow: none;
    background: none;
}

.details-content {
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    gap: 20px;
}

.detail-item {
    background: var(--bg-primary);
    padding: 15px;
    border-radius: 8px;
    transition: transform 0.2s;
}

.detail-item:hover {
    transform: translateX(5px);
}

.detail-value {
    font-size: 1.2em;
    padding: 5px 0;
    background: none;
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .profile-header {
        grid-template-columns: 1fr;
    }

    .profile-picture-container {
        max-width: 300px;
        margin: 0 auto;
    }

    .profile-stats {
        max-width: 300px;
        margin: 0 auto;
    }
}

.profile-details {
    background: var(--bg-secondary);
    border-radius: 8px;
    padding: 20px;
    margin: 20px 0;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.profile-details h3 {
    color: var(--text-primary);
    margin-bottom: 20px;
    display: flex;
    align-items: center;
    gap: 10px;
}

.details-content {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.detail-item {
    display: flex;
    flex-direction: column;
    gap: 5px;
}

.detail-label {
    color: var(--text-secondary);
    font-size: 0.9em;
    display: flex;
    align-items: center;
    gap: 8px;
}

.bio-text {
    white-space: pre-line;
    line-height: 1.4;
    min-height: 60px;
}

.bio-text em {
    color: var(--text-secondary);
}

.profile-edit h3 {
    display: flex;
    align-items: center;
    gap: 10px;
}

.alert {
    padding: 15px;
    border-radius: 4px;
    margin-bottom: 20px;
    animation: slideDown 0.3s ease-out;
}

.alert.success {
    background-color: var(--success-bg);
    color: var(--success-text);
    border: 1px solid var(--success-border);
}

.alert.error {
    background-color: var(--error-bg);
    color: var(--error-text);
    border: 1px solid var(--error-border);
}

@keyframes slideDown {
    from {
        transform: translateY(-20px);
        opacity: 0;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
}

/* Update existing styles */
.profile-container {
    max-width: 800px;
    margin: 0 auto;
}

.form-group {
    margin-bottom: 20px;
}

.form-group label {
    display: block;
    margin-bottom: 8px;
    color: var(--text-secondary);
}

.form-group input,
.form-group textarea {
    width: 100%;
    padding: 10px;
    border: 1px solid var(--border-color);
    border-radius: 4px;
    background: var(--bg-primary);
    color: var(--text-primary);
    transition: border-color 0.3s;
}

.form-group input:focus,
.form-group textarea:focus {
    border-color: var(--primary-color);
    outline: none;
}

.save-button {
    background: linear-gradient(45deg, var(--primary-color), var(--primary-color-light));
    color: white;
    border: none;
    padding: 12px 24px;
    border-radius: 8px;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    font-size: 1.1em;
    font-weight: 600;
    width: 100%;
    max-width: 200px;
    margin: 20px auto 0;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
}

.save-button:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
    background: linear-gradient(45deg, var(--primary-color-light), var(--primary-color));
}

.save-button:active {
    transform: translateY(1px);
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
}

.save-button i {
    font-size: 1.2em;
    transition: transform 0.3s ease;
}

.save-button:hover i {
    transform: rotate(10deg);
}

.save-button::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(
        to right,
        transparent,
        rgba(255, 255, 255, 0.2),
        transparent
    );
    transition: left 0.7s ease;
}

.save-button:hover::before {
    left: 100%;
}

@media (max-width: 768px) {
    .save-button {
        max-width: 100%;
        padding: 15px 24px;
        font-size: 1em;
    }
}

/* Add CSS variables if they don't exist */
:root {
    --primary-color-light: #4a90e2;
    --primary-color: #2171cd;
}

/* Posts Section Styles */
.user-posts {
    margin: 30px 0;
}

.user-posts h3 {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 20px;
    color: var(--text-primary);
}

.posts-grid {
    display: grid;
    gap: 20px;
}

.post {
    background: var(--bg-secondary);
    border-radius: 8px;
    padding: 15px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.post-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 15px;
}

.post-user {
    display: flex;
    align-items: center;
    gap: 10px;
}

.post-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    object-fit: cover;
}

.post-info {
    display: flex;
    flex-direction: column;
}

.username {
    font-weight: bold;
    color: var(--text-primary);
}

.post-date {
    font-size: 0.8em;
    color: var(--text-secondary);
}

.post-content {
    margin-bottom: 15px;
}

.post-content p {
    margin-bottom: 10px;
    white-space: pre-line;
}

.post-media {
    margin: 10px 0;
    border-radius: 8px;
    overflow: hidden;
}

.post-image, .post-video {
    width: 100%;
    max-height: 400px;
    object-fit: cover;
    border-radius: 8px;
}

.post-actions {
    display: flex;
    gap: 15px;
    padding-top: 10px;
    border-top: 1px solid var(--border-color);
}

.action-btn {
    background: none;
    border: none;
    color: var(--text-secondary);
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 5px;
    padding: 5px;
    transition: color 0.2s;
}

.action-btn:hover {
    color: var(--primary-color);
}

.action-btn.liked {
    color: #ff4444;
}

.delete-post-btn {
    background: none;
    border: none;
    color: #ff4444;
    cursor: pointer;
    padding: 5px;
    opacity: 0.7;
    transition: opacity 0.2s;
}

.delete-post-btn:hover {
    opacity: 1;
}

.no-posts {
    text-align: center;
    padding: 40px;
    background: var(--bg-secondary);
    border-radius: 8px;
    color: var(--text-secondary);
}

.no-posts i {
    font-size: 2em;
    margin-bottom: 15px;
}

.create-post-btn {
    display: inline-block;
    margin-top: 15px;
    padding: 10px 20px;
    background: var(--primary-color);
    color: white;
    border-radius: 4px;
    text-decoration: none;
    transition: background-color 0.2s;
}

.create-post-btn:hover {
    background: var(--primary-color-dark);
}

@media (max-width: 768px) {
    .posts-grid {
        grid-template-columns: 1fr;
    }
}

/* Profile Picture Edit Styles */
.profile-picture-edit {
    margin-bottom: 30px;
}

.picture-preview {
    position: relative;
    width: 150px;
    height: 150px;
    margin: 10px 0;
    border-radius: 50%;
    overflow: hidden;
}

.picture-preview img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.picture-overlay {
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    background: rgba(0, 0, 0, 0.7);
    padding: 10px;
    opacity: 0;
    transition: opacity 0.3s;
}

.picture-preview:hover .picture-overlay {
    opacity: 1;
}

.upload-btn {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 5px;
    color: white;
    cursor: pointer;
}

.upload-btn i {
    font-size: 1.2em;
}

.form-text {
    display: block;
    margin-top: 5px;
    color: var(--text-secondary);
    font-size: 0.9em;
}

/* Friend Stats Styling */
.friends-stat, .mutual-stat {
    cursor: pointer;
    position: relative;
    transition: transform 0.2s ease;
}

.friends-stat:hover, .mutual-stat:hover {
    transform: translateY(-2px);
}

/* Friends Dropdown Styling */
.friends-dropdown {
    position: absolute;
    width: 300px;
    max-height: 400px;
    background: var(--bg-primary);
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    z-index: 1000;
    left: 0;
    top: 100%;
    margin-top: 10px;
    display: none;
    overflow: hidden;
    transition: all 0.3s ease;
    border: 1px solid var(--border-color);
}

.friends-dropdown.active {
    display: block;
    animation: fadeIn 0.3s ease;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
}

.dropdown-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 15px;
    background: var(--bg-secondary);
    border-bottom: 1px solid var(--border-color);
}

.dropdown-header h4 {
    margin: 0;
    display: flex;
    align-items: center;
    gap: 8px;
    color: var(--text-primary);
    font-size: 16px;
}

.close-dropdown {
    background: none;
    border: none;
    color: var(--text-secondary);
    cursor: pointer;
    font-size: 16px;
    padding: 5px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background 0.2s ease;
}

.close-dropdown:hover {
    background: rgba(0, 0, 0, 0.05);
    color: var(--text-primary);
}

.dropdown-content {
    max-height: 350px;
    overflow-y: auto;
    padding: 10px 0;
}

.friend-item {
    display: flex;
    align-items: center;
    padding: 10px 15px;
    transition: background 0.2s ease;
    cursor: default;
}

.friend-item:hover {
    background: var(--bg-secondary);
}

.friend-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    object-fit: cover;
    margin-right: 12px;
}

.friend-info {
    flex: 1;
    display: flex;
    flex-direction: column;
}

.friend-username {
    font-weight: 500;
    color: var(--text-primary);
}

.friend-bio {
    font-size: 12px;
    color: var(--text-secondary);
    margin-top: 2px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.view-friend-btn {
    background: var(--primary-color);
    color: white;
    border: none;
    padding: 6px 12px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 12px;
    display: flex;
    align-items: center;
    gap: 5px;
    text-decoration: none;
    transition: background 0.2s ease;
}

.view-friend-btn:hover {
    background: var(--primary-color-dark);
}

.no-friends {
    text-align: center;
    padding: 15px;
    color: var(--text-secondary);
    font-style: italic;
}

/* Scrollbar styling for dropdown content */
.dropdown-content::-webkit-scrollbar {
    width: 8px;
}

.dropdown-content::-webkit-scrollbar-track {
    background: var(--bg-primary);
}

.dropdown-content::-webkit-scrollbar-thumb {
    background: var(--border-color);
    border-radius: 4px;
}

.dropdown-content::-webkit-scrollbar-thumb:hover {
    background: var(--text-secondary);
}

/* Responsive styling */
@media (max-width: 768px) {
    .friends-dropdown {
        width: 280px;
        left: 50%;
        transform: translateX(-50%);
    }
}

@media (max-width: 480px) {
    .friends-dropdown {
        width: 90%;
        max-width: 300px;
    }
}

/* Add notification badge */
.notification-badge {
    position: absolute;
    top: -8px;
    right: -8px;
    background-color: #ff4b4b;
    color: white;
    font-size: 0.7rem;
    padding: 2px 6px;
    border-radius: 10px;
    font-weight: bold;
}

.btn-report {
    background: none;
    border: none;
    color: var(--text-secondary);
    cursor: pointer;
    padding: 5px 10px;
    font-size: 0.9em;
    transition: all 0.2s ease;
    display: inline-flex;
    align-items: center;
    gap: 5px;
}

.btn-report:hover {
    color: var(--danger-color);
}

.btn-report i {
    font-size: 1.1em;
}
</style>

<script>
// Profile picture preview and upload
document.getElementById('profile_picture').addEventListener('change', function(e) {
    if (this.files && this.files[0]) {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            document.getElementById('profilePreview').src = e.target.result;
        }
        
        reader.readAsDataURL(this.files[0]);
        
        // Automatically submit the form when a file is selected
        document.getElementById('pictureForm').submit();
    }
});

// Profile picture preview
document.getElementById('profile_picture').addEventListener('change', function(e) {
    if (this.files && this.files[0]) {
        const reader = new FileReader();
        
        reader.onload = function(e) {
            document.getElementById('picturePreview').src = e.target.result;
        }
        
        reader.readAsDataURL(this.files[0]);
    }
});

// Mobile menu toggle
document.querySelector('.nav-toggle').addEventListener('click', function() {
    document.querySelector('.nav-links').classList.toggle('active');
});

// Auto-hide alerts after 5 seconds
document.addEventListener('DOMContentLoaded', function() {
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 300);
        }, 5000);
    });
});

document.addEventListener('DOMContentLoaded', function() {
    const pictureInput = document.getElementById('profile_picture');
    const picturePreview = document.getElementById('picturePreview');
    
    if (pictureInput) {
        pictureInput.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    picturePreview.src = e.target.result;
                };
                reader.readAsDataURL(file);
            }
        });
    }
    
    // Delete post functionality
    const deleteButtons = document.querySelectorAll('.delete-post-btn');
    deleteButtons.forEach(button => {
        button.addEventListener('click', async function(e) {
            e.stopPropagation();
            const postId = this.getAttribute('data-post-id');
            if (confirm('Are you sure you want to delete this post?')) {
                try {
                    const response = await fetch('api/posts.php', {
                        method: 'DELETE',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({ post_id: postId })
                    });
                    
                    const data = await response.json();
                    
                    if (data.success) {
                        const postElement = document.querySelector(`.post[data-post-id="${postId}"]`);
                        postElement.remove();
                        showNotification('Post deleted successfully!', 'success');
                    } else {
                        showNotification(data.message, 'error');
                    }
                } catch (error) {
                    console.error('Error:', error);
                    showNotification('An error occurred. Please try again.', 'error');
                }
            }
        });
    });
    
    // Like post functionality
    const likeButtons = document.querySelectorAll('.like-btn');
    likeButtons.forEach(button => {
        button.addEventListener('click', async function() {
            const postId = this.getAttribute('data-post-id');
            try {
                const response = await fetch('api/likes.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ post_id: postId })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    const likeIcon = this.querySelector('i');
                    const likeCount = this.querySelector('.like-count');
                    
                    if (data.liked) {
                        likeIcon.classList.remove('far');
                        likeIcon.classList.add('fas');
                        this.classList.add('liked');
                    } else {
                        likeIcon.classList.remove('fas');
                        likeIcon.classList.add('far');
                        this.classList.remove('liked');
                    }
                    
                    likeCount.textContent = data.likeCount;
                } else {
                    showNotification(data.message, 'error');
                }
            } catch (error) {
                console.error('Error:', error);
                showNotification('An error occurred. Please try again.', 'error');
            }
        });
    });
    
    // Comment functionality
    const commentButtons = document.querySelectorAll('.comment-btn');
    commentButtons.forEach(button => {
        button.addEventListener('click', function() {
            const postId = this.getAttribute('data-post-id');
            // Implementation for comments
        });
    });
});

function submitReport(contentType, contentId, reportedId) {
    const reason = prompt('Please provide a reason for your report:');
    if (!reason) return;

    // Show loading state
    const loadingToast = showNotification('Submitting report...', 'info');

    fetch('includes/report_handler.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `content_type=${contentType}&content_id=${contentId || ''}&reported_id=${reportedId}&reason=${encodeURIComponent(reason)}`
    })
    .then(response => response.json())
    .then(data => {
        // Remove loading notification
        loadingToast.remove();
        
        // Show success or error message
        showNotification(data.message, data.success ? 'success' : 'error');
    })
    .catch(error => {
        // Remove loading notification
        loadingToast.remove();
        
        console.error('Error:', error);
        showNotification('An error occurred while submitting the report. Please try again.', 'error');
    });
}

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
        ${message}
    `;
    
    document.body.appendChild(notification);
    
    // Auto-hide after 3 seconds for success/error messages
    if (type !== 'info') {
        setTimeout(() => {
            notification.classList.add('fade-out');
            setTimeout(() => notification.remove(), 3000);
        }, 3000);
    }
    
    return notification;
}

function toggleFriendsList() {
    const dropdown = document.getElementById('friendsDropdown');
    const mutualDropdown = document.getElementById('mutualFriendsDropdown');
    
    if (mutualDropdown && mutualDropdown.classList.contains('active')) {
        mutualDropdown.classList.remove('active');
    }
    
    dropdown.classList.toggle('active');
}

function toggleMutualFriendsList() {
    const dropdown = document.getElementById('mutualFriendsDropdown');
    const friendsDropdown = document.getElementById('friendsDropdown');
    
    if (friendsDropdown.classList.contains('active')) {
        friendsDropdown.classList.remove('active');
    }
    
    dropdown.classList.toggle('active');
}

// Close dropdowns when clicking outside
document.addEventListener('click', function(event) {
    const friendsDropdown = document.getElementById('friendsDropdown');
    const mutualDropdown = document.getElementById('mutualFriendsDropdown');
    const friendsStat = document.querySelector('.friends-stat');
    const mutualStat = document.querySelector('.mutual-stat');
    
    if (friendsDropdown && !friendsDropdown.contains(event.target) && !friendsStat.contains(event.target)) {
        friendsDropdown.classList.remove('active');
    }
    
    if (mutualDropdown && !mutualDropdown.contains(event.target) && mutualStat && !mutualStat.contains(event.target)) {
        mutualDropdown.classList.remove('active');
    }
});
</script>
</body>
</html>
