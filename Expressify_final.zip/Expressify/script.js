// Friend request functionality
function handleFriendRequest(userId, button) {
    const action = button.getAttribute('data-action'); // 'send', 'accept', 'cancel', or 'unfriend'
    
    fetch('api/friend_request.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
            userId: userId,
            action: action
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            updateFriendButton(button, data.newStatus);
            
            // Update friend count
            const friendCount = document.querySelector('.friend-count');
            if (friendCount && (data.newStatus === 'friends' || data.newStatus === 'none')) {
                let count = parseInt(friendCount.textContent);
                friendCount.textContent = data.newStatus === 'friends' ? count + 1 : count - 1;
            }
            
            // Show notification
            if (data.message) {
                showNotification(data.message, 'success');
            }
        } else {
            showNotification(data.message || 'An error occurred', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showNotification('An error occurred while processing your request', 'error');
    });
}

function updateFriendButton(button, status) {
    switch(status) {
        case 'none':
            button.innerHTML = '<i class="fas fa-user-plus"></i> Add Friend';
            button.setAttribute('data-action', 'send');
            button.classList.remove('pending', 'friends');
            break;
        case 'pending_sent':
            button.innerHTML = '<i class="fas fa-clock"></i> Cancel Request';
            button.setAttribute('data-action', 'cancel');
            button.classList.add('pending');
            button.classList.remove('friends');
            break;
        case 'pending_received':
            button.innerHTML = '<i class="fas fa-user-clock"></i> Respond to Request';
            button.setAttribute('data-action', 'accept');
            button.classList.add('pending');
            button.classList.remove('friends');
            break;
        case 'friends':
            button.innerHTML = '<i class="fas fa-user-check"></i> Friends';
            button.setAttribute('data-action', 'unfriend');
            button.classList.add('friends');
            button.classList.remove('pending');
            break;
    }
}

function showNotification(message, type) {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
        <span>${message}</span>
    `;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.classList.add('fade-out');
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Add event listeners to friend buttons
document.addEventListener('DOMContentLoaded', () => {
    const friendButtons = document.querySelectorAll('.friend-btn');
    friendButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            e.preventDefault();
            const userId = button.getAttribute('data-user-id');
            handleFriendRequest(userId, button);
        });
    });
}); 