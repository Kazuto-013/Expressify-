<?php
class Database {
    private static $instance = null;
    
    public static function getConnection() {
        if (self::$instance === null) {
            $host = 'localhost';
            $dbname = 'Expressify_db';
            $username = 'root';
            $password = '1234';
            
            self::$instance = new mysqli($host, $username, $password, $dbname);
            
            if (self::$instance->connect_error) {
                throw new Exception("Connection failed: " . self::$instance->connect_error);
            }
            
            self::$instance->set_charset("utf8mb4");
        }
        return self::$instance;
    }
} 