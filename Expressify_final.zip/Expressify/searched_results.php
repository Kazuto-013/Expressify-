<?php
require 'session.php';
require 'config.php';
require 'theme.php';

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Get search parameters
$search = isset($_GET['q']) ? trim($_GET['q']) : '';
$search_type = isset($_GET['type']) ? $_GET['type'] : 'all';

// If search is empty, redirect to explore page
if (empty($search)) {
    header('Location: explore.php');
    exit;
}

// Get unread notifications count for navbar
$stmt = $conn->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$unread_count = $stmt->get_result()->fetch_assoc()['count'];

// Check if friend_requests table exists for friendship status
$result = $conn->query("SHOW TABLES LIKE 'friend_requests'");
$friend_requests_table_exists = ($result->num_rows > 0);

// Search functionality based on type
$users_results = [];
$posts_results = [];

// Search for users
if ($search_type === 'all' || $search_type === 'users') {
    // Basic user search query
    $users_query = "
        SELECT u.id, u.username, u.profile_picture, u.bio, u.created_at
        FROM users u
        WHERE u.username LIKE CONCAT('%', ?, '%') 
        OR u.email LIKE CONCAT('%', ?, '%')
        OR u.bio LIKE CONCAT('%', ?, '%')
        AND u.id != ? 
        ORDER BY 
            CASE 
                WHEN u.username = ? THEN 0
                WHEN u.username LIKE CONCAT(?, '%') THEN 1
                WHEN u.username LIKE CONCAT('%', ?, '%') THEN 2
                ELSE 3
            END, 
            u.username ASC
    ";
    
    // Enhanced query with friendship status if table exists
    if ($friend_requests_table_exists) {
        $users_query = "
            SELECT 
                u.id, 
                u.username, 
                u.profile_picture, 
                u.bio, 
                u.created_at,
                CASE
                    WHEN fr.status = 'accepted' THEN 'friends'
                    WHEN fr.status = 'pending' AND fr.sender_id = ? THEN 'pending_sent'
                    WHEN fr.status = 'pending' AND fr.receiver_id = ? THEN 'pending_received'
                    ELSE 'not_friends'
                END as friendship_status
            FROM users u
            LEFT JOIN friend_requests fr ON 
                (fr.sender_id = ? AND fr.receiver_id = u.id) OR 
                (fr.sender_id = u.id AND fr.receiver_id = ?)
            WHERE (u.username LIKE CONCAT('%', ?, '%') 
                OR u.email LIKE CONCAT('%', ?, '%')
                OR u.bio LIKE CONCAT('%', ?, '%'))
                AND u.id != ? 
            ORDER BY 
                CASE 
                    WHEN u.username = ? THEN 0
                    WHEN u.username LIKE CONCAT(?, '%') THEN 1
                    WHEN u.username LIKE CONCAT('%', ?, '%') THEN 2
                    ELSE 3
                END, 
                u.username ASC
        ";
        
        $stmt = $conn->prepare($users_query);
        $stmt->bind_param("iiiisssisss", 
            $user_id, $user_id, $user_id, $user_id, 
            $search, $search, $search, $user_id, 
            $search, $search, $search
        );
    } else {
        $stmt = $conn->prepare($users_query);
        $stmt->bind_param("sssisss", 
            $search, $search, $search, $user_id, 
            $search, $search, $search
        );
    }
    
    $stmt->execute();
    $users_result = $stmt->get_result();
    
    while ($row = $users_result->fetch_assoc()) {
        $users_results[] = $row;
    }
}

// Search for posts
if ($search_type === 'all' || $search_type === 'posts') {
    $posts_query = "
        SELECT 
            p.*, 
            u.username, 
            u.profile_picture,
            m.file_path,
            m.file_type,
            COUNT(DISTINCT l.id) as likes_count,
            COUNT(DISTINCT c.id) as comments_count,
            MAX(CASE WHEN l.user_id = ? THEN 1 ELSE 0 END) as user_liked
        FROM posts p
        JOIN users u ON p.user_id = u.id
        LEFT JOIN media m ON p.media_id = m.id
        LEFT JOIN likes l ON p.id = l.post_id
        LEFT JOIN comments c ON p.id = c.post_id
        WHERE p.content LIKE CONCAT('%', ?, '%')
        OR u.username LIKE CONCAT('%', ?, '%')
        GROUP BY p.id
        ORDER BY 
            CASE 
                WHEN p.content = ? THEN 0
                WHEN p.content LIKE CONCAT(?, '%') THEN 1
                WHEN p.content LIKE CONCAT('%', ?, '%') THEN 2
                ELSE 3
            END,
            p.created_at DESC
    ";
    
    $stmt = $conn->prepare($posts_query);
    $stmt->bind_param("isssss", $user_id, $search, $search, $search, $search, $search);
    $stmt->execute();
    $posts_result = $stmt->get_result();
    
    while ($row = $posts_result->fetch_assoc()) {
        $posts_results[] = $row;
    }
}

// Get theme preference
$theme = $_SESSION['theme'] ?? 'light';
?>
<!DOCTYPE html>
<html data-theme="<?php echo htmlspecialchars($theme); ?>">
<head>
    <title>Search Results: <?php echo htmlspecialchars($search); ?> - Expressify</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
    /* Search Section Styles */
    .search-header {
        margin-bottom: 20px;
        padding-bottom: 20px;
        border-bottom: 1px solid var(--border-color);
    }

    .search-header h2 {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 15px;
        color: var(--text-primary);
    }

    .search-form {
        margin-bottom: 15px;
    }

    .search-container {
        display: flex;
        gap: 10px;
        max-width: 600px;
    }

    .search-input {
        flex: 1;
        padding: 12px 15px;
        border: 1px solid var(--border-color);
        border-radius: 8px;
        background-color: var(--bg-secondary);
        color: var(--text-primary);
        font-size: 16px;
    }

    .search-type {
        padding: 12px 15px;
        border: 1px solid var(--border-color);
        border-radius: 8px;
        background-color: var(--bg-secondary);
        color: var(--text-primary);
        cursor: pointer;
    }

    .search-button {
        padding: 12px 20px;
        background-color: var(--primary-color);
        color: white;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        transition: background-color 0.2s;
    }

    .search-button:hover {
        background-color: var(--primary-color-dark);
    }

    .search-stats {
        color: var(--text-secondary);
        font-size: 14px;
    }

    /* Search Results Styles */
    .search-section {
        margin-bottom: 30px;
    }

    .search-section h3 {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 15px;
        color: var(--text-primary);
        font-size: 1.2em;
    }

    /* User Results Styles */
    .users-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: 20px;
    }

    .user-card {
        background-color: var(--bg-secondary);
        border-radius: 8px;
        padding: 20px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        transition: transform 0.2s;
    }

    .user-card:hover {
        transform: translateY(-5px);
    }

    .user-card-header {
        display: flex;
        align-items: center;
        gap: 15px;
        margin-bottom: 15px;
    }

    .user-avatar {
        width: 60px;
        height: 60px;
        border-radius: 50%;
        object-fit: cover;
    }

    .user-primary-info h4 {
        margin: 0 0 5px 0;
        color: var(--text-primary);
        font-size: 1.1em;
    }

    .user-join-date {
        margin: 0;
        color: var(--text-secondary);
        font-size: 0.8em;
    }

    .user-bio {
        margin: 0 0 20px 0;
        color: var(--text-secondary);
        font-size: 0.9em;
        line-height: 1.4;
        max-height: 80px;
        overflow: hidden;
    }

    .empty-bio {
        color: var(--text-secondary);
        font-style: italic;
    }

    .user-card-actions {
        display: flex;
        flex-direction: column;
        gap: 10px;
    }

    .view-profile-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        padding: 10px;
        background-color: var(--primary-color);
        color: white;
        border: none;
        border-radius: 6px;
        text-decoration: none;
        text-align: center;
        transition: background-color 0.2s;
    }

    .view-profile-btn:hover {
        background-color: var(--primary-color-dark);
    }

    .friend-action-btn, .friendship-status {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        padding: 10px;
        border: 1px solid var(--border-color);
        border-radius: 6px;
        background-color: var(--bg-primary);
        color: var(--text-primary);
        font-size: 0.9em;
        cursor: pointer;
        transition: all 0.2s;
    }

    .friend-action-btn:hover {
        background-color: var(--bg-hover);
    }

    .friend-action-btn.add-friend {
        color: #2ecc71;
        border-color: #2ecc71;
    }

    .friend-action-btn.add-friend:hover {
        background-color: #2ecc71;
        color: white;
    }

    .friend-action-btn.cancel-request,
    .friend-action-btn.reject-request {
        color: #e74c3c;
        border-color: #e74c3c;
    }

    .friend-action-btn.cancel-request:hover,
    .friend-action-btn.reject-request:hover {
        background-color: #e74c3c;
        color: white;
    }

    .friend-action-btn.accept-request {
        color: #2ecc71;
        border-color: #2ecc71;
    }

    .friend-action-btn.accept-request:hover {
        background-color: #2ecc71;
        color: white;
    }

    .friendship-status {
        background-color: #3498db;
        color: white;
        border-color: #3498db;
        cursor: default;
    }

    .friend-request-options {
        display: flex;
        gap: 10px;
    }

    .friend-request-options .friend-action-btn {
        flex: 1;
    }

    /* Post Results Styles */
    .posts-container {
        display: flex;
        flex-direction: column;
        gap: 20px;
    }

    .post {
        background-color: var(--bg-secondary);
        border-radius: 8px;
        padding: 20px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        cursor: pointer;
        transition: transform 0.2s;
    }

    .post:hover {
        transform: translateY(-5px);
    }

    .post-header {
        display: flex;
        justify-content: space-between;
        margin-bottom: 15px;
    }

    .post-user {
        display: flex;
        align-items: center;
        gap: 15px;
    }

    .post-avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        object-fit: cover;
    }

    .post-info {
        display: flex;
        flex-direction: column;
    }

    .username {
        color: var(--text-primary);
        font-weight: 500;
        text-decoration: none;
        margin-bottom: 3px;
    }

    .username:hover {
        text-decoration: underline;
    }

    .post-date {
        color: var(--text-secondary);
        font-size: 0.8em;
    }

    .post-content {
        margin-bottom: 15px;
    }

    .post-content p {
        margin: 0 0 15px 0;
        line-height: 1.5;
        color: var(--text-primary);
    }

    .post-media {
        margin: 15px 0;
        border-radius: 8px;
        overflow: hidden;
    }

    .post-image, .post-video {
        width: 100%;
        max-height: 400px;
        object-fit: cover;
        border-radius: 8px;
    }

    .post-actions {
        display: flex;
        gap: 15px;
        padding-top: 15px;
        border-top: 1px solid var(--border-color);
    }

    .action-btn {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        padding: 8px 12px;
        background: none;
        border: none;
        color: var(--text-secondary);
        cursor: pointer;
        font-size: 0.9em;
        transition: color 0.2s;
    }

    .action-btn:hover {
        color: var(--primary-color);
    }

    .action-btn.liked {
        color: #e74c3c;
    }

    .action-btn.view-post-btn {
        margin-left: auto;
        color: var(--primary-color);
    }

    .action-btn.view-post-btn:hover {
        text-decoration: underline;
    }

    /* No Results Styles */
    .no-results {
        text-align: center;
        padding: 40px;
        background-color: var(--bg-secondary);
        border-radius: 8px;
        color: var(--text-secondary);
    }

    .no-results i {
        font-size: 3em;
        margin-bottom: 15px;
        color: var(--text-secondary);
    }

    /* Notification styles for friend requests */
    .notification {
        position: fixed;
        bottom: 20px;
        right: 20px;
        padding: 15px 20px;
        border-radius: 5px;
        background-color: white;
        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.2);
        display: flex;
        align-items: center;
        max-width: 300px;
        z-index: 1000;
        animation: slideIn 0.3s ease;
    }

    .notification.success {
        border-left: 4px solid #2ecc71;
    }

    .notification.success i {
        color: #2ecc71;
    }

    .notification.error {
        border-left: 4px solid #e74c3c;
    }

    .notification.error i {
        color: #e74c3c;
    }

    .notification i {
        margin-right: 10px;
        font-size: 20px;
    }

    .notification p {
        margin: 0;
        font-size: 14px;
    }

    .notification.fade-out {
        animation: fadeOut 0.3s ease forwards;
    }

    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }

    @keyframes fadeOut {
        from {
            opacity: 1;
        }
        to {
            opacity: 0;
        }
    }

    /* Responsive Styles */
    @media (max-width: 768px) {
        .users-grid {
            grid-template-columns: 1fr;
        }
        
        .search-container {
            flex-direction: column;
        }
        
        .user-card-actions, .friend-request-options {
            flex-direction: column;
        }
    }
    </style>
</head>
<body>
<div class="container">
    <!-- Navigation bar -->
    <nav class="navbar">
        <div class="nav-brand">
            <h2>Expressify</h2>
        </div>
        <div class="nav-links">
            <a href="home.php" class="nav-item"><i class="fas fa-home"></i> Home</a>
            <a href="posts.php" class="nav-item"><i class="fas fa-pen"></i> Create Post</a>
            <a href="explore.php" class="nav-item active"><i class="fas fa-compass"></i> Explore</a>
            <div class="nav-item notifications-dropdown">
                <button class="notifications-btn">
                    <i class="fas fa-bell"></i> Notifications
                    <?php if ($unread_count > 0): ?>
                        <span class="notification-badge"><?php echo $unread_count; ?></span>
                    <?php endif; ?>
                </button>
                <div class="notifications-menu">
                    <div class="notifications-header">
                        <h3>Notifications</h3>
                        <button class="mark-all-read">Mark all as read</button>
                    </div>
                    <div class="notifications-list">
                        <!-- Notifications will be loaded here -->
                    </div>
                    <div class="notifications-footer">
                        <a href="notifications.php" class="view-all">View All Notifications</a>
                    </div>
                </div>
            </div>
            <a href="profile.php" class="nav-item"><i class="fas fa-user"></i> My Profile</a>
            <a href="friends.php" class="nav-item"><i class="fas fa-users"></i> Friends</a>
            <a href="settings.php" class="nav-item"><i class="fas fa-cog"></i> Settings</a>
            <a href="logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
        <div class="nav-toggle">
            <i class="fas fa-bars"></i>
        </div>
    </nav>

    <div class="content">
        <div class="search-header">
            <h2><i class="fas fa-search"></i> Search Results: "<?php echo htmlspecialchars($search); ?>"</h2>
            
            <!-- Search form -->
            <form method="GET" class="search-form">
                <div class="search-container">
                    <input type="text" name="q" placeholder="Search users, posts..." value="<?php echo htmlspecialchars($search); ?>" class="search-input">
                    <select name="type" class="search-type">
                        <option value="all" <?php echo $search_type === 'all' ? 'selected' : ''; ?>>All</option>
                        <option value="users" <?php echo $search_type === 'users' ? 'selected' : ''; ?>>Users</option>
                        <option value="posts" <?php echo $search_type === 'posts' ? 'selected' : ''; ?>>Posts</option>
                    </select>
                    <button type="submit" class="search-button">
                        <i class="fas fa-search"></i>
                    </button>
                </div>
            </form>
            
            <div class="search-stats">
                <p>Found <?php echo count($users_results); ?> users and <?php echo count($posts_results); ?> posts matching your search.</p>
            </div>
        </div>
        
        <!-- Display search results -->
        <div class="search-results">
            <!-- User results section -->
            <?php if ($search_type === 'all' || $search_type === 'users'): ?>
                <div class="search-section">
                    <h3><i class="fas fa-users"></i> People</h3>
                    
                    <?php if (count($users_results) > 0): ?>
                        <div class="users-grid">
                            <?php foreach ($users_results as $user): ?>
                                <div class="user-card">
                                    <div class="user-card-header">
                                        <img src="<?php echo !empty($user['profile_picture']) ? htmlspecialchars($user['profile_picture']) : 'assets/default-avatar.png'; ?>" 
                                            alt="Profile Picture" class="user-avatar">
                                        <div class="user-primary-info">
                                            <h4><?php echo htmlspecialchars($user['username']); ?></h4>
                                            <p class="user-join-date">Joined <?php echo date('M Y', strtotime($user['created_at'])); ?></p>
                                        </div>
                                    </div>
                                    
                                    <?php if (!empty($user['bio'])): ?>
                                        <p class="user-bio"><?php echo htmlspecialchars(substr($user['bio'], 0, 100)) . (strlen($user['bio']) > 100 ? '...' : ''); ?></p>
                                    <?php else: ?>
                                        <p class="user-bio empty-bio"><em>No bio provided</em></p>
                                    <?php endif; ?>
                                    
                                    <div class="user-card-actions">
                                        <a href="searched_profile_viewer.php?user_id=<?php echo $user['id']; ?>" class="view-profile-btn">
                                            <i class="fas fa-user"></i> View Profile
                                        </a>
                                        
                                        <?php if ($friend_requests_table_exists && isset($user['friendship_status'])): ?>
                                            <?php if ($user['friendship_status'] === 'not_friends'): ?>
                                                <button class="friend-action-btn add-friend" data-user-id="<?php echo $user['id']; ?>">
                                                    <i class="fas fa-user-plus"></i> Add Friend
                                                </button>
                                            <?php elseif ($user['friendship_status'] === 'pending_sent'): ?>
                                                <button class="friend-action-btn cancel-request" data-user-id="<?php echo $user['id']; ?>">
                                                    <i class="fas fa-user-times"></i> Cancel Request
                                                </button>
                                            <?php elseif ($user['friendship_status'] === 'pending_received'): ?>
                                                <div class="friend-request-options">
                                                    <button class="friend-action-btn accept-request" data-user-id="<?php echo $user['id']; ?>">
                                                        <i class="fas fa-check"></i> Accept
                                                    </button>
                                                    <button class="friend-action-btn reject-request" data-user-id="<?php echo $user['id']; ?>">
                                                        <i class="fas fa-times"></i> Reject
                                                    </button>
                                                </div>
                                            <?php elseif ($user['friendship_status'] === 'friends'): ?>
                                                <div class="friendship-status">
                                                    <i class="fas fa-user-check"></i> Friends
                                                </div>
                                                <button class="message-btn" onclick="startConversation(<?php echo $user['id']; ?>, '<?php echo htmlspecialchars($user['username'], ENT_QUOTES); ?>')">
                                                    <i class="fas fa-comments"></i> Message
                                                </button>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="no-results">
                            <i class="fas fa-user-slash"></i>
                            <p>No users found matching your search.</p>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <!-- Posts results section -->
            <?php if ($search_type === 'all' || $search_type === 'posts'): ?>
                <div class="search-section">
                    <h3><i class="fas fa-file-alt"></i> Posts</h3>
                    
                    <?php if (count($posts_results) > 0): ?>
                        <div class="posts-container">
                            <?php foreach ($posts_results as $post): ?>
                                <div class="post" data-post-id="<?php echo $post['id']; ?>">
                                    <div class="post-header">
                                        <div class="post-user">
                                            <img src="<?php echo !empty($post['profile_picture']) ? htmlspecialchars($post['profile_picture']) : 'assets/default-avatar.png'; ?>" 
                                                alt="Profile Picture" class="post-avatar">
                                            <div class="post-info">
                                                <a href="searched_profile_viewer.php?user_id=<?php echo $post['user_id']; ?>" class="username">
                                                    <?php echo htmlspecialchars($post['username']); ?>
                                                </a>
                                                <span class="post-date"><?php echo date('M d, Y', strtotime($post['created_at'])); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="post-content">
                                        <p><?php echo nl2br(htmlspecialchars($post['content'])); ?></p>
                                        <?php if (!empty($post['file_path'])): ?>
                                            <div class="post-media">
                                                <?php if (strpos($post['file_type'], 'image/') !== false || in_array($post['file_type'], ['jpg', 'jpeg', 'png', 'gif'])): ?>
                                                    <img src="<?php echo htmlspecialchars($post['file_path']); ?>" alt="Post image" class="post-image">
                                                <?php elseif (strpos($post['file_type'], 'video/') !== false || in_array($post['file_type'], ['mp4', 'mov'])): ?>
                                                    <video controls class="post-video">
                                                        <source src="<?php echo htmlspecialchars($post['file_path']); ?>" type="video/<?php echo $post['file_type']; ?>">
                                                        Your browser does not support the video tag.
                                                    </video>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="post-actions">
                                        <button class="action-btn like-btn <?php echo $post['user_liked'] ? 'liked' : ''; ?>" 
                                                data-post-id="<?php echo $post['id']; ?>"
                                                data-liked="<?php echo $post['user_liked']; ?>">
                                            <i class="<?php echo $post['user_liked'] ? 'fas' : 'far'; ?> fa-heart"></i>
                                            <span class="like-count"><?php echo $post['likes_count']; ?></span>
                                        </button>
                                        <button class="action-btn comment-btn" data-post-id="<?php echo $post['id']; ?>">
                                            <i class="far fa-comment"></i>
                                            <span class="comment-count"><?php echo $post['comments_count']; ?></span>
                                        </button>
                                        <button class="action-btn view-post-btn" data-post-id="<?php echo $post['id']; ?>">
                                            <i class="fas fa-eye"></i> View Full Post
                                        </button>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="no-results">
                            <i class="fas fa-file-excel"></i>
                            <p>No posts found matching your search.</p>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    document.querySelector('.nav-toggle').addEventListener('click', function() {
        document.querySelector('.nav-links').classList.toggle('active');
    });
    
    // Friend request functionality
    const friendBtns = document.querySelectorAll('.friend-action-btn');
    
    friendBtns.forEach(button => {
        if (button.classList.contains('add-friend')) {
            button.addEventListener('click', function(e) {
                e.stopPropagation(); // Prevent triggering parent click
                sendFriendRequest('send', this.dataset.userId);
            });
        } else if (button.classList.contains('cancel-request')) {
            button.addEventListener('click', function(e) {
                e.stopPropagation(); // Prevent triggering parent click
                sendFriendRequest('cancel', this.dataset.userId);
            });
        } else if (button.classList.contains('accept-request')) {
            button.addEventListener('click', function(e) {
                e.stopPropagation(); // Prevent triggering parent click
                sendFriendRequest('accept', this.dataset.userId);
            });
        } else if (button.classList.contains('reject-request')) {
            button.addEventListener('click', function(e) {
                e.stopPropagation(); // Prevent triggering parent click
                sendFriendRequest('reject', this.dataset.userId);
            });
        }
    });
    
    async function sendFriendRequest(action, userId) {
        try {
            const response = await fetch('api/friend_request.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ action, user_id: userId })
            });
            
            const data = await response.json();
            
            if (data.success) {
                showNotification(data.message, 'success');
                // Reload page to refresh UI after short delay
                setTimeout(() => {
                    window.location.reload();
                }, 1500);
            } else {
                showNotification(data.message || 'An error occurred', 'error');
            }
        } catch (error) {
            console.error('Error:', error);
            showNotification('Failed to process request', 'error');
        }
    }
    
    // Message functionality
    window.startConversation = function(userId, username) {
        window.location.href = `messages.php?user_id=${userId}`;
    };
    
    // Post like functionality
    const likeBtns = document.querySelectorAll('.like-btn');
    
    likeBtns.forEach(button => {
        button.addEventListener('click', async function(e) {
            e.stopPropagation(); // Prevent triggering post click
            
            const postId = this.dataset.postId;
            const isLiked = this.dataset.liked === '1';
            
            try {
                const response = await fetch('like_post.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ post_id: postId })
                });
                
                if (response.ok) {
                    const data = await response.json();
                    
                    // Update UI
                    this.dataset.liked = isLiked ? '0' : '1';
                    this.querySelector('i').className = isLiked ? 'far fa-heart' : 'fas fa-heart';
                    this.querySelector('.like-count').textContent = data.like_count;
                    this.classList.toggle('liked');
                    
                    showNotification(isLiked ? 'Post unliked' : 'Post liked', 'success');
                }
            } catch (error) {
                console.error('Error:', error);
                showNotification('Failed to update like', 'error');
            }
        });
    });
    
    // View post functionality
    const viewPostBtns = document.querySelectorAll('.view-post-btn');
    
    viewPostBtns.forEach(button => {
        button.addEventListener('click', function(e) {
            e.stopPropagation(); // Prevent triggering post click
            const postId = this.dataset.postId;
            window.location.href = `home.php?post_id=${postId}`;
        });
    });
    
    // Make entire post clickable
    const posts = document.querySelectorAll('.post');
    
    posts.forEach(post => {
        post.addEventListener('click', function(e) {
            // Only proceed if we didn't click a button or link inside the post
            if (!e.target.closest('button') && !e.target.closest('a')) {
                const postId = this.dataset.postId;
                window.location.href = `home.php?post_id=${postId}`;
            }
        });
    });
    
    // Make user cards clickable to view profile
    const userCards = document.querySelectorAll('.user-card');
    
    userCards.forEach(card => {
        card.addEventListener('click', function(e) {
            // Only proceed if we didn't click a button or link inside the card
            if (!e.target.closest('button') && !e.target.closest('a')) {
                const viewProfileBtn = this.querySelector('.view-profile-btn');
                if (viewProfileBtn) {
                    window.location.href = viewProfileBtn.getAttribute('href');
                }
            }
        });
    });
    
    // Notification system
    function showNotification(message, type) {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
            <p>${message}</p>
        `;
        document.body.appendChild(notification);
        
        // Remove notification after 3 seconds
        setTimeout(() => {
            notification.classList.add('fade-out');
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }

    // Notifications dropdown functionality
    const notificationsBtn = document.querySelector('.notifications-btn');
    const notificationsMenu = document.querySelector('.notifications-menu');
    
    if (notificationsBtn) {
        notificationsBtn.addEventListener('click', function(e) {
            e.preventDefault();
            notificationsMenu.classList.toggle('show');
            if (notificationsMenu.classList.contains('show')) {
                loadNotifications();
            }
        });
        
        // Close notifications menu when clicking outside
        document.addEventListener('click', function(e) {
            if (!e.target.closest('.notifications-dropdown')) {
                notificationsMenu.classList.remove('show');
            }
        });
    }
    
    // Load notifications
    async function loadNotifications() {
        const notificationsList = document.querySelector('.notifications-list');
        
        try {
            const response = await fetch('api/notifications.php');
            const data = await response.json();
            
            if (data.notifications) {
                notificationsList.innerHTML = data.notifications.map(notification => `
                    <div class="notification-item ${notification.is_read ? '' : 'unread'}" 
                         data-notification-id="${notification.id}">
                        <img src="${notification.profile_picture || 'assets/default-avatar.png'}" 
                             alt="Profile picture" class="notification-avatar">
                        <div class="notification-content">
                            <p>${notification.content}</p>
                            <small>${timeAgo(new Date(notification.created_at))}</small>
                        </div>
                        ${!notification.is_read ? '<div class="notification-status"></div>' : ''}
                    </div>
                `).join('') || '<div class="no-notifications">No notifications</div>';
            }
        } catch (error) {
            console.error('Error loading notifications:', error);
            notificationsList.innerHTML = '<div class="error">Failed to load notifications</div>';
        }
    }
    
    // Mark all notifications as read
    const markAllReadBtn = document.querySelector('.mark-all-read');
    if (markAllReadBtn) {
        markAllReadBtn.addEventListener('click', async function() {
            try {
                const response = await fetch('api/notifications.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'action=mark_all_read'
                });
                
                if (response.ok) {
                    document.querySelectorAll('.notification-item').forEach(item => {
                        item.classList.remove('unread');
                        item.querySelector('.notification-status')?.remove();
                    });
                    document.querySelector('.notification-badge')?.remove();
                }
            } catch (error) {
                console.error('Error marking notifications as read:', error);
            }
        });
    }
    
    // Helper function for time ago format
    function timeAgo(timestamp) {
        const seconds = Math.floor((new Date() - timestamp) / 1000);
        
        let interval = Math.floor(seconds / 31536000);
        if (interval > 1) return interval + ' years ago';
        
        interval = Math.floor(seconds / 2592000);
        if (interval > 1) return interval + ' months ago';
        
        interval = Math.floor(seconds / 86400);
        if (interval > 1) return interval + ' days ago';
        
        interval = Math.floor(seconds / 3600);
        if (interval > 1) return interval + ' hours ago';
        
        interval = Math.floor(seconds / 60);
        if (interval > 1) return interval + ' minutes ago';
        
        return 'just now';
    }
});
</script>
</body>
</html>
?>
