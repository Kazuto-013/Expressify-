<?php
require_once '../includes/session.php';
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if(!isset($_SESSION['admin_id'])) {
    header("Location: admin_auth.php");
    exit();
}

// Ensure comments table exists with correct structure
$checkTableSQL = "SHOW TABLES LIKE 'comments'";
$commentsTableExists = $conn->query($checkTableSQL)->num_rows > 0;

if (!$commentsTableExists) {
    // Create comments table
    $createTableSQL = "CREATE TABLE IF NOT EXISTS `comments` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `post_id` int(11) NOT NULL,
        `user_id` int(11) NOT NULL,
        `comment_text` text NOT NULL,
        `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `post_id` (`post_id`),
        KEY `user_id` (`user_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    
    try {
        $conn->query($createTableSQL);
    } catch (Exception $e) {
        $debug_message = "Error creating comments table: " . $e->getMessage();
    }
} else {
    // Check if comment_text column exists
    $checkColumnSQL = "SHOW COLUMNS FROM comments LIKE 'comment_text'";
    $commentTextExists = $conn->query($checkColumnSQL)->num_rows > 0;
    
    if (!$commentTextExists) {
        // Try to add the column
        try {
            $conn->query("ALTER TABLE comments ADD COLUMN `comment_text` text NOT NULL AFTER `user_id`");
        } catch (Exception $e) {
            $debug_message = "Error adding comment_text column: " . $e->getMessage();
        }
    }
}

// Get active action
$action = isset($_GET['action']) ? $_GET['action'] : 'list';
$postId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$success = isset($_GET['success']) ? $_GET['success'] : '';
$error = isset($_GET['error']) ? $_GET['error'] : '';

// Handle search and filters
$search = isset($_GET['search']) ? $_GET['search'] : '';
$sortBy = isset($_GET['sort']) ? $_GET['sort'] : 'created_at';
$sortOrder = isset($_GET['order']) ? $_GET['order'] : 'DESC';
$page = isset($_GET['page_num']) ? (int)$_GET['page_num'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;

// Handle post actions (delete, etc.)
if(isset($_POST['action'])) {
    switch($_POST['action']) {
        case 'delete':
            if(isset($_POST['post_id'])) {
                $deleteId = (int)$_POST['post_id'];
                $stmt = $conn->prepare("DELETE FROM posts WHERE id = ?");
                $stmt->bind_param("i", $deleteId);
                if($stmt->execute()) {
                    header("Location: admin_post_management.php?success=post_deleted");
                } else {
                    header("Location: admin_post_management.php?error=delete_failed");
                }
                exit();
            }
            break;
            
        case 'feature':
            if(isset($_POST['post_id'])) {
                $featureId = (int)$_POST['post_id'];
                $stmt = $conn->prepare("UPDATE posts SET featured = 1 WHERE id = ?");
                $stmt->bind_param("i", $featureId);
                if($stmt->execute()) {
                    header("Location: admin_post_management.php?success=post_featured");
                } else {
                    header("Location: admin_post_management.php?error=feature_failed");
                }
                exit();
            }
            break;
            
        case 'unfeature':
            if(isset($_POST['post_id'])) {
                $unfeatureId = (int)$_POST['post_id'];
                $stmt = $conn->prepare("UPDATE posts SET featured = 0 WHERE id = ?");
                $stmt->bind_param("i", $unfeatureId);
                if($stmt->execute()) {
                    header("Location: admin_post_management.php?success=post_unfeatured");
                } else {
                    header("Location: admin_post_management.php?error=unfeature_failed");
                }
                exit();
            }
            break;
    }
}

// Success and error messages
$messages = [
    'post_deleted' => 'Post has been successfully deleted',
    'post_featured' => 'Post has been successfully featured',
    'post_unfeatured' => 'Post has been successfully unfeatured',
    'delete_failed' => 'Failed to delete post',
    'feature_failed' => 'Failed to feature post',
    'unfeature_failed' => 'Failed to unfeature post'
];

// Get posts with pagination
$whereClause = "";
if(!empty($search)) {
    $searchTerm = "%$search%";
    $whereClause = "WHERE p.content LIKE ? OR u.username LIKE ?";
}

// Count total posts for pagination
$countQuery = "SELECT COUNT(*) as total FROM posts p JOIN users u ON p.user_id = u.id $whereClause";
$total = 0;

if(!empty($search)) {
    $stmt = $conn->prepare($countQuery);
    $stmt->bind_param("ss", $searchTerm, $searchTerm);
    $stmt->execute();
    $total = $stmt->get_result()->fetch_assoc()['total'];
    $stmt->close();
} else {
    $total = $conn->query($countQuery)->fetch_assoc()['total'];
}

$totalPages = ceil($total / $limit);

// Get posts
$query = "SELECT p.id, p.content, p.media_id, p.created_at, p.featured,
           u.id as user_id, u.username, u.profile_picture,
           (SELECT COUNT(*) FROM likes WHERE post_id = p.id) as like_count,
           (SELECT COUNT(*) FROM comments WHERE post_id = p.id) as comment_count
          FROM posts p
          JOIN users u ON p.user_id = u.id
          $whereClause
          ORDER BY $sortBy $sortOrder
          LIMIT ?, ?";

$posts = [];

if(!empty($search)) {
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssii", $searchTerm, $searchTerm, $offset, $limit);
    $stmt->execute();
    $posts = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
} else {
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $offset, $limit);
    $stmt->execute();
    $posts = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}

// Get post details if viewing a specific post
$postDetails = null;
if($action === 'view' && $postId > 0) {
    $stmt = $conn->prepare("SELECT p.*, u.username, u.profile_picture,
                          (SELECT COUNT(*) FROM likes WHERE post_id = p.id) as like_count,
                          (SELECT COUNT(*) FROM comments WHERE post_id = p.id) as comment_count
                         FROM posts p
                         JOIN users u ON p.user_id = u.id
                         WHERE p.id = ?");
    $stmt->bind_param("i", $postId);
    $stmt->execute();
    $postDetails = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    
    if(!$postDetails) {
        header("Location: admin_post_management.php?error=post_not_found");
        exit();
    }
    
    // Get post comments
    $commentFields = "c.id, c.post_id, c.user_id, c.created_at, c.content, u.username, u.profile_picture";
    
    // Check which comment text field exists in the database
    $commentTextCol = "";
    $commentCols = ["comment_text", "text", "content"];
    foreach ($commentCols as $col) {
        $checkColumnSQL = "SHOW COLUMNS FROM comments LIKE '$col'";
        if ($conn->query($checkColumnSQL)->num_rows > 0) {
            $commentTextCol = $col;
            break;
        }
    }
    
    if (!empty($commentTextCol)) {
        $commentFields .= ", c.$commentTextCol";
    }
    
    // Prepare the query with the detected column
    $stmt = $conn->prepare("SELECT $commentFields
                          FROM comments c
                          JOIN users u ON c.user_id = u.id
                          WHERE c.post_id = ?
                          ORDER BY c.created_at DESC");
    $stmt->bind_param("i", $postId);
    $stmt->execute();
    $postComments = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
    
    // If we found a comment text column, map it to comment_text for consistency
    if (!empty($commentTextCol) && $commentTextCol != "comment_text") {
        foreach ($postComments as &$comment) {
            if (isset($comment[$commentTextCol])) {
                $comment['comment_text'] = $comment[$commentTextCol];
            }
        }
        unset($comment); // Break the reference
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Post Management - Expressify Admin</title>
    <link rel="stylesheet" href="admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-brand">
                <h1>Express<span>ify</span></h1>
                <p>Admin Panel</p>
            </div>
            <ul class="sidebar-menu">
                <li><a href="admin_panel.php?page=dashboard">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a></li>
                <li><a href="admin_user_management.php">
                    <i class="fas fa-users"></i> User Management
                </a></li>
                <li><a href="admin_post_management.php" class="active">
                    <i class="fas fa-file-alt"></i> Post Management
                </a></li>
                <li><a href="admin_analysis.php">
                    <i class="fas fa-chart-line"></i> Content Analysis
                </a></li>
                <li><a href="admin_panel.php?page=settings">
                    <i class="fas fa-cog"></i> Settings
                </a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>
                    <?php
                    if($action === 'view') {
                        echo "Post Details";
                    } else {
                        echo "Post Management";
                    }
                    ?>
                </h1>
                <div class="user-actions">
                    <a href="#" title="Notifications"><i class="fas fa-bell"></i></a>
                    <a href="#" title="Profile"><i class="fas fa-user-circle"></i> Admin</a>
                    <a href="admin_auth.php?logout=true" title="Logout"><i class="fas fa-sign-out-alt"></i></a>
                </div>
            </div>

            <?php if(!empty($success) && isset($messages[$success])): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?php echo $messages[$success]; ?>
                <span class="close">&times;</span>
            </div>
            <?php endif; ?>

            <?php if(!empty($error) && isset($messages[$error])): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i> <?php echo $messages[$error]; ?>
                <span class="close">&times;</span>
            </div>
            <?php endif; ?>
            
            <?php if(isset($debug_message) && !empty($debug_message)): ?>
            <div class="alert alert-warning">
                <i class="fas fa-exclamation-triangle"></i> <?php echo $debug_message; ?>
                <span class="close">&times;</span>
            </div>
            <?php endif; ?>

            <?php if($action === 'list'): ?>
            <!-- Post List View -->
            <div class="content-header">
                <div class="search-filter">
                    <form action="" method="GET" class="search-form">
                        <div class="search-input">
                            <input type="text" name="search" placeholder="Search posts..." value="<?php echo htmlspecialchars($search); ?>">
                            <button type="submit"><i class="fas fa-search"></i></button>
                        </div>
                        <div class="filter-options">
                            <select name="sort">
                                <option value="p.created_at" <?php echo $sortBy === 'p.created_at' ? 'selected' : ''; ?>>Date Posted</option>
                                <option value="like_count" <?php echo $sortBy === 'like_count' ? 'selected' : ''; ?>>Likes</option>
                                <option value="comment_count" <?php echo $sortBy === 'comment_count' ? 'selected' : ''; ?>>Comments</option>
                            </select>
                            <select name="order">
                                <option value="DESC" <?php echo $sortOrder === 'DESC' ? 'selected' : ''; ?>>Descending</option>
                                <option value="ASC" <?php echo $sortOrder === 'ASC' ? 'selected' : ''; ?>>Ascending</option>
                            </select>
                            <button type="submit" class="btn btn-sm">Apply</button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="content-body">
                <div class="posts-grid">
                    <?php if(count($posts) > 0): ?>
                        <?php foreach($posts as $post): ?>
                        <div class="post-card">
                            <div class="post-header">
                                <div class="user-info">
                                    <img src="<?php echo !empty($post['profile_picture']) ? '../' . $post['profile_picture'] : '../assets/default_profile.png'; ?>" alt="Profile">
                                    <div>
                                        <a href="admin_user_management.php?action=view&id=<?php echo $post['user_id']; ?>"><?php echo htmlspecialchars($post['username']); ?></a>
                                        <span class="post-date"><?php echo date('M d, Y', strtotime($post['created_at'])); ?></span>
                                    </div>
                                </div>
                                <?php if($post['featured']): ?>
                                <span class="featured-badge"><i class="fas fa-star"></i> Featured</span>
                                <?php endif; ?>
                            </div>
                            <div class="post-content">
                                <?php echo htmlspecialchars(substr($post['content'], 0, 150)) . (strlen($post['content']) > 150 ? '...' : ''); ?>
                            </div>
                            <?php if(!empty($post['media_id'])): ?>
                            <div class="post-media">
                                <?php
                                // Get media information using media_id
                                $mediaQuery = $conn->prepare("SELECT file_path, file_type FROM media WHERE id = ?");
                                $mediaQuery->bind_param("i", $post['media_id']);
                                $mediaQuery->execute();
                                $media = $mediaQuery->get_result()->fetch_assoc();
                                $mediaQuery->close();
                                
                                if($media && !empty($media['file_path'])):
                                    $mediaType = strtolower(pathinfo($media['file_path'], PATHINFO_EXTENSION));
                                    if(in_array($mediaType, ['jpg', 'jpeg', 'png', 'gif'])):
                                ?>
                                <img src="<?php echo '../' . $media['file_path']; ?>" alt="Post Image">
                                <?php elseif(in_array($mediaType, ['mp4', 'webm', 'ogg'])): ?>
                                <video controls>
                                    <source src="<?php echo '../' . $media['file_path']; ?>" type="video/<?php echo $mediaType; ?>">
                                    Your browser does not support the video tag.
                                </video>
                                <?php endif; endif; ?>
                            </div>
                            <?php endif; ?>
                            <div class="post-footer">
                                <div class="post-stats">
                                    <span><i class="fas fa-heart"></i> <?php echo $post['like_count']; ?></span>
                                    <span><i class="fas fa-comment"></i> <?php echo $post['comment_count']; ?></span>
                                </div>
                                <div class="post-actions">
                                    <a href="?action=view&id=<?php echo $post['id']; ?>" class="btn btn-sm btn-primary">
                                        <i class="fas fa-eye"></i> View
                                    </a>
                                    
                                    <?php if($post['featured']): ?>
                                    <form method="POST" class="d-inline">
                                        <input type="hidden" name="action" value="unfeature">
                                        <input type="hidden" name="post_id" value="<?php echo $post['id']; ?>">
                                        <button type="submit" class="btn btn-sm btn-warning">
                                            <i class="fas fa-star-half-alt"></i> Unfeature
                                        </button>
                                    </form>
                                    <?php else: ?>
                                    <form method="POST" class="d-inline">
                                        <input type="hidden" name="action" value="feature">
                                        <input type="hidden" name="post_id" value="<?php echo $post['id']; ?>">
                                        <button type="submit" class="btn btn-sm btn-success">
                                            <i class="fas fa-star"></i> Feature
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                    
                                    <form method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this post? This action cannot be undone!');">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="post_id" value="<?php echo $post['id']; ?>">
                                        <button type="submit" class="btn btn-sm btn-danger">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="no-content">
                            <i class="fas fa-file-alt"></i>
                            <p>No posts found</p>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Pagination -->
                <?php if($totalPages > 1): ?>
                <div class="pagination">
                    <?php if($page > 1): ?>
                        <a href="?page_num=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>&sort=<?php echo $sortBy; ?>&order=<?php echo $sortOrder; ?>" class="page-link">
                            <i class="fas fa-chevron-left"></i> Previous
                        </a>
                    <?php endif; ?>
                    
                    <?php
                    $startPage = max(1, $page - 2);
                    $endPage = min($totalPages, $page + 2);
                    
                    for($i = $startPage; $i <= $endPage; $i++): ?>
                        <a href="?page_num=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>&sort=<?php echo $sortBy; ?>&order=<?php echo $sortOrder; ?>" 
                           class="page-link <?php echo $i === $page ? 'active' : ''; ?>">
                            <?php echo $i; ?>
                        </a>
                    <?php endfor; ?>
                    
                    <?php if($page < $totalPages): ?>
                        <a href="?page_num=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>&sort=<?php echo $sortBy; ?>&order=<?php echo $sortOrder; ?>" class="page-link">
                            Next <i class="fas fa-chevron-right"></i>
                        </a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>

            <?php elseif($action === 'view' && $postDetails): ?>
            <!-- Post Detail View -->
            <div class="content-header">
                <div class="btn-group">
                    <a href="admin_post_management.php" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Back to Posts
                    </a>
                </div>
            </div>

            <div class="post-detail">
                <div class="post-card full">
                    <div class="post-header">
                        <div class="user-info">
                            <img src="<?php echo !empty($postDetails['profile_picture']) ? '../' . $postDetails['profile_picture'] : '../assets/default_profile.png'; ?>" alt="Profile">
                            <div>
                                <a href="admin_user_management.php?action=view&id=<?php echo $postDetails['user_id']; ?>"><?php echo htmlspecialchars($postDetails['username']); ?></a>
                                <span class="post-date"><?php echo date('M d, Y h:i A', strtotime($postDetails['created_at'])); ?></span>
                            </div>
                        </div>
                        <?php if($postDetails['featured']): ?>
                        <span class="featured-badge"><i class="fas fa-star"></i> Featured</span>
                        <?php endif; ?>
                    </div>
                    <div class="post-content">
                        <?php echo nl2br(htmlspecialchars($postDetails['content'])); ?>
                    </div>
                    
                    <?php if(!empty($postDetails['media_id'])): ?>
                    <div class="post-media">
                        <?php
                        // Get media information using media_id
                        $mediaQuery = $conn->prepare("SELECT file_path, file_type FROM media WHERE id = ?");
                        $mediaQuery->bind_param("i", $postDetails['media_id']);
                        $mediaQuery->execute();
                        $media = $mediaQuery->get_result()->fetch_assoc();
                        $mediaQuery->close();
                        
                        if($media && !empty($media['file_path'])):
                            $mediaType = strtolower(pathinfo($media['file_path'], PATHINFO_EXTENSION));
                            if(in_array($mediaType, ['jpg', 'jpeg', 'png', 'gif'])):
                        ?>
                        <img src="<?php echo '../' . $media['file_path']; ?>" alt="Post Image">
                        <?php elseif(in_array($mediaType, ['mp4', 'webm', 'ogg'])): ?>
                        <video controls>
                            <source src="<?php echo '../' . $media['file_path']; ?>" type="video/<?php echo $mediaType; ?>">
                            Your browser does not support the video tag.
                        </video>
                        <?php endif; endif; ?>
                    </div>
                    <?php endif; ?>
                    
                    <div class="post-stats full">
                        <div class="stat">
                            <i class="fas fa-heart"></i>
                            <span><?php echo $postDetails['like_count']; ?> Likes</span>
                        </div>
                        <div class="stat">
                            <i class="fas fa-comment"></i>
                            <span><?php echo $postDetails['comment_count']; ?> Comments</span>
                        </div>
                        <div class="stat">
                            <i class="fas fa-calendar"></i>
                            <span>Posted <?php echo date('M d, Y h:i A', strtotime($postDetails['created_at'])); ?></span>
                        </div>
                    </div>
                    
                    <div class="post-actions-bar">
                        <?php if($postDetails['featured']): ?>
                        <form method="POST">
                            <input type="hidden" name="action" value="unfeature">
                            <input type="hidden" name="post_id" value="<?php echo $postDetails['id']; ?>">
                            <button type="submit" class="btn btn-warning">
                                <i class="fas fa-star-half-alt"></i> Unfeature Post
                            </button>
                        </form>
                        <?php else: ?>
                        <form method="POST">
                            <input type="hidden" name="action" value="feature">
                            <input type="hidden" name="post_id" value="<?php echo $postDetails['id']; ?>">
                            <button type="submit" class="btn btn-success">
                                <i class="fas fa-star"></i> Feature Post
                            </button>
                        </form>
                        <?php endif; ?>
                        
                        <form method="POST" onsubmit="return confirm('Are you sure you want to delete this post? This action cannot be undone!');">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="post_id" value="<?php echo $postDetails['id']; ?>">
                            <button type="submit" class="btn btn-danger">
                                <i class="fas fa-trash"></i> Delete Post
                            </button>
                        </form>
                    </div>
                </div>
                
                <!-- Comments Section -->
                <div class="comments-section">
                    <h3><i class="fas fa-comments"></i> Comments (<?php echo count($postComments); ?>)</h3>
                    
                    <?php if(isset($debug_message) && !empty($debug_message)): ?>
                        <div class="alert alert-warning">
                            <i class="fas fa-exclamation-triangle"></i> <?php echo $debug_message; ?>
                        </div>
                    <?php endif; ?>
                    
                    <?php if(count($postComments) > 0): ?>
                        <div class="comments-list">
                            <?php foreach($postComments as $comment): ?>
                            <div class="comment">
                                <div class="comment-header">
                                    <div class="user-info">
                                        <img src="<?php echo !empty($comment['profile_picture']) ? '../' . $comment['profile_picture'] : '../assets/default_profile.png'; ?>" alt="Profile">
                                        <div>
                                            <a href="admin_user_management.php?action=view&id=<?php echo isset($comment['user_id']) ? $comment['user_id'] : 0; ?>"><?php echo htmlspecialchars($comment['username']); ?></a>
                                            <span class="comment-date"><?php echo date('M d, Y h:i A', strtotime($comment['created_at'])); ?></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="comment-content">
                                    <?php 
                                    if(isset($comment['comment_text'])) {
                                        echo nl2br(htmlspecialchars($comment['comment_text']));
                                    } elseif(isset($comment['text'])) {
                                        echo nl2br(htmlspecialchars($comment['text']));
                                    } elseif(isset($comment['content'])) {
                                        echo nl2br(htmlspecialchars($comment['content']));
                                    } else {
                                        echo '<em>No comment text available</em>';
                                    }
                                    ?>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="no-content">
                            <i class="fas fa-comment-slash"></i>
                            <p>No comments on this post.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
            // Close alerts
            $('.alert .close').on('click', function() {
                $(this).parent().fadeOut();
            });
            
            // Auto-fade alerts
            setTimeout(function() {
                $('.alert').fadeOut();
            }, 5000);
        });
    </script>
</body>
</html>
