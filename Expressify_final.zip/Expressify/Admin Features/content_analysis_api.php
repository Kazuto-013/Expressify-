<?php
require_once '../includes/session.php';
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'error' => 'Unauthorized access']);
    exit();
}

// Get parameters
$timeRange = $_GET['timeRange'] ?? '7days';
$contentType = $_GET['contentType'] ?? 'all';

// Calculate date range
$endDate = date('Y-m-d H:i:s');
$startDate = '';

switch ($timeRange) {
    case '24hours':
        $startDate = date('Y-m-d H:i:s', strtotime('-24 hours'));
        break;
    case '7days':
        $startDate = date('Y-m-d H:i:s', strtotime('-7 days'));
        break;
    case '30days':
        $startDate = date('Y-m-d H:i:s', strtotime('-30 days'));
        break;
    case '90days':
        $startDate = date('Y-m-d H:i:s', strtotime('-90 days'));
        break;
    default:
        $startDate = date('Y-m-d H:i:s', strtotime('-7 days'));
}

try {
    // Prepare base query conditions
    $conditions = ["ca.created_at BETWEEN ? AND ?"];
    $params = [$startDate, $endDate];
    $types = "ss";

    if ($contentType !== 'all') {
        $conditions[] = "ca.content_type = ?";
        $params[] = $contentType;
        $types .= "s";
    }

    $whereClause = implode(" AND ", $conditions);

    // Get overall metrics
    $metricsQuery = "SELECT 
        AVG(1 - toxicity_score) * 100 as safety_score,
        AVG(sentiment_score) * 100 as sentiment_score,
        AVG(quality_score) * 100 as quality_score,
        AVG(readability_score) * 100 as readability_score
    FROM content_analysis ca
    WHERE $whereClause";

    $stmt = $conn->prepare($metricsQuery);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $metricsResult = $stmt->get_result()->fetch_assoc();

    // Get previous period metrics for trend calculation
    $prevStartDate = date('Y-m-d H:i:s', strtotime($startDate . ' -' . str_replace('days', ' days', $timeRange)));
    $prevEndDate = $startDate;

    $prevConditions = ["ca.created_at BETWEEN ? AND ?"];
    $prevParams = [$prevStartDate, $prevEndDate];
    $prevTypes = "ss";

    if ($contentType !== 'all') {
        $prevConditions[] = "ca.content_type = ?";
        $prevParams[] = $contentType;
        $prevTypes .= "s";
    }

    $prevWhereClause = implode(" AND ", $prevConditions);

    $prevMetricsQuery = "SELECT 
        AVG(1 - toxicity_score) * 100 as safety_score,
        AVG(sentiment_score) * 100 as sentiment_score,
        AVG(quality_score) * 100 as quality_score
    FROM content_analysis ca
    WHERE $prevWhereClause";

    $stmt = $conn->prepare($prevMetricsQuery);
    $stmt->bind_param($prevTypes, ...$prevParams);
    $stmt->execute();
    $prevMetricsResult = $stmt->get_result()->fetch_assoc();

    // Calculate trends
    $trends = [
        'safety' => round(($metricsResult['safety_score'] - $prevMetricsResult['safety_score']), 1),
        'sentiment' => round(($metricsResult['sentiment_score'] - $prevMetricsResult['sentiment_score']), 1),
        'quality' => round(($metricsResult['quality_score'] - $prevMetricsResult['quality_score']), 1)
    ];

    // Get trend data
    $trendQuery = "SELECT 
        DATE(created_at) as date,
        AVG(toxicity_score) as toxicity,
        AVG(sentiment_score) as sentiment,
        AVG(quality_score) as quality
    FROM content_analysis ca
    WHERE $whereClause
    GROUP BY DATE(created_at)
    ORDER BY date ASC";

    $stmt = $conn->prepare($trendQuery);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $trendResult = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    // Get sentiment distribution
    $sentimentQuery = "SELECT 
        CASE 
            WHEN sentiment_score < 0.2 THEN 'Very Negative'
            WHEN sentiment_score < 0.4 THEN 'Negative'
            WHEN sentiment_score < 0.6 THEN 'Neutral'
            WHEN sentiment_score < 0.8 THEN 'Positive'
            ELSE 'Very Positive'
        END as sentiment_category,
        COUNT(*) as count
    FROM content_analysis ca
    WHERE $whereClause
    GROUP BY sentiment_category
    ORDER BY sentiment_category";

    $stmt = $conn->prepare($sentimentQuery);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $sentimentResult = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    // Get content type stats
    $contentTypeQuery = "SELECT 
        content_type,
        AVG(toxicity_score) as avg_toxicity,
        AVG(sentiment_score) as avg_sentiment
    FROM content_analysis ca
    WHERE $whereClause
    GROUP BY content_type";

    $stmt = $conn->prepare($contentTypeQuery);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $contentTypeResult = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    // Prepare response
    $response = [
        'success' => true,
        'metrics' => [
            'safety_score' => round($metricsResult['safety_score'], 1),
            'sentiment_score' => round($metricsResult['sentiment_score'], 1),
            'quality_score' => round($metricsResult['quality_score'], 1),
            'readability_score' => round($metricsResult['readability_score'], 1)
        ],
        'trends' => $trends,
        'trend_data' => $trendResult,
        'sentiment_distribution' => $sentimentResult,
        'content_type_stats' => $contentTypeResult
    ];

    header('Content-Type: application/json');
    echo json_encode($response);

} catch (Exception $e) {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'error' => 'An error occurred while fetching the data: ' . $e->getMessage()
    ]);
} 