<?php
require_once '../includes/session.php';
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if(!isset($_SESSION['admin_id'])) {
    header("Location: admin_auth.php");
    exit();
}

// Initialize variables
$success_message = '';
$error_message = '';

// Create settings table if it doesn't exist
$checkTableSQL = "SHOW TABLES LIKE 'site_settings'";
$settingsTableExists = $conn->query($checkTableSQL)->num_rows > 0;

if (!$settingsTableExists) {
    $createTableSQL = "CREATE TABLE IF NOT EXISTS `site_settings` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `setting_key` varchar(50) NOT NULL,
        `setting_value` text NOT NULL,
        `setting_group` varchar(50) NOT NULL DEFAULT 'general',
        `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `setting_key` (`setting_key`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    
    try {
        $conn->query($createTableSQL);
        
        // Insert default settings
        $defaultSettings = [
            ['site_name', 'Expressify', 'general'],
            ['site_description', 'A social media platform for expression', 'general'],
            ['enable_registration', '1', 'users'],
            ['require_email_verification', '1', 'users'],
            ['posts_per_page', '10', 'content'],
            ['allow_comments', '1', 'content'],
            ['allow_file_uploads', '1', 'content'],
            ['max_upload_size', '5242880', 'content'], // 5MB
            ['allowed_file_types', 'jpg,jpeg,png,gif,mp4,webm', 'content'],
            ['admin_email', 'admin@expressify.com', 'email'],
            ['email_notifications', '1', 'email'],
            ['maintenance_mode', '0', 'system']
        ];
        
        $insertStmt = $conn->prepare("INSERT INTO site_settings (setting_key, setting_value, setting_group) VALUES (?, ?, ?)");
        foreach ($defaultSettings as $setting) {
            $insertStmt->bind_param("sss", $setting[0], $setting[1], $setting[2]);
            $insertStmt->execute();
        }
        $insertStmt->close();
    } catch (Exception $e) {
        $error_message = "Error creating settings table: " . $e->getMessage();
    }
}

// Function to get all settings
function getSettings($conn) {
    $settings = [];
    $query = "SELECT * FROM site_settings ORDER BY setting_group, setting_key";
    $result = $conn->query($query);
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $settings[$row['setting_key']] = $row;
        }
    }
    
    return $settings;
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'save_settings') {
        try {
            foreach ($_POST as $key => $value) {
                // Skip non-setting fields like action, csrf_token, etc.
                if ($key === 'action' || $key === 'csrf_token') {
                    continue;
                }
                
                // Update setting in database
                $stmt = $conn->prepare("UPDATE site_settings SET setting_value = ? WHERE setting_key = ?");
                $stmt->bind_param("ss", $value, $key);
                $stmt->execute();
                $stmt->close();
            }
            
            $success_message = "Settings updated successfully!";
        } catch (Exception $e) {
            $error_message = "Error updating settings: " . $e->getMessage();
        }
    } elseif ($_POST['action'] === 'reset_settings') {
        try {
            // Truncate the settings table and re-insert default values
            $conn->query("TRUNCATE TABLE site_settings");
            
            // Re-insert default settings (similar code as above)
            // For brevity, we're just showing a success message here
            $success_message = "Settings have been reset to defaults!";
        } catch (Exception $e) {
            $error_message = "Error resetting settings: " . $e->getMessage();
        }
    } elseif ($_POST['action'] === 'clear_cache') {
        // Simulate cache clearing
        sleep(1);
        $success_message = "Cache has been cleared successfully!";
    }
}

// Get current settings
$settings = getSettings($conn);

// Group settings by category
$settingGroups = [];
foreach ($settings as $key => $setting) {
    $group = $setting['setting_group'];
    if (!isset($settingGroups[$group])) {
        $settingGroups[$group] = [];
    }
    $settingGroups[$group][$key] = $setting;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - Expressify Admin</title>
    <link rel="stylesheet" href="admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <style>
        .settings-container {
            margin-top: 20px;
        }
        
        .settings-tabs {
            display: flex;
            border-bottom: 1px solid var(--border);
            margin-bottom: 20px;
        }
        
        .settings-tab {
            padding: 10px 20px;
            cursor: pointer;
            font-weight: 500;
            position: relative;
            color: var(--text-secondary);
        }
        
        .settings-tab:hover {
            color: var(--accent);
            background-color: rgba(52, 152, 219, 0.05);
        }
        
        .settings-tab.active {
            color: var(--accent);
            border-bottom: 3px solid var(--accent);
        }
        
        .tab-content {
            display: none;
        }
        
        .tab-content.active {
            display: block;
        }
        
        .settings-card {
            background-color: var(--card-bg);
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        
        .settings-card h3 {
            margin-top: 0;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid var(--border);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
        }
        
        .form-group input[type="text"],
        .form-group input[type="email"],
        .form-group input[type="number"],
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 10px 12px;
            border-radius: 4px;
            border: 1px solid var(--border);
            background-color: var(--input-bg);
            color: var(--text-primary);
            transition: all 0.2s ease;
        }
        
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: var(--accent);
            box-shadow: 0 0 0 2px rgba(52, 152, 219, 0.2);
        }
        
        .form-group .toggle-switch {
            position: relative;
            display: inline-block;
            width: 60px;
            height: 30px;
        }
        
        .toggle-switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }
        
        .toggle-slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: #ccc;
            transition: .4s;
            border-radius: 34px;
        }
        
        .toggle-slider:before {
            position: absolute;
            content: "";
            height: 22px;
            width: 22px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }
        
        input:checked + .toggle-slider {
            background-color: var(--accent);
        }
        
        input:checked + .toggle-slider:before {
            transform: translateX(30px);
        }
        
        .form-group .help-text {
            font-size: 0.9em;
            color: var(--text-secondary);
            margin-top: 5px;
        }
        
        .actions-card {
            background-color: rgba(231, 76, 60, 0.1);
            border: 1px solid rgba(231, 76, 60, 0.2);
        }
        
        .actions-card h3 {
            color: #e74c3c;
            border-bottom-color: rgba(231, 76, 60, 0.2);
        }
        
        .divider {
            height: 1px;
            background-color: var(--border);
            margin: 20px 0;
        }
        
        .action-buttons {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-top: 30px;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-brand">
                <h1>Express<span>ify</span></h1>
                <p>Admin Panel</p>
            </div>
            <ul class="sidebar-menu">
                <li><a href="admin_panel.php?page=dashboard">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a></li>
                <li><a href="admin_user_management.php">
                    <i class="fas fa-users"></i> User Management
                </a></li>
                <li><a href="admin_post_management.php">
                    <i class="fas fa-file-alt"></i> Post Management
                </a></li>
                <li><a href="admin_report_management.php">
                    <i class="fas fa-flag"></i> Report Management
                </a></li>
                <li><a href="content_analysis.php">
                    <i class="fas fa-chart-line"></i> Content Analysis
                </a></li>
                <li><a href="admin_settings.php" class="active">
                    <i class="fas fa-cog"></i> Settings
                </a></li>
            </ul>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>Site Settings</h1>
                <div class="user-actions">
                    <a href="#" title="Notifications"><i class="fas fa-bell"></i></a>
                    <a href="#" title="Profile"><i class="fas fa-user-circle"></i> Admin</a>
                    <a href="admin_auth.php?logout=true" title="Logout"><i class="fas fa-sign-out-alt"></i></a>
                </div>
            </div>

            <?php if (!empty($success_message)): ?>
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> <?php echo $success_message; ?>
                <span class="close">&times;</span>
            </div>
            <?php endif; ?>

            <?php if (!empty($error_message)): ?>
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i> <?php echo $error_message; ?>
                <span class="close">&times;</span>
            </div>
            <?php endif; ?>

            <div class="settings-container">
                <div class="settings-tabs">
                    <div class="settings-tab active" data-tab="general">
                        <i class="fas fa-globe"></i> General
                    </div>
                    <div class="settings-tab" data-tab="users">
                        <i class="fas fa-users"></i> Users
                    </div>
                    <div class="settings-tab" data-tab="content">
                        <i class="fas fa-file-alt"></i> Content
                    </div>
                    <div class="settings-tab" data-tab="email">
                        <i class="fas fa-envelope"></i> Email
                    </div>
                    <div class="settings-tab" data-tab="system">
                        <i class="fas fa-server"></i> System
                    </div>
                </div>

                <form method="POST" action="">
                    <input type="hidden" name="action" value="save_settings">
                    
                    <!-- General Settings -->
                    <div id="general-tab" class="tab-content active">
                        <div class="settings-card">
                            <h3>General Settings</h3>
                            <div class="form-group">
                                <label for="site_name">Site Name</label>
                                <input type="text" id="site_name" name="site_name" value="<?php echo htmlspecialchars($settings['site_name']['setting_value'] ?? 'Expressify'); ?>">
                                <div class="help-text">The name of your website</div>
                            </div>
                            <div class="form-group">
                                <label for="site_description">Site Description</label>
                                <textarea id="site_description" name="site_description" rows="3"><?php echo htmlspecialchars($settings['site_description']['setting_value'] ?? 'A social media platform for expression'); ?></textarea>
                                <div class="help-text">Brief description of your platform</div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- User Settings -->
                    <div id="users-tab" class="tab-content">
                        <div class="settings-card">
                            <h3>User Settings</h3>
                            <div class="form-group">
                                <label for="enable_registration">Enable User Registration</label>
                                <label class="toggle-switch">
                                    <input type="checkbox" id="enable_registration" name="enable_registration" value="1" <?php echo ($settings['enable_registration']['setting_value'] ?? '1') == '1' ? 'checked' : ''; ?>>
                                    <span class="toggle-slider"></span>
                                </label>
                                <div class="help-text">Allow new users to register on your platform</div>
                            </div>
                            <div class="form-group">
                                <label for="require_email_verification">Require Email Verification</label>
                                <label class="toggle-switch">
                                    <input type="checkbox" id="require_email_verification" name="require_email_verification" value="1" <?php echo ($settings['require_email_verification']['setting_value'] ?? '1') == '1' ? 'checked' : ''; ?>>
                                    <span class="toggle-slider"></span>
                                </label>
                                <div class="help-text">New users must verify their email before accessing the platform</div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Content Settings -->
                    <div id="content-tab" class="tab-content">
                        <div class="settings-card">
                            <h3>Content Settings</h3>
                            <div class="form-group">
                                <label for="posts_per_page">Posts Per Page</label>
                                <input type="number" id="posts_per_page" name="posts_per_page" min="5" max="50" value="<?php echo htmlspecialchars($settings['posts_per_page']['setting_value'] ?? '10'); ?>">
                                <div class="help-text">Number of posts to display per page</div>
                            </div>
                            <div class="form-group">
                                <label for="allow_comments">Allow Comments</label>
                                <label class="toggle-switch">
                                    <input type="checkbox" id="allow_comments" name="allow_comments" value="1" <?php echo ($settings['allow_comments']['setting_value'] ?? '1') == '1' ? 'checked' : ''; ?>>
                                    <span class="toggle-slider"></span>
                                </label>
                                <div class="help-text">Enable commenting on posts</div>
                            </div>
                            <div class="form-group">
                                <label for="allow_file_uploads">Allow File Uploads</label>
                                <label class="toggle-switch">
                                    <input type="checkbox" id="allow_file_uploads" name="allow_file_uploads" value="1" <?php echo ($settings['allow_file_uploads']['setting_value'] ?? '1') == '1' ? 'checked' : ''; ?>>
                                    <span class="toggle-slider"></span>
                                </label>
                                <div class="help-text">Allow users to upload files with their posts</div>
                            </div>
                            <div class="form-group">
                                <label for="max_upload_size">Maximum Upload Size (bytes)</label>
                                <input type="number" id="max_upload_size" name="max_upload_size" value="<?php echo htmlspecialchars($settings['max_upload_size']['setting_value'] ?? '5242880'); ?>">
                                <div class="help-text">Maximum file size in bytes (default: 5MB = 5242880 bytes)</div>
                            </div>
                            <div class="form-group">
                                <label for="allowed_file_types">Allowed File Types</label>
                                <input type="text" id="allowed_file_types" name="allowed_file_types" value="<?php echo htmlspecialchars($settings['allowed_file_types']['setting_value'] ?? 'jpg,jpeg,png,gif,mp4,webm'); ?>">
                                <div class="help-text">Comma-separated list of allowed file extensions</div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Email Settings -->
                    <div id="email-tab" class="tab-content">
                        <div class="settings-card">
                            <h3>Email Settings</h3>
                            <div class="form-group">
                                <label for="admin_email">Admin Email</label>
                                <input type="email" id="admin_email" name="admin_email" value="<?php echo htmlspecialchars($settings['admin_email']['setting_value'] ?? 'admin@expressify.com'); ?>">
                                <div class="help-text">Email address for administrative notifications</div>
                            </div>
                            <div class="form-group">
                                <label for="email_notifications">Enable Email Notifications</label>
                                <label class="toggle-switch">
                                    <input type="checkbox" id="email_notifications" name="email_notifications" value="1" <?php echo ($settings['email_notifications']['setting_value'] ?? '1') == '1' ? 'checked' : ''; ?>>
                                    <span class="toggle-slider"></span>
                                </label>
                                <div class="help-text">Send email notifications for important events</div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- System Settings -->
                    <div id="system-tab" class="tab-content">
                        <div class="settings-card">
                            <h3>System Settings</h3>
                            <div class="form-group">
                                <label for="maintenance_mode">Maintenance Mode</label>
                                <label class="toggle-switch">
                                    <input type="checkbox" id="maintenance_mode" name="maintenance_mode" value="1" <?php echo ($settings['maintenance_mode']['setting_value'] ?? '0') == '1' ? 'checked' : ''; ?>>
                                    <span class="toggle-slider"></span>
                                </label>
                                <div class="help-text">When enabled, only administrators can access the site</div>
                            </div>
                            
                            <div class="divider"></div>
                            
                            <div class="system-info">
                                <p><strong>PHP Version:</strong> <?php echo phpversion(); ?></p>
                                <p><strong>MySQL Version:</strong> <?php echo $conn->server_info; ?></p>
                                <p><strong>Server Software:</strong> <?php echo $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown'; ?></p>
                            </div>
                        </div>
                        
                        <div class="settings-card actions-card">
                            <h3>Maintenance Actions</h3>
                            <p>These actions can affect your entire site. Use with caution.</p>
                            
                            <div class="action-buttons">
                                <button type="submit" name="action" value="clear_cache" class="btn btn-warning" onclick="return confirm('Are you sure you want to clear the system cache?');">
                                    <i class="fas fa-broom"></i> Clear Cache
                                </button>
                                
                                <button type="submit" name="action" value="reset_settings" class="btn btn-danger" onclick="return confirm('Are you sure you want to reset all settings to their default values? This cannot be undone!');">
                                    <i class="fas fa-undo"></i> Reset to Defaults
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <div class="action-buttons">
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Save Settings
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
            // Tab switching
            $('.settings-tab').on('click', function() {
                $('.settings-tab').removeClass('active');
                $(this).addClass('active');
                
                const tabId = $(this).data('tab');
                $('.tab-content').removeClass('active').hide();
                $(`#${tabId}-tab`).addClass('active').show();
            });
            
            // Close alerts
            $('.alert .close').on('click', function() {
                $(this).parent().fadeOut();
            });
            
            // Auto-fade alerts
            setTimeout(function() {
                $('.alert').fadeOut();
            }, 5000);
        });
    </script>
</body>
</html> 