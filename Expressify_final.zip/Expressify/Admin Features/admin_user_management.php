<?php
// Error handling for development 
ini_set('display_errors', 0);  // Set to 0 for production
error_reporting(E_ALL);

require_once '../includes/session.php';
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if(!isset($_SESSION['admin_id'])) {
    header("Location: admin_auth.php");
    exit();
}

// Function to safely get array values
function safe_get($array, $key, $default = '') {
    return isset($array[$key]) ? $array[$key] : $default;
}

// Helper function to ensure user array has all required fields
function ensure_user_fields($user) {
    $defaults = [
        'id' => 0,
        'username' => 'Unknown',
        'email' => 'No email',
        'profile_picture' => '',
        'status' => 'inactive',
        'created_at' => date('Y-m-d H:i:s'),
        'post_count' => 0,
        'follower_count' => 0,
        'following_count' => 0,
        'friends_count' => 0
    ];
    
    return array_merge($defaults, $user);
}

// Initialize all variables at the top
$total = 0;
$total_pages = 1;
$start_page = 1;
$end_page = 1;
$tableExists = false;
$query_string = '';
$debugInfo = [];
$userDetails = null;
$userPosts = [];
$userFriends = [];
$users = [];
$sortColumn = 'created_at';
$sortAlias = 'created_at';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$limit = 10;
$offset = ($page - 1) * $limit;
$action = isset($_GET['action']) ? $_GET['action'] : 'list';
$userId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$success = isset($_GET['success']) ? $_GET['success'] : '';
$error = isset($_GET['error']) ? $_GET['error'] : '';
$search = isset($_GET['search']) ? $_GET['search'] : '';
$filterStatus = isset($_GET['status']) ? $_GET['status'] : '';
$sortBy = isset($_GET['sort']) ? $_GET['sort'] : 'created_at';
$sortOrder = isset($_GET['order']) ? $_GET['order'] : 'DESC';

// Initialize user_id from GET parameters or session
$user_id = isset($_GET['id']) ? (int)$_GET['id'] : (isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null);

// Build query string for pagination links
if(!empty($search)) {
    $query_string .= '&search=' . urlencode($search);
}
if(!empty($filterStatus)) {
    $query_string .= '&status=' . urlencode($filterStatus);
}
if(!empty($sortBy)) {
    $query_string .= '&sort=' . urlencode($sortBy);
}
if(!empty($sortOrder)) {
    $query_string .= '&order=' . urlencode($sortOrder);
}

// Make sure page is at least 1
if($page < 1) $page = 1;

// Success and error messages
$messages = [
    'user_updated' => 'User has been successfully updated',
    'user_banned' => 'User has been successfully banned',
    'user_activated' => 'User has been successfully activated',
    'user_deleted' => 'User has been successfully deleted',
    'update_failed' => 'Failed to update user',
    'ban_failed' => 'Failed to ban user',
    'activate_failed' => 'Failed to activate user',
    'delete_failed' => 'Failed to delete user',
    'not_found' => 'User not found'
];

// Error and success message handling
$errorMessages = [
    'update_failed' => 'Failed to update user information.',
    'ban_failed' => 'Failed to ban user.',
    'activate_failed' => 'Failed to activate user.',
    'delete_failed' => 'Failed to delete user.',
    'not_found' => 'User not found.'
];

// Handle user actions (ban, delete, etc.)
if(isset($_POST['action'])) {
    switch($_POST['action']) {
        case 'update':
            if(isset($_POST['user_id']) && !empty($_POST['email']) && !empty($_POST['username'])) {
                $updateId = (int)$_POST['user_id'];
                $email = $_POST['email'];
                $username = $_POST['username'];
                $bio = $_POST['bio'] ?? '';
                $status = $_POST['status'] ?? 'active';
                $private = isset($_POST['private_account']) ? 1 : 0;
                $show_activity = isset($_POST['show_activity']) ? 1 : 0;
                
                $stmt = $conn->prepare("UPDATE users SET email = ?, username = ?, bio = ?, status = ?, private_account = ?, show_activity = ? WHERE id = ?");
                $stmt->bind_param("ssssiis", $email, $username, $bio, $status, $private, $show_activity, $updateId);
                
                if($stmt->execute()) {
                    header("Location: admin_user_management.php?success=user_updated");
                } else {
                    header("Location: admin_user_management.php?error=update_failed");
                }
                exit();
            }
            break;
            
        case 'ban':
            if(isset($_POST['user_id'])) {
                $banId = (int)$_POST['user_id'];
                $stmt = $conn->prepare("UPDATE users SET status = 'banned' WHERE id = ?");
                $stmt->bind_param("i", $banId);
                
                if($stmt->execute()) {
                    header("Location: admin_user_management.php?success=user_banned");
                } else {
                    header("Location: admin_user_management.php?error=ban_failed");
                }
                exit();
            }
            break;
            
        case 'activate':
            if(isset($_POST['user_id'])) {
                $activateId = (int)$_POST['user_id'];
                $stmt = $conn->prepare("UPDATE users SET status = 'active' WHERE id = ?");
                $stmt->bind_param("i", $activateId);
                
                if($stmt->execute()) {
                    header("Location: admin_user_management.php?success=user_activated");
                } else {
                    header("Location: admin_user_management.php?error=activate_failed");
                }
                exit();
            }
            break;
            
        case 'delete':
            if(isset($_POST['user_id'])) {
                try {
                    $conn->begin_transaction();
                    
                    $deleteId = (int)$_POST['user_id'];
                    
                    // First, backup user data to deleted_users table
                    $insertStmt = $conn->prepare("INSERT INTO deleted_users (user_id, deleted_at) VALUES (?, NOW())");
                    $insertStmt->bind_param("i", $deleteId);
                    $insertStmt->execute();
                    
                    // Update user status to 'deleted' instead of actually deleting
                    $updateStmt = $conn->prepare("UPDATE users SET status = 'deleted', email = CONCAT(email, '_deleted_', id), username = CONCAT(username, '_deleted_', id) WHERE id = ?");
                    $updateStmt->bind_param("i", $deleteId);
                    
                    if($updateStmt->execute()) {
                        // Kill any active sessions for this user
                        $sessionPath = session_save_path();
                        if ($sessionPath) {
                            foreach (glob($sessionPath . "/sess_*") as $file) {
                                $sessionData = file_get_contents($file);
                                if (strpos($sessionData, 'user_id|i:' . $deleteId . ';') !== false) {
                                    unlink($file);
                                }
                            }
                        }
                        
                        $conn->commit();
                        header("Location: admin_user_management.php?success=user_deleted");
                    } else {
                        throw new Exception("Failed to update user status");
                    }
                } catch (Exception $e) {
                    $conn->rollback();
                    header("Location: admin_user_management.php?error=delete_failed");
                }
                exit();
            }
            break;
    }
}

// Check if friends table exists and create it with proper structure
$checkFriendsTable = "SHOW TABLES LIKE 'friends'";
$result = $conn->query($checkFriendsTable);

if ($result->num_rows == 0) {
    $createFriendsTable = "CREATE TABLE friends (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        friend_id INT NOT NULL,
        status ENUM('pending', 'accepted', 'rejected') NOT NULL DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (friend_id) REFERENCES users(id) ON DELETE CASCADE,
        UNIQUE KEY unique_friendship (user_id, friend_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci";
    
    try {
        if (!$conn->query($createFriendsTable)) {
            throw new Exception("Error creating friends table: " . $conn->error);
        }
        $tableExists = true;
    } catch (Exception $e) {
        $tableExists = false;
        error_log("Error creating friends table: " . $e->getMessage());
    }
}

// Check and update users table structure
$checkUsersTable = "SHOW CREATE TABLE users";
$result = $conn->query($checkUsersTable);
if ($result) {
    $tableInfo = $result->fetch_assoc();
    if (!strpos($tableInfo['Create Table'], "status enum('active','inactive','banned','deleted')")) {
        // Update the status column to support all required states
        $alterStatusQuery = "ALTER TABLE users MODIFY COLUMN status ENUM('active', 'inactive', 'banned', 'deleted') DEFAULT 'active'";
        try {
            $conn->query($alterStatusQuery);
        } catch (Exception $e) {
            error_log("Failed to update users table status column: " . $e->getMessage());
        }
    }
}

// Initialize parameters
$whereClause = [];
$params = [];
$types = "";

// Add search parameters if search is provided
if (!empty($search)) {
    $searchTerm = "%$search%";
    $whereClause[] = "(u.username LIKE ? OR u.email LIKE ?)";
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $types .= "ss";
}

// Add status filter if provided
if (!empty($filterStatus)) {
    $whereClause[] = "u.status = ?";
    $params[] = $filterStatus;
    $types .= "s";
}

// Add pagination parameters
$params[] = $limit;
$params[] = $offset;
$types .= "ii";

// Get users with their post counts and friend counts
$query = "
    SELECT 
        u.id,
        u.username,
        u.email,
        u.profile_picture,
        u.status,
        u.created_at,
        COUNT(DISTINCT p.id) as post_count,
        COUNT(DISTINCT CASE 
            WHEN fr.status = 'accepted' THEN 
                CASE 
                    WHEN fr.sender_id = u.id THEN fr.receiver_id
                    WHEN fr.receiver_id = u.id THEN fr.sender_id
                END
        END) as friend_count
    FROM users u
    LEFT JOIN posts p ON u.id = p.user_id
    LEFT JOIN friend_requests fr ON (fr.sender_id = u.id OR fr.receiver_id = u.id)
    " . (!empty($whereClause) ? "WHERE " . implode(" AND ", $whereClause) : "") . "
    GROUP BY u.id
    ORDER BY " . $sortBy . " " . $sortOrder . "
    LIMIT ? OFFSET ?
";

// Prepare and execute the query
$stmt = $conn->prepare($query);
if ($stmt === false) {
    die('Error preparing statement: ' . $conn->error);
}

// Bind parameters if we have any
if (!empty($params)) {
    if (!$stmt->bind_param($types, ...$params)) {
        die('Error binding parameters: ' . $stmt->error);
    }
}

if (!$stmt->execute()) {
    die('Error executing statement: ' . $stmt->error);
}

$result = $stmt->get_result();
$users = [];
while ($row = $result->fetch_assoc()) {
    $users[] = ensure_user_fields($row);
}

// Get total count for pagination
$countQuery = "
    SELECT COUNT(*) as total 
    FROM users u 
    " . (!empty($whereClause) ? "WHERE " . implode(" AND ", $whereClause) : "");

$countStmt = $conn->prepare($countQuery);
if ($countStmt === false) {
    die('Error preparing count statement: ' . $conn->error);
}

// For count query, remove the last two parameters (limit and offset)
if (!empty($params)) {
    $countParams = array_slice($params, 0, -2);
    $countTypes = substr($types, 0, -2);
    if (!empty($countParams)) {
        if (!$countStmt->bind_param($countTypes, ...$countParams)) {
            die('Error binding count parameters: ' . $countStmt->error);
        }
    }
}

if (!$countStmt->execute()) {
    die('Error executing count statement: ' . $countStmt->error);
}

$totalUsers = $countStmt->get_result()->fetch_assoc()['total'];
$total_pages = ceil($totalUsers / $limit);

// Calculate pagination range
$start_page = max(1, $page - 2);
$end_page = min($total_pages, $page + 2);

// Get user details if viewing a specific user
if(isset($_GET['view']) && !empty($_GET['view'])) {
    $userId = (int)$_GET['view'];
    
    try {
        if ($tableExists) {
            $stmt = $conn->prepare("
                SELECT u.*, 
                       (SELECT COUNT(*) FROM posts WHERE user_id = u.id) as post_count,
                       (SELECT COUNT(*) FROM friends WHERE (user_id1 = u.id OR user_id2 = u.id) AND status = 'accepted') as friends_count,
                       (SELECT COUNT(*) FROM friends WHERE (user_id1 = u.id OR user_id2 = u.id) AND status = 'pending') as pending_friends_count
                FROM users u
                WHERE u.id = ?
            ");
        } else {
            // Fallback if friends table doesn't exist
            $stmt = $conn->prepare("
                SELECT u.*, 
                       (SELECT COUNT(*) FROM posts WHERE user_id = u.id) as post_count,
                       0 as friends_count,
                       0 as pending_friends_count
                FROM users u
                WHERE u.id = ?
            ");
        }
        
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $userDetails = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        
        if(!$userDetails) {
            header("Location: admin_user_management.php?error=not_found");
            exit();
        }
        
        // Get user's posts
        $stmt = $conn->prepare("
            SELECT id, content, created_at, likes_count, comments_count, status 
            FROM posts 
            WHERE user_id = ? 
            ORDER BY created_at DESC 
            LIMIT 10
        ");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $userPosts = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        
        // Get user's friends if the table exists
        if ($tableExists) {
            $stmt = $conn->prepare("
                SELECT 
                    CASE 
                        WHEN f.user_id1 = ? THEN u2.id
                        ELSE u1.id
                    END as friend_id,
                    CASE 
                        WHEN f.user_id1 = ? THEN u2.username
                        ELSE u1.username
                    END as username,
                    CASE 
                        WHEN f.user_id1 = ? THEN u2.email
                        ELSE u1.email
                    END as email,
                    CASE 
                        WHEN f.user_id1 = ? THEN u2.profile_picture
                        ELSE u1.profile_picture
                    END as profile_picture,
                    f.status
                FROM friends f
                JOIN users u1 ON f.user_id1 = u1.id
                JOIN users u2 ON f.user_id2 = u2.id
                WHERE (f.user_id1 = ? OR f.user_id2 = ?) AND f.status = 'accepted'
                LIMIT 10
            ");
            $stmt->bind_param("iiiiii", $userId, $userId, $userId, $userId, $userId, $userId);
            $stmt->execute();
            $userFriends = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $stmt->close();
        }
    } catch (Exception $e) {
        // Log error
        $debugInfo['user_query_error'] = $e->getMessage();
    }
}

// Helper functions
function formatCreatedAt($date) {
    $timestamp = strtotime($date);
    return date('M j, Y', $timestamp);
}

function getStatusBadgeClass($status) {
    switch($status) {
        case 'active':
            return 'badge-success';
        case 'inactive':
            return 'badge-warning';
        case 'banned':
            return 'badge-danger';
        default:
            return 'badge-secondary';
    }
}

function truncateText($text, $length = 100) {
    if(strlen($text) <= $length) {
        return $text;
    }
    return substr($text, 0, $length) . '...';
}

// Display error messages
if(isset($_GET['error']) && isset($errorMessages[$_GET['error']])) {
    echo '<div class="error-message"><i class="fas fa-exclamation-circle error-icon"></i>' . $errorMessages[$_GET['error']] . '</div>';
}

// Display success messages
if(isset($_GET['success']) && isset($messages[$_GET['success']])) {
    echo '<div class="alert alert-success"><i class="fas fa-check-circle"></i> ' . $messages[$_GET['success']] . '</div>';
}

// Display empty state for no users found
if(!isset($_GET['view']) && !isset($_GET['action']) && empty($users)) {
    echo '<div class="empty-state-container">
            <div class="empty-state">
                <i class="fas fa-users"></i>
                <h3>No Users Found</h3>
                <p>There are no users matching your criteria. Try adjusting your filters or creating new users.</p>
                <div class="empty-state-actions">
                    <a href="admin_user_management.php" class="btn btn-outline">
                        <i class="fas fa-redo"></i> Reset Filters
                    </a>
                </div>
            </div>
          </div>';
}

// Check if deleted_users table exists
$checkDeletedUsersSQL = "SHOW TABLES LIKE 'deleted_users'";
$deletedUsersTableExists = $conn->query($checkDeletedUsersSQL)->num_rows > 0;

if (!$deletedUsersTableExists) {
    $createDeletedUsersSQL = "CREATE TABLE IF NOT EXISTS `deleted_users` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `user_id` int(11) NOT NULL,
        `deleted_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `user_id` (`user_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
    
    try {
        $conn->query($createDeletedUsersSQL);
    } catch (Exception $e) {
        error_log("Failed to create deleted_users table: " . $e->getMessage());
    }
}

// Only get friend counts if we have a valid user_id
if ($user_id) {
    // Get friend count
    $friendCountQuery = "SELECT COUNT(*) as friend_count 
                        FROM friend_requests 
                        WHERE status = 'accepted' AND (sender_id = ? OR receiver_id = ?)";
    $friendStmt = $conn->prepare($friendCountQuery);
    $friendStmt->bind_param("ii", $user_id, $user_id);
    $friendStmt->execute();
    $friendResult = $friendStmt->get_result();
    $friendCount = $friendResult->fetch_assoc()['friend_count'];

    // Get mutual friends count if viewing another user's profile
    $mutualFriendsCount = 0;
    if ($user_id !== $_SESSION['user_id']) {
        $mutualQuery = "SELECT COUNT(*) as mutual_count
                       FROM (
                           SELECT IF(sender_id = ?, receiver_id, sender_id) as friend_id
                           FROM friend_requests
                           WHERE status = 'accepted' AND (sender_id = ? OR receiver_id = ?)
                       ) AS my_friends
                       JOIN (
                           SELECT IF(sender_id = ?, receiver_id, sender_id) as friend_id
                           FROM friend_requests
                           WHERE status = 'accepted' AND (sender_id = ? OR receiver_id = ?)
                       ) AS their_friends
                       ON my_friends.friend_id = their_friends.friend_id";
        $mutualStmt = $conn->prepare($mutualQuery);
        $mutualStmt->bind_param("iiiiii", 
            $_SESSION['user_id'], $_SESSION['user_id'], $_SESSION['user_id'],
            $user_id, $user_id, $user_id
        );
        $mutualStmt->execute();
        $mutualResult = $mutualStmt->get_result();
        $mutualFriendsCount = $mutualResult->fetch_assoc()['mutual_count'];
    }
} else {
    // Set default values if no user_id is available
    $friendCount = 0;
    $mutualFriendsCount = 0;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Management - Expressify Admin</title>
    <link rel="stylesheet" href="admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        :root {
            --bg-primary: #1e2a3a;
            --bg-secondary: #172331;
            --card-bg: #243447;
            --card-bg-hover: #2c3e50;
            --text-primary: #ffffff;
            --text-secondary: #a0aec0;
            --accent: #3498db;
            --accent-light: rgba(52, 152, 219, 0.2);
            --accent-hover: #2980b9;
            --border: #2d3748;
            --border-light: #34495e;
            --success: #2ecc71;
            --warning: #f39c12;
            --danger: #e74c3c;
            --danger-light: rgba(231, 76, 60, 0.1);
            --input-bg: #1a2635;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: var(--bg-primary);
            color: var(--text-primary);
            display: flex;
            min-height: 100vh;
            padding-left: 250px;
        }
        
        /* Error message styles */
        .error-message {
            background-color: var(--danger-light);
            border-left: 4px solid var(--danger);
            padding: 12px 15px;
            margin-bottom: 20px;
            border-radius: 4px;
            color: var(--text-primary);
        }
        
        .error-message .error-icon {
            color: var(--danger);
            margin-right: 10px;
        }
        
        /* Empty state styles */
        .empty-state-container {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 400px;
        }
        
        .empty-state {
            background-color: var(--card-bg);
            padding: 60px 40px;
            text-align: center;
            border-radius: 12px;
            margin: 40px auto;
            max-width: 500px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.2);
            border: 1px solid var(--border);
        }
        
        .empty-state i {
            font-size: 64px;
            color: var(--accent);
            margin-bottom: 20px;
            opacity: 0.8;
        }
        
        .empty-state h3 {
            color: var(--text-primary);
            margin-bottom: 15px;
            font-size: 1.5rem;
        }
        
        .empty-state p {
            color: var(--text-secondary);
            max-width: 400px;
            margin: 0 auto;
            line-height: 1.6;
        }
        
        /* Search and filter styles */
        .filters-section {
            background-color: var(--card-bg);
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 25px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
            border: 1px solid var(--border);
        }
        
        .filters-form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        
        .search-box {
            position: relative;
            max-width: 100%;
            margin-bottom: 5px;
        }
        
        .search-box input {
            width: 100%;
            padding: 12px 45px 12px 18px;
            border: 1px solid var(--border);
            border-radius: 24px;
            background-color: var(--input-bg);
            color: var(--text-primary);
            font-size: 1rem;
            transition: all 0.2s ease;
        }
        
        .search-box input:focus {
            border-color: var(--accent);
            box-shadow: 0 0 0 3px var(--accent-light);
            outline: none;
        }
        
        .search-box button {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: var(--accent);
            cursor: pointer;
            font-size: 1.1rem;
            transition: all 0.2s ease;
        }
        
        .search-box button:hover {
            color: var(--accent-hover);
        }
        
        .filter-options {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            align-items: center;
        }
        
        .filter-group {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .filter-group label {
            color: var(--text-secondary);
            font-size: 0.95em;
            font-weight: 500;
        }
        
        .filter-group select {
            padding: 10px 35px 10px 15px;
            border: 1px solid var(--border);
            border-radius: 6px;
            background-color: var(--input-bg);
            color: var(--text-primary);
            font-size: 0.95rem;
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='%236b7280' viewBox='0 0 16 16'%3E%3Cpath d='M7.247 11.14 2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: calc(100% - 12px) center;
            cursor: pointer;
            transition: all 0.2s ease;
        }
        
        .filter-group select:focus {
            border-color: var(--accent);
            box-shadow: 0 0 0 3px var(--accent-light);
            outline: none;
        }
        
        /* User card styles */
        .users-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
            gap: 25px;
            margin-bottom: 40px;
        }
        
        .user-card {
            background: var(--card-bg);
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
            transition: all 0.2s ease;
            border: 1px solid var(--border);
            overflow: hidden;
        }
        
        .user-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 15px rgba(0,0,0,0.3);
            border-color: var(--accent);
        }
        
        .user-info {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .user-avatar {
            position: relative;
        }
        
        .profile-image {
            width: 70px;
            height: 70px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--accent);
            background-color: var(--card-bg-hover);
        }
        
        .user-details h3 {
            margin: 0 0 5px 0;
            color: var(--text-primary);
            font-size: 1.1em;
        }
        
        .user-details p {
            margin: 0 0 8px 0;
            color: var(--text-secondary);
            font-size: 0.9em;
        }
        
        .user-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            font-size: 0.8em;
            color: var(--text-secondary);
        }
        
        .user-stats {
            display: flex;
            gap: 15px;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--border-light);
        }
        
        .stat-item {
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--text-secondary);
            font-size: 0.9em;
        }
        
        .stat-item i {
            color: var(--accent);
        }
        
        .user-actions {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
        }
        
        /* Badge styles */
        .badge {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.8em;
            font-weight: 500;
        }
        
        .badge-success {
            background-color: var(--success);
            color: white;
        }
        
        .badge-warning {
            background-color: var(--warning);
            color: var(--bg-primary);
        }
        
        .badge-danger {
            background-color: var(--danger);
            color: white;
        }
        
        .badge-secondary {
            background-color: var(--text-secondary);
            color: var(--bg-primary);
        }
        
        /* Button styles */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 8px 16px;
            border-radius: 6px;
            font-size: 0.9rem;
            font-weight: 500;
            text-decoration: none;
            cursor: pointer;
            transition: all 0.2s ease;
            border: none;
            gap: 8px;
        }
        
        .btn-sm {
            padding: 5px 10px;
            font-size: 0.8rem;
        }
        
        .btn-primary {
            background-color: var(--accent);
            color: white;
        }
        
        .btn-primary:hover {
            background-color: var(--accent-hover);
        }
        
        .btn-secondary {
            background-color: #4a5568;
            color: white;
        }
        
        .btn-secondary:hover {
            background-color: #2d3748;
        }
        
        .btn-success {
            background-color: var(--success);
            color: white;
        }
        
        .btn-success:hover {
            background-color: #27ae60;
        }
        
        .btn-warning {
            background-color: var(--warning);
            color: white;
        }
        
        .btn-warning:hover {
            background-color: #e67e22;
        }
        
        .btn-danger {
            background-color: var(--danger);
            color: white;
        }
        
        .btn-danger:hover {
            background-color: #c0392b;
        }
        
        .btn-outline {
            background-color: transparent;
            color: var(--text-primary);
            border: 1px solid var(--border);
        }
        
        .btn-outline:hover {
            background-color: var(--card-bg-hover);
            border-color: var(--accent);
            color: var(--accent);
        }
        
        /* Tab content styling */
        .detail-tabs {
            display: flex;
            gap: 0;
            margin-bottom: 20px;
            border-bottom: 1px solid var(--border);
        }
        
        .detail-tab {
            padding: 12px 20px;
            cursor: pointer;
            font-weight: 500;
            color: var(--text-secondary);
            border-bottom: 3px solid transparent;
            transition: all 0.2s ease;
        }
        
        .detail-tab:hover {
            color: var(--accent);
            background-color: var(--card-bg-hover);
        }
        
        .detail-tab.active {
            color: var(--accent);
            border-bottom-color: var(--accent);
        }
        
        .tab-content {
            margin-bottom: 20px;
        }
        
        /* Pagination styling */
        .pagination {
            display: flex;
            justify-content: center;
            gap: 5px;
            margin-top: 30px;
        }
        
        .pagination-link {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 8px 12px;
            border-radius: 4px;
            background-color: var(--card-bg);
            color: var(--text-primary);
            text-decoration: none;
            transition: all 0.2s ease;
            min-width: 40px;
        }
        
        .pagination-link:hover {
            background-color: var(--card-bg-hover);
            color: var(--accent);
        }
        
        .pagination-link.active {
            background-color: var(--accent);
            color: white;
        }
        
        .pagination-ellipsis {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 40px;
            color: var(--text-secondary);
        }
        
        /* User detail sections */
        .card {
            background-color: var(--card-bg);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
            border: 1px solid var(--border);
        }
        
        .card h3 {
            margin-top: 0;
            margin-bottom: 20px;
            color: var(--text-primary);
            font-size: 1.2rem;
            border-bottom: 1px solid var(--border);
            padding-bottom: 10px;
        }
        
        .user-detail-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .detail-item {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
        
        .detail-item .label {
            color: var(--text-secondary);
            font-size: 0.9em;
        }
        
        .detail-item .value {
            font-weight: 500;
            color: var(--text-primary);
        }
        
        /* Action buttons */
        .action-buttons {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-top: 20px;
            border-top: 1px solid var(--border);
            padding-top: 20px;
        }
        
        /* Post items in user details */
        .user-posts {
            display: grid;
            grid-template-columns: 1fr;
            gap: 15px;
            margin-top: 15px;
        }
        
        .post-item {
            background-color: var(--card-bg-hover);
            padding: 15px;
            border-radius: 8px;
            border-left: 3px solid var(--accent);
        }
        
        .post-content {
            margin-bottom: 10px;
            color: var(--text-primary);
        }
        
        .post-meta {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            color: var(--text-secondary);
            font-size: 0.85em;
            margin-bottom: 10px;
        }
        
        .post-actions {
            display: flex;
            justify-content: flex-end;
        }
        
        .view-all {
            margin-top: 20px;
            text-align: center;
        }
        
        /* Friends list styles */
        .friends-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }
        
        .friend-item {
            display: flex;
            align-items: center;
            background: var(--card-bg-hover);
            padding: 15px;
            border-radius: 8px;
            transition: all 0.2s ease;
        }
        
        .friend-item:hover {
            transform: translateY(-3px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }
        
        .friend-avatar {
            margin-right: 15px;
        }
        
        .profile-image-sm {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid var(--accent);
        }
        
        .friend-info {
            flex: 1;
        }
        
        .friend-info h4 {
            margin: 0 0 5px 0;
            font-size: 1rem;
            color: var(--text-primary);
        }
        
        .friend-info p {
            margin: 0 0 5px 0;
            font-size: 0.85rem;
            color: var(--text-secondary);
        }
        
        .friend-status {
            margin-top: 5px;
        }
        
        .friend-actions {
            margin-left: auto;
        }
        
        /* Empty state actions */
        .empty-state-actions {
            margin-top: 20px;
            display: flex;
            justify-content: center;
            gap: 10px;
        }
        
        /* Main layout styles */
        .content {
            padding: 20px;
            background-color: var(--bg-secondary);
            border-radius: 12px;
            margin-top: 20px;
            min-height: calc(100vh - 180px);
        }
        
        .main-content {
            flex: 1;
            padding: 20px;
            background-color: var(--bg-primary);
            overflow-y: auto;
            min-height: 100vh;
        }
        
        /* Header styling */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid var(--border);
        }
        
        .title h1 {
            margin: 0;
            font-size: 1.8rem;
            color: var(--text-primary);
        }
        
        .title p {
            margin: 5px 0 0;
            color: var(--text-secondary);
        }
        
        .admin-profile {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .admin-profile span {
            color: var(--text-secondary);
        }
        
        .admin-profile img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            border: 2px solid var(--accent);
        }
        
        /* Sidebar styling */
        .sidebar {
            width: 250px;
            background-color: var(--card-bg);
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            display: flex;
            flex-direction: column;
            box-shadow: 2px 0 10px rgba(0,0,0,0.2);
            z-index: 100;
        }
        
        .logo {
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 15px;
            border-bottom: 1px solid var(--border);
            margin-bottom: 20px;
        }
        
        .logo img {
            width: 40px;
            height: 40px;
            object-fit: contain;
        }
        
        .logo h2 {
            margin: 0;
            color: var(--accent);
            font-size: 1.3rem;
        }
        
        .nav-links {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .nav-links li {
            padding: 0;
            margin: 0;
        }
        
        .nav-links a {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 15px 20px;
            color: var(--text-primary);
            text-decoration: none;
            transition: all 0.2s ease;
        }
        
        .nav-links a:hover {
            background-color: var(--card-bg-hover);
            color: var(--accent);
        }
        
        .nav-links li.active a {
            background-color: var(--accent-light);
            color: var(--accent);
            border-left: 4px solid var(--accent);
            padding-left: 16px;
            font-weight: 500;
        }
        
        .sidebar-footer {
            margin-top: auto;
            padding: 20px;
            border-top: 1px solid var(--border);
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        
        .sidebar-footer a {
            display: flex;
            align-items: center;
            gap: 10px;
            color: var(--text-secondary);
            text-decoration: none;
            padding: 10px 15px;
            border-radius: 6px;
            transition: all 0.2s ease;
        }
        
        .sidebar-footer a:hover {
            background-color: var(--card-bg-hover);
            color: var(--accent);
        }
        
        /* Alert styles */
        .alert {
            padding: 12px 15px;
            margin-bottom: 20px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .alert-success {
            background-color: rgba(46, 204, 113, 0.2);
            border-left: 4px solid var(--success);
            color: var(--text-primary);
        }
        
        .alert-danger {
            background-color: rgba(231, 76, 60, 0.2);
            border-left: 4px solid var(--danger);
            color: var(--text-primary);
        }
        
        /* Debug box */
        .debug-box {
            background-color: rgba(248, 215, 218, 0.9);
            color: #721c24;
            padding: 10px;
            margin: 10px 0;
            border-radius: 4px;
            border: 1px solid #f5c6cb;
            display: none;
            position: fixed;
            bottom: 20px;
            right: 20px;
            max-width: 400px;
            max-height: 200px;
            overflow: auto;
            z-index: 9999;
            font-size: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        
        /* Responsive adjustments */
        @media (max-width: 768px) {
            body {
                padding-left: 0;
            }
            
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .main-content {
                width: 100%;
            }
            
            .user-detail-grid {
                grid-template-columns: 1fr;
            }
            
            .users-container {
                grid-template-columns: 1fr;
            }
        }

        /* Modal styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 1000;
        }

        .modal-content {
            position: relative;
            background-color: var(--card-bg);
            margin: 10% auto;
            padding: 20px;
            width: 50%;
            max-width: 500px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid var(--border);
        }

        .modal-header h3 {
            margin: 0;
            color: var(--text-primary);
        }

        .close {
            color: var(--text-secondary);
            font-size: 24px;
            cursor: pointer;
        }

        .close:hover {
            color: var(--text-primary);
        }

        .modal .form-group {
            margin-bottom: 15px;
        }

        .modal label {
            display: block;
            margin-bottom: 5px;
            color: var(--text-primary);
        }

        .modal input,
        .modal select {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid var(--border);
            border-radius: 4px;
            background-color: var(--input-bg);
            color: var(--text-primary);
        }

        .modal input:focus,
        .modal select:focus {
            border-color: var(--accent);
            outline: none;
            box-shadow: 0 0 0 2px var(--accent-light);
        }

        .form-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="logo">
            <img src="../assets/logo.png" alt="Expressify Logo">
            <h2>Expressify</h2>
        </div>
        <ul class="nav-links">
            <li><a href="admin_panel.php"><i class="fas fa-home"></i> Dashboard</a></li>
            <li class="active"><a href="admin_user_management.php"><i class="fas fa-users"></i> User Management</a></li>
            <li><a href="admin_post_management.php"><i class="fas fa-stream"></i> Post Management</a></li>
            <li><a href="content_analysis.php"><i class="fas fa-chart-line"></i> Content Analysis</a></li>
        </ul>
        <div class="sidebar-footer">
            <a href="../index.php"><i class="fas fa-sign-out-alt"></i> Back to Site</a>
            <a href="admin_auth.php?logout=1"><i class="fas fa-power-off"></i> Logout</a>
        </div>
    </div>

    <div class="main-content">
        <div class="header">
            <div class="title">
                <h1><?php echo isset($userDetails) ? "User Details: " . htmlspecialchars($userDetails['username']) : "User Management"; ?></h1>
                <p>Manage Expressify users and their settings</p>
            </div>
            <div class="admin-profile">
                <span>Welcome, Admin</span>
                <img src="../assets/images/admin_avatar.png" alt="Admin">
            </div>
        </div>

        <div class="content">
            <?php if(isset($_GET['success']) && isset($messages[$_GET['success']])): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $messages[$_GET['success']]; ?>
                </div>
            <?php endif; ?>
            
            <?php if(isset($_GET['error']) && isset($messages[$_GET['error']])): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $messages[$_GET['error']]; ?>
                </div>
            <?php endif; ?>

            <div class="user-management-content">
                <?php if(isset($userDetails)): ?>
                    <!-- User Detail View -->
                    <div class="detail-tabs">
                        <div class="detail-tab active" data-tab="profile">Profile</div>
                        <div class="detail-tab" data-tab="posts">Posts</div>
                        <?php if(!empty($userFriends)): ?>
                        <div class="detail-tab" data-tab="friends">Friends</div>
                        <?php endif; ?>
                        <div class="detail-tab" data-tab="activity">Activity Log</div>
                    </div>

                    <div class="tab-content" id="profile-tab">
                        <div class="card">
                            <h3>User Information</h3>
                            <div class="user-detail-grid">
                                <div class="detail-item">
                                    <span class="label">Username:</span>
                                    <span class="value"><?php echo htmlspecialchars($userDetails['username']); ?></span>
                                </div>
                                <div class="detail-item">
                                    <span class="label">Email:</span>
                                    <span class="value"><?php echo htmlspecialchars($userDetails['email']); ?></span>
                                </div>
                                <div class="detail-item">
                                    <span class="label">Status:</span>
                                    <span class="value">
                                        <span class="badge <?php echo getStatusBadgeClass($userDetails['status']); ?>">
                                            <?php echo ucfirst(htmlspecialchars($userDetails['status'])); ?>
                                        </span>
                                    </span>
                                </div>
                                <div class="detail-item">
                                    <span class="label">Joined:</span>
                                    <span class="value"><?php echo formatCreatedAt($userDetails['created_at']); ?></span>
                                </div>
                                <div class="detail-item">
                                    <span class="label">Posts:</span>
                                    <span class="value"><?php echo htmlspecialchars($userDetails['post_count']); ?></span>
                                </div>
                                <?php if(isset($userDetails['friends_count'])): ?>
                                <div class="detail-item">
                                    <span class="label">Friends:</span>
                                    <span class="value"><?php echo htmlspecialchars($userDetails['friends_count']); ?></span>
                                </div>
                                <div class="detail-item">
                                    <span class="label">Pending Friends:</span>
                                    <span class="value"><?php echo htmlspecialchars($userDetails['pending_friends_count']); ?></span>
                                </div>
                                <?php else: ?>
                                <div class="detail-item">
                                    <span class="label">Friends:</span>
                                    <span class="value">0</span>
                                </div>
                                <div class="detail-item">
                                    <span class="label">Pending Friends:</span>
                                    <span class="value">0</span>
                                </div>
                                <?php endif; ?>
                            </div>

                            <div class="action-buttons">
                                <a href="admin_user_management.php?action=edit&id=<?php echo $userDetails['id']; ?>" class="btn btn-primary">
                                    <i class="fas fa-edit"></i> Edit User
                                </a>
                                <?php if($userDetails['status'] == 'active'): ?>
                                    <a href="admin_user_management.php?action=ban&id=<?php echo $userDetails['id']; ?>" class="btn btn-warning">
                                        <i class="fas fa-ban"></i> Ban User
                                    </a>
                                <?php else: ?>
                                    <a href="admin_user_management.php?action=activate&id=<?php echo $userDetails['id']; ?>" class="btn btn-success">
                                        <i class="fas fa-check-circle"></i> Activate User
                                    </a>
                                <?php endif; ?>
                                <a href="admin_user_management.php?action=delete&id=<?php echo $userDetails['id']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this user? This action cannot be undone.');">
                                    <i class="fas fa-trash"></i> Delete User
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="tab-content" id="posts-tab" style="display: none;">
                        <div class="card">
                            <h3>User Posts</h3>
                            <?php if(empty($userPosts)): ?>
                                <p>This user has not created any posts yet.</p>
                            <?php else: ?>
                                <div class="user-posts">
                                    <?php foreach($userPosts as $post): ?>
                                        <div class="post-item">
                                            <div class="post-content">
                                                <?php echo htmlspecialchars(truncateText($post['content'])); ?>
                                            </div>
                                            <div class="post-meta">
                                                <span><i class="fas fa-calendar"></i> <?php echo formatCreatedAt($post['created_at']); ?></span>
                                                <span><i class="fas fa-heart"></i> <?php echo $post['likes_count']; ?> likes</span>
                                                <span><i class="fas fa-comment"></i> <?php echo $post['comments_count']; ?> comments</span>
                                                <span class="badge <?php echo getStatusBadgeClass($post['status']); ?>">
                                                    <?php echo ucfirst($post['status']); ?>
                                                </span>
                                            </div>
                                            <div class="post-actions">
                                                <a href="admin_post_management.php?view=<?php echo $post['id']; ?>" class="btn btn-sm btn-secondary">
                                                    <i class="fas fa-eye"></i> View
                                                </a>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                                <div class="view-all">
                                    <a href="admin_post_management.php?user_id=<?php echo $userDetails['id']; ?>" class="btn btn-outline">
                                        View All Posts <i class="fas fa-arrow-right"></i>
                                    </a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <?php if(!empty($userFriends)): ?>
                    <div class="tab-content" id="friends-tab" style="display: none;">
                        <div class="card">
                            <h3>User Friends</h3>
                            <?php if(empty($userFriends)): ?>
                                <p>This user has no friends yet.</p>
                            <?php else: ?>
                                <div class="friends-list">
                                    <?php foreach($userFriends as $friend): ?>
                                        <div class="friend-item">
                                            <div class="friend-avatar">
                                                <?php 
                                                $friendAvatar = !empty($friend['profile_picture']) ? '../' . $friend['profile_picture'] : '../assets/images/default_avatar.png';
                                                ?>
                                                <img src="<?php echo $friendAvatar; ?>" alt="<?php echo htmlspecialchars($friend['username']); ?>" class="profile-image-sm">
                                            </div>
                                            <div class="friend-info">
                                                <h4><?php echo htmlspecialchars($friend['username']); ?></h4>
                                                <p><?php echo htmlspecialchars($friend['email']); ?></p>
                                                <div class="friend-status">
                                                    <span class="badge <?php echo getStatusBadgeClass($friend['status']); ?>">
                                                        <?php echo ucfirst($friend['status']); ?>
                                                    </span>
                                                </div>
                                            </div>
                                            <div class="friend-actions">
                                                <a href="admin_user_management.php?view=<?php echo $friend['friend_id']; ?>" class="btn btn-sm btn-secondary">
                                                    <i class="fas fa-eye"></i> View
                                                </a>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <div class="tab-content" id="activity-tab" style="display: none;">
                        <div class="card">
                            <h3>Activity Log</h3>
                            <p>User activity log coming soon.</p>
                        </div>
                    </div>

                <?php else: ?>
                    <!-- User List View -->
                    <div class="filters-section">
                        <form action="" method="GET" class="filters-form">
                            <div class="search-box">
                                <input type="text" name="search" placeholder="Search by username or email..." value="<?php echo htmlspecialchars($search); ?>">
                                <button type="submit"><i class="fas fa-search"></i></button>
                            </div>
                            <div class="filter-options">
                                <div class="filter-group">
                                    <label>Status:</label>
                                    <select name="status">
                                        <option value="">All</option>
                                        <option value="active" <?php echo ($filterStatus == 'active') ? 'selected' : ''; ?>>Active</option>
                                        <option value="banned" <?php echo ($filterStatus == 'banned') ? 'selected' : ''; ?>>Banned</option>
                                        <option value="inactive" <?php echo ($filterStatus == 'inactive') ? 'selected' : ''; ?>>Inactive</option>
                                    </select>
                                </div>
                                <div class="filter-group">
                                    <label>Sort By:</label>
                                    <select name="sort">
                                        <option value="created_at" <?php echo ($sortBy == 'created_at' || $sortBy == 'newest') ? 'selected' : ''; ?>>Newest</option>
                                        <option value="username" <?php echo ($sortBy == 'username') ? 'selected' : ''; ?>>Username</option>
                                        <option value="most_posts" <?php echo ($sortBy == 'most_posts') ? 'selected' : ''; ?>>Most Posts</option>
                                        <?php if($tableExists): ?>
                                        <option value="most_friends" <?php echo ($sortBy == 'most_friends') ? 'selected' : ''; ?>>Most Friends</option>
                                        <?php endif; ?>
                                    </select>
                                </div>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-filter"></i> Apply Filters
                                </button>
                                <a href="admin_user_management.php" class="btn btn-outline">
                                    <i class="fas fa-redo"></i> Reset
                                </a>
                            </div>
                        </form>
                    </div>

                    <div class="users-container">
                        <?php if(empty($users)): ?>
                            <div class="empty-state">
                                <i class="fas fa-users"></i>
                                <h3>No Users Found</h3>
                                <p>There are no users matching your criteria. Try adjusting your filters.</p>
                            </div>
                        <?php else: ?>
                            <?php foreach($users as $user): ?>
                                <?php $user = ensure_user_fields($user); ?>
                                <div class="user-card">
                                    <div class="user-info">
                                        <div class="user-avatar">
                                            <?php 
                                            $userAvatar = !empty($user['profile_picture']) ? '../' . $user['profile_picture'] : '../assets/images/default_avatar.png';
                                            ?>
                                            <img src="<?php echo $userAvatar; ?>" alt="<?php echo htmlspecialchars($user['username']); ?>" class="profile-image">
                                        </div>
                                        <div class="user-details">
                                            <h3><?php echo htmlspecialchars($user['username']); ?></h3>
                                            <p><?php echo htmlspecialchars($user['email']); ?></p>
                                            <div class="user-meta">
                                                <span><i class="fas fa-calendar"></i> Joined: <?php echo formatCreatedAt($user['created_at']); ?></span>
                                                <span class="badge <?php echo getStatusBadgeClass($user['status']); ?>">
                                                    <?php echo ucfirst($user['status']); ?>
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="user-stats">
                                        <div class="stat-item">
                                            <i class="fas fa-file-alt"></i>
                                            <span><?php echo safe_get($user, 'post_count', 0); ?> Posts</span>
                                        </div>
                                        <div class="stat-item">
                                            <i class="fas fa-user-friends"></i>
                                            <span>
                                                <?php 
                                                if(isset($user['friends_count']) && $tableExists) {
                                                    echo $user['friends_count'] . ' Friends';
                                                } else {
                                                    echo '0 Friends';
                                                }
                                                ?>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="user-actions">
                                        <a href="admin_user_management.php?view=<?php echo $user['id']; ?>" class="btn btn-primary btn-sm">
                                            <i class="fas fa-eye"></i> View
                                        </a>
                                        <a href="admin_user_management.php?action=edit&id=<?php echo $user['id']; ?>" class="btn btn-secondary btn-sm">
                                            <i class="fas fa-edit"></i> Edit
                                        </a>
                                        <?php if($user['status'] == 'active'): ?>
                                            <a href="admin_user_management.php?action=ban&id=<?php echo $user['id']; ?>" class="btn btn-warning btn-sm">
                                                <i class="fas fa-ban"></i> Ban
                                            </a>
                                        <?php else: ?>
                                            <a href="admin_user_management.php?action=activate&id=<?php echo $user['id']; ?>" class="btn btn-success btn-sm">
                                                <i class="fas fa-check-circle"></i> Activate
                                            </a>
                                        <?php endif; ?>
                                        <a href="admin_user_management.php?action=delete&id=<?php echo $user['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this user? This action cannot be undone.');">
                                            <i class="fas fa-trash"></i> Delete
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>

                    <!-- Pagination -->
                    <?php if($total_pages > 1): ?>
                        <div class="pagination">
                            <?php if($page > 1): ?>
                                <a href="admin_user_management.php?page=<?php echo ($page-1); ?><?php echo $query_string; ?>" class="pagination-link">
                                    <i class="fas fa-chevron-left"></i> Previous
                                </a>
                            <?php endif; ?>
                            
                            <?php if($start_page > 1): ?>
                                <a href="admin_user_management.php?page=1<?php echo $query_string; ?>" class="pagination-link">1</a>
                                <?php if($start_page > 2): ?>
                                    <span class="pagination-ellipsis">...</span>
                                <?php endif; ?>
                            <?php endif; ?>
                            
                            <?php for($i=$start_page; $i<=$end_page; $i++): ?>
                                <a href="admin_user_management.php?page=<?php echo $i; ?><?php echo $query_string; ?>" class="pagination-link <?php echo ($i == $page) ? 'active' : ''; ?>">
                                    <?php echo $i; ?>
                                </a>
                            <?php endfor; ?>
                            
                            <?php if($end_page < $total_pages): ?>
                                <?php if($end_page < $total_pages - 1): ?>
                                    <span class="pagination-ellipsis">...</span>
                                <?php endif; ?>
                                <a href="admin_user_management.php?page=<?php echo $total_pages; ?><?php echo $query_string; ?>" class="pagination-link">
                                    <?php echo $total_pages; ?>
                                </a>
                            <?php endif; ?>
                            
                            <?php if($page < $total_pages): ?>
                                <a href="admin_user_management.php?page=<?php echo ($page+1); ?><?php echo $query_string; ?>" class="pagination-link">
                                    Next <i class="fas fa-chevron-right"></i>
                                </a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="debug-box" id="debug-output" style="display: <?php echo !empty($debugInfo) ? 'block' : 'none'; ?>">
        <?php if(!empty($debugInfo)): ?>
            <strong>Debug Info:</strong><br>
            <?php foreach($debugInfo as $key => $value): ?>
                <?php echo htmlspecialchars($key) ?>: <?php echo htmlspecialchars($value) ?><br>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>

    <div class="modal" id="editUserModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Edit User</h3>
                <span class="close">&times;</span>
            </div>
            <div class="modal-body">
                <form id="editUserForm">
                    <div class="form-group">
                        <label for="edit-username">Username</label>
                        <input type="text" id="edit-username" name="username" required>
                    </div>
                    <div class="form-group">
                        <label for="edit-email">Email</label>
                        <input type="email" id="edit-email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="edit-status">Status</label>
                        <select id="edit-status" name="status">
                            <option value="active">Active</option>
                            <option value="inactive">Inactive</option>
                            <option value="banned">Banned</option>
                        </select>
                    </div>
                    <input type="hidden" id="edit-user-id" name="user_id">
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                        <button type="button" class="btn btn-secondary close-modal">Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Tab switching functionality
            const tabs = document.querySelectorAll('.detail-tab');
            if(tabs.length > 0) {
                tabs.forEach(tab => {
                    tab.addEventListener('click', function() {
                        // Hide all tab contents
                        document.querySelectorAll('.tab-content').forEach(content => {
                            content.style.display = 'none';
                        });
                        
                        // Remove active class from all tabs
                        tabs.forEach(t => {
                            t.classList.remove('active');
                        });
                        
                        // Add active class to clicked tab
                        this.classList.add('active');
                        
                        // Show corresponding tab content
                        const tabName = this.getAttribute('data-tab');
                        document.getElementById(tabName + '-tab').style.display = 'block';
                    });
                });
            }
            
            // Auto-hide alerts after 5 seconds
            const alerts = document.querySelectorAll('.alert');
            if(alerts.length > 0) {
                setTimeout(() => {
                    alerts.forEach(alert => {
                        alert.style.opacity = '0';
                        setTimeout(() => {
                            alert.style.display = 'none';
                        }, 500);
                    });
                }, 5000);
            }

            // Handle user management actions
            function handleUserAction(action, userId, confirmMessage = '') {
                if (confirmMessage && !confirm(confirmMessage)) {
                    return;
                }

                const formData = new FormData();
                formData.append('action', action);
                formData.append('user_id', userId);

                // If it's an edit action, gather form data
                if (action === 'edit') {
                    const userForm = document.querySelector(`form[data-user-id="${userId}"]`);
                    if (userForm) {
                        formData.append('username', userForm.querySelector('[name="username"]').value);
                        formData.append('email', userForm.querySelector('[name="email"]').value);
                        formData.append('status', userForm.querySelector('[name="status"]').value);
                    }
                }

                fetch('admin_api.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Show success message
                        const alert = document.createElement('div');
                        alert.className = 'alert alert-success';
                        alert.innerHTML = `<i class="fas fa-check-circle"></i> ${data.message}`;
                        document.querySelector('.content').insertBefore(alert, document.querySelector('.content').firstChild);

                        // Reload page after successful action
                        setTimeout(() => {
                            window.location.reload();
                        }, 1000);
                    } else {
                        // Show error message
                        const alert = document.createElement('div');
                        alert.className = 'alert alert-danger';
                        alert.innerHTML = `<i class="fas fa-exclamation-circle"></i> ${data.message}`;
                        document.querySelector('.content').insertBefore(alert, document.querySelector('.content').firstChild);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    const alert = document.createElement('div');
                    alert.className = 'alert alert-danger';
                    alert.innerHTML = '<i class="fas fa-exclamation-circle"></i> An error occurred while processing your request';
                    document.querySelector('.content').insertBefore(alert, document.querySelector('.content').firstChild);
                });
            }

            // Add event listeners to all user action buttons
            document.querySelectorAll('.user-actions').forEach(actionContainer => {
                actionContainer.addEventListener('click', function(e) {
                    const target = e.target.closest('a');
                    if (!target) return;

                    e.preventDefault();
                    
                    const userId = target.href.split('id=')[1]?.split('&')[0];
                    if (!userId) return;

                    if (target.classList.contains('btn-warning')) {
                        handleUserAction('ban', userId, 'Are you sure you want to ban this user?');
                    } else if (target.classList.contains('btn-success')) {
                        handleUserAction('activate', userId, 'Are you sure you want to activate this user?');
                    } else if (target.classList.contains('btn-danger')) {
                        handleUserAction('delete', userId, 'Are you sure you want to delete this user? This action cannot be undone.');
                    } else if (target.classList.contains('btn-secondary')) {
                        // Get user data from the card
                        const userCard = target.closest('.user-card');
                        const username = userCard.querySelector('h3').textContent;
                        const email = userCard.querySelector('p').textContent;
                        const statusBadge = userCard.querySelector('.badge');
                        const status = statusBadge.textContent.toLowerCase();
                        
                        // Open edit modal with user data
                        openModal(userId, username, email, status);
                    } else if (target.classList.contains('btn-primary')) {
                        // Handle view action
                        window.location.href = target.href;
                    }
                });
            });

            // Modal functionality
            const modal = document.getElementById('editUserModal');
            const closeButtons = modal.querySelectorAll('.close, .close-modal');
            const editUserForm = document.getElementById('editUserForm');

            function openModal(userId, username, email, status) {
                document.getElementById('edit-user-id').value = userId;
                document.getElementById('edit-username').value = username;
                document.getElementById('edit-email').value = email;
                document.getElementById('edit-status').value = status;
                modal.style.display = 'block';
            }

            function closeModal() {
                modal.style.display = 'none';
            }

            closeButtons.forEach(button => {
                button.addEventListener('click', closeModal);
            });

            window.addEventListener('click', (e) => {
                if (e.target === modal) {
                    closeModal();
                }
            });

            // Handle edit form submission
            editUserForm.addEventListener('submit', function(e) {
                e.preventDefault();
                const userId = document.getElementById('edit-user-id').value;
                const formData = new FormData(this);
                formData.append('action', 'edit');

                fetch('admin_api.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const alert = document.createElement('div');
                        alert.className = 'alert alert-success';
                        alert.innerHTML = `<i class="fas fa-check-circle"></i> ${data.message}`;
                        document.querySelector('.content').insertBefore(alert, document.querySelector('.content').firstChild);
                        closeModal();
                        setTimeout(() => {
                            window.location.reload();
                        }, 1000);
                    } else {
                        const alert = document.createElement('div');
                        alert.className = 'alert alert-danger';
                        alert.innerHTML = `<i class="fas fa-exclamation-circle"></i> ${data.message}`;
                        document.querySelector('.content').insertBefore(alert, document.querySelector('.content').firstChild);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    const alert = document.createElement('div');
                    alert.className = 'alert alert-danger';
                    alert.innerHTML = '<i class="fas fa-exclamation-circle"></i> An error occurred while processing your request';
                    document.querySelector('.content').insertBefore(alert, document.querySelector('.content').firstChild);
                });
            });
        });
    </script>
</body>
</html>
