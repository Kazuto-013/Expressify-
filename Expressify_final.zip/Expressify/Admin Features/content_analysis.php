<?php
require_once '../includes/session.php';
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if(!isset($_SESSION['admin_id'])) {
    header("Location: admin_auth.php");
    exit();
}

// Get period from query string (default to 'month')
$period = isset($_GET['period']) ? $_GET['period'] : 'month';

// Set up date ranges based on period
$endDate = date('Y-m-d');
switch($period) {
    case 'week':
        $startDate = date('Y-m-d', strtotime('-1 week'));
        $interval = 'DAY';
        $format = '%Y-%m-%d';
        $chartLabel = 'Last 7 Days';
        break;
    case 'month':
        $startDate = date('Y-m-d', strtotime('-1 month'));
        $interval = 'DAY';
        $format = '%Y-%m-%d';
        $chartLabel = 'Last 30 Days';
        break;
    case 'year':
        $startDate = date('Y-m-d', strtotime('-1 year'));
        $interval = 'MONTH';
        $format = '%Y-%m';
        $chartLabel = 'Last 12 Months';
        break;
    default:
        $startDate = date('Y-m-d', strtotime('-1 month'));
        $interval = 'DAY';
        $format = '%Y-%m-%d';
        $chartLabel = 'Last 30 Days';
}

// Get user growth data
$userGrowthData = [];
$userQuery = $conn->query("
    SELECT 
        DATE_FORMAT(created_at, '$format') as date,
        COUNT(*) as count
    FROM users
    WHERE created_at BETWEEN '$startDate' AND '$endDate 23:59:59'
    GROUP BY date
    ORDER BY date ASC
");

if($userQuery) {
    while($row = $userQuery->fetch_assoc()) {
        $userGrowthData[$row['date']] = (int)$row['count'];
    }
}

// Get post activity data
$postActivityData = [];
$postQuery = $conn->query("
    SELECT 
        DATE_FORMAT(created_at, '$format') as date,
        COUNT(*) as count
    FROM posts
    WHERE created_at BETWEEN '$startDate' AND '$endDate 23:59:59'
    GROUP BY date
    ORDER BY date ASC
");

if($postQuery) {
    while($row = $postQuery->fetch_assoc()) {
        $postActivityData[$row['date']] = (int)$row['count'];
    }
}

// Get most active users
$mostActiveUsers = [];
$activeUsersQuery = $conn->query("
    SELECT 
        u.id,
        u.username,
        u.profile_picture,
        COUNT(p.id) as post_count
    FROM users u
    LEFT JOIN posts p ON u.id = p.user_id
    GROUP BY u.id
    ORDER BY post_count DESC
    LIMIT 5
");

if($activeUsersQuery) {
    while($row = $activeUsersQuery->fetch_assoc()) {
        $mostActiveUsers[] = $row;
    }
}

// Get most liked posts
$mostLikedPosts = [];
$likedPostsQuery = $conn->query("
    SELECT 
        p.id,
        p.content,
        p.created_at,
        u.username,
        u.profile_picture,
        (SELECT COUNT(*) FROM likes WHERE post_id = p.id) as like_count
    FROM posts p
    JOIN users u ON p.user_id = u.id
    ORDER BY like_count DESC
    LIMIT 5
");

if($likedPostsQuery) {
    while($row = $likedPostsQuery->fetch_assoc()) {
        $mostLikedPosts[] = $row;
    }
}

// Get most commented posts
$mostCommentedPosts = [];
$commentedPostsQuery = $conn->query("
    SELECT 
        p.id,
        p.content,
        p.created_at,
        u.username,
        u.profile_picture,
        (SELECT COUNT(*) FROM comments WHERE post_id = p.id) as comment_count
    FROM posts p
    JOIN users u ON p.user_id = u.id
    ORDER BY comment_count DESC
    LIMIT 5
");

if($commentedPostsQuery) {
    while($row = $commentedPostsQuery->fetch_assoc()) {
        $mostCommentedPosts[] = $row;
    }
}

// Function to format date
function formatDate($date) {
    return date('M d, Y', strtotime($date));
}

// Function to truncate text
function truncateText($text, $length = 100) {
    if(strlen($text) <= $length) {
        return $text;
    }
    return substr($text, 0, $length) . '...';
}

// Generate chart labels and data points
$labels = [];
$userDataPoints = [];
$postDataPoints = [];

// Create a complete date range for the selected period
$currentDate = new DateTime($startDate);
$endDateTime = new DateTime($endDate);
$endDateTime->modify('+1 day'); // Include end date

$interval = new DateInterval('P1D'); // 1 day interval
$dateRange = new DatePeriod($currentDate, $interval, $endDateTime);

foreach($dateRange as $date) {
    $formattedDate = $date->format('Y-m-d');
    $labels[] = $formattedDate;
    $userDataPoints[] = $userGrowthData[$formattedDate] ?? 0;
    $postDataPoints[] = $postActivityData[$formattedDate] ?? 0;
}

// Convert to JSON for JavaScript
$chartLabels = json_encode($labels);
$userGrowthJSON = json_encode($userDataPoints);
$postActivityJSON = json_encode($postDataPoints);

// Get word frequencies for word cloud
$wordFrequencies = [];
$wordCloudQuery = $conn->query("
    SELECT content FROM posts 
    WHERE created_at BETWEEN '$startDate' AND '$endDate 23:59:59'
    LIMIT 1000
");

if($wordCloudQuery) {
    $allContent = '';
    while($row = $wordCloudQuery->fetch_assoc()) {
        $allContent .= ' ' . $row['content'];
    }
    
    // Remove common words and special characters
    $allContent = preg_replace('/[^\p{L}\p{N}\s]/u', '', $allContent);
    $allContent = strtolower($allContent);
    
    $stopWords = ['a', 'an', 'the', 'and', 'but', 'or', 'for', 'in', 'to', 'of', 'at', 'by', 'with', 'about', 'it', 'is', 'as', 'from', 'this', 'that', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'not', 'are', 'on', 'your', 'my', 'I', 'we', 'they', 'he', 'she'];
    
    $words = preg_split('/\s+/', $allContent);
    $wordCount = [];
    
    foreach($words as $word) {
        $word = trim($word);
        if(strlen($word) >= 3 && !in_array($word, $stopWords)) {
            if(isset($wordCount[$word])) {
                $wordCount[$word]++;
            } else {
                $wordCount[$word] = 1;
            }
        }
    }
    
    // Sort by frequency
    arsort($wordCount);
    
    // Take top 50 words
    $wordCount = array_slice($wordCount, 0, 50);
    
    foreach($wordCount as $word => $count) {
        $wordFrequencies[] = [
            'text' => $word,
            'value' => $count
        ];
    }
}

$wordCloudJSON = json_encode($wordFrequencies);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Content Analysis - Expressify Admin</title>
    <link rel="stylesheet" href="admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/d3@7"></script>
    <script src="https://cdn.jsdelivr.net/npm/d3-cloud@1.2.5/build/d3.layout.cloud.min.js"></script>
    <style>
        .chart-container {
            position: relative;
            height: 300px;
            margin-bottom: 30px;
        }
        
        .chart-card {
            background-color: var(--card-bg);
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .chart-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }
        
        .chart-title {
            font-size: 1.1rem;
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .period-selector {
            display: flex;
            gap: 10px;
        }
        
        .period-btn {
            padding: 5px 10px;
            font-size: 0.9rem;
            background: var(--card-bg-hover);
            border: 1px solid var(--border);
            border-radius: 4px;
            color: var(--text-secondary);
            cursor: pointer;
            transition: all 0.2s ease;
        }
        
        .period-btn.active {
            background-color: var(--accent);
            color: white;
            border-color: var(--accent);
        }
        
        .word-cloud-container {
            height: 300px;
            position: relative;
        }
        
        .stats-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-item {
            background-color: var(--card-bg);
            border-radius: 8px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .stat-value {
            font-size: 2rem;
            font-weight: bold;
            margin: 10px 0;
            color: var(--accent);
        }
        
        .stat-label {
            color: var(--text-secondary);
            font-size: 0.9rem;
        }
        
        .activity-list {
            margin-top: 15px;
        }
        
        .activity-item {
            display: flex;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid var(--border);
        }
        
        .activity-item:last-child {
            border-bottom: none;
        }
        
        .activity-user-info {
            display: flex;
            align-items: center;
            flex: 1;
        }
        
        .activity-user-info img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            object-fit: cover;
            margin-right: 10px;
        }
        
        .activity-content {
            flex: 2;
            color: var(--text-secondary);
            font-size: 0.9rem;
            padding: 0 10px;
        }
        
        .activity-stat {
            flex: 0.5;
            text-align: right;
            color: var(--accent);
            font-weight: bold;
        }

        .sidebar-footer {
            margin-top: auto;
            padding: 20px;
            border-top: 1px solid var(--border);
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        
        .sidebar-footer a {
            display: flex;
            align-items: center;
            gap: 10px;
            color: var(--text-secondary);
            text-decoration: none;
            padding: 10px 15px;
            border-radius: 6px;
            transition: all 0.2s ease;
        }
        
        .sidebar-footer a:hover {
            background-color: var(--card-bg-hover);
            color: var(--accent);
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-brand">
                <h1>Express<span>ify</span></h1>
                <p>Admin Panel</p>
            </div>
            <ul class="sidebar-menu">
                <li><a href="admin_panel.php">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a></li>
                <li><a href="admin_user_management.php">
                    <i class="fas fa-users"></i> User Management
                </a></li>
                <li><a href="admin_post_management.php">
                    <i class="fas fa-file-alt"></i> Post Management
                </a></li>
                <li><a href="content_analysis.php" class="active">
                    <i class="fas fa-chart-line"></i> Content Analysis
                </a></li>
                <li><a href="admin_settings.php">
                    <i class="fas fa-cog"></i> Settings
                </a></li>
            </ul>
            <div class="sidebar-footer">
                <a href="../index.php"><i class="fas fa-sign-out-alt"></i> Back to Site</a>
                <a href="admin_auth.php?logout=1"><i class="fas fa-power-off"></i> Logout</a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>Content Analysis</h1>
                <div class="user-actions">
                    <a href="#" title="Notifications"><i class="fas fa-bell"></i></a>
                    <a href="#" title="Profile"><i class="fas fa-user-circle"></i> Admin</a>
                    <a href="admin_auth.php?logout=true" title="Logout"><i class="fas fa-sign-out-alt"></i></a>
                </div>
            </div>

            <!-- Platform Overview Stats -->
            <div class="stats-row">
                <?php
                // Get total users
                $totalUsers = 0;
                $totalUsersQuery = $conn->query("SELECT COUNT(*) as total FROM users");
                if($totalUsersQuery) {
                    $totalUsers = $totalUsersQuery->fetch_assoc()['total'];
                }

                // Get total posts
                $totalPosts = 0;
                $totalPostsQuery = $conn->query("SELECT COUNT(*) as total FROM posts");
                if($totalPostsQuery) {
                    $totalPosts = $totalPostsQuery->fetch_assoc()['total'];
                }

                // Get total likes
                $totalLikes = 0;
                $totalLikesQuery = $conn->query("SELECT COUNT(*) as total FROM likes");
                if($totalLikesQuery) {
                    $totalLikes = $totalLikesQuery->fetch_assoc()['total'];
                }

                // Get total comments
                $totalComments = 0;
                $totalCommentsQuery = $conn->query("SELECT COUNT(*) as total FROM comments");
                if($totalCommentsQuery) {
                    $totalComments = $totalCommentsQuery->fetch_assoc()['total'];
                }
                ?>
                <div class="stat-item">
                    <div class="stat-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-value"><?php echo number_format($totalUsers); ?></div>
                    <div class="stat-label">Total Users</div>
                </div>
                <div class="stat-item">
                    <div class="stat-icon">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <div class="stat-value"><?php echo number_format($totalPosts); ?></div>
                    <div class="stat-label">Total Posts</div>
                </div>
                <div class="stat-item">
                    <div class="stat-icon">
                        <i class="fas fa-heart"></i>
                    </div>
                    <div class="stat-value"><?php echo number_format($totalLikes); ?></div>
                    <div class="stat-label">Total Likes</div>
                </div>
                <div class="stat-item">
                    <div class="stat-icon">
                        <i class="fas fa-comment"></i>
                    </div>
                    <div class="stat-value"><?php echo number_format($totalComments); ?></div>
                    <div class="stat-label">Total Comments</div>
                </div>
            </div>

            <!-- User Growth & Post Activity Charts -->
            <div class="chart-card">
                <div class="chart-header">
                    <div class="chart-title">
                        <i class="fas fa-chart-line"></i> Platform Activity
                    </div>
                    <div class="period-selector">
                        <a href="?period=week" class="period-btn <?php echo $period === 'week' ? 'active' : ''; ?>">Week</a>
                        <a href="?period=month" class="period-btn <?php echo $period === 'month' ? 'active' : ''; ?>">Month</a>
                        <a href="?period=year" class="period-btn <?php echo $period === 'year' ? 'active' : ''; ?>">Year</a>
                    </div>
                </div>
                <div class="chart-container">
                    <canvas id="activityChart"></canvas>
                </div>
            </div>

            <div class="row-container">
                <!-- Most Active Users -->
                <div class="chart-card">
                    <div class="chart-header">
                        <div class="chart-title">
                            <i class="fas fa-users"></i> Most Active Users
                        </div>
                    </div>
                    <div class="activity-list">
                        <?php if(count($mostActiveUsers) > 0): ?>
                            <?php foreach($mostActiveUsers as $user): ?>
                                <div class="activity-item">
                                    <div class="activity-user-info">
                                        <img src="<?php echo !empty($user['profile_picture']) ? '../' . $user['profile_picture'] : '../assets/default_profile.png'; ?>" alt="Profile">
                                        <div>
                                            <div><?php echo htmlspecialchars($user['username']); ?></div>
                                        </div>
                                    </div>
                                    <div class="activity-stat">
                                        <i class="fas fa-file-alt"></i> <?php echo $user['post_count']; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="no-content">
                                <p>No active users found</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Most Liked Posts -->
                <div class="chart-card">
                    <div class="chart-header">
                        <div class="chart-title">
                            <i class="fas fa-heart"></i> Most Liked Posts
                        </div>
                    </div>
                    <div class="activity-list">
                        <?php if(count($mostLikedPosts) > 0): ?>
                            <?php foreach($mostLikedPosts as $post): ?>
                                <div class="activity-item">
                                    <div class="activity-user-info">
                                        <img src="<?php echo !empty($post['profile_picture']) ? '../' . $post['profile_picture'] : '../assets/default_profile.png'; ?>" alt="Profile">
                                        <div>
                                            <div><?php echo htmlspecialchars($post['username']); ?></div>
                                            <small><?php echo formatDate($post['created_at']); ?></small>
                                        </div>
                                    </div>
                                    <div class="activity-content">
                                        <?php echo htmlspecialchars(truncateText($post['content'], 50)); ?>
                                    </div>
                                    <div class="activity-stat">
                                        <i class="fas fa-heart"></i> <?php echo $post['like_count']; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="no-content">
                                <p>No liked posts found</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Word Cloud -->
            <div class="chart-card">
                <div class="chart-header">
                    <div class="chart-title">
                        <i class="fas fa-cloud"></i> Word Cloud
                    </div>
                </div>
                <div class="word-cloud-container" id="wordCloud"></div>
            </div>

            <!-- Most Commented Posts -->
            <div class="chart-card">
                <div class="chart-header">
                    <div class="chart-title">
                        <i class="fas fa-comment"></i> Most Commented Posts
                    </div>
                </div>
                <div class="activity-list">
                    <?php if(count($mostCommentedPosts) > 0): ?>
                        <?php foreach($mostCommentedPosts as $post): ?>
                            <div class="activity-item">
                                <div class="activity-user-info">
                                    <img src="<?php echo !empty($post['profile_picture']) ? '../' . $post['profile_picture'] : '../assets/default_profile.png'; ?>" alt="Profile">
                                    <div>
                                        <div><?php echo htmlspecialchars($post['username']); ?></div>
                                        <small><?php echo formatDate($post['created_at']); ?></small>
                                    </div>
                                </div>
                                <div class="activity-content">
                                    <?php echo htmlspecialchars(truncateText($post['content'], 50)); ?>
                                </div>
                                <div class="activity-stat">
                                    <i class="fas fa-comment"></i> <?php echo $post['comment_count']; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="no-content">
                            <p>No commented posts found</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Initialize activity chart
        const activityCtx = document.getElementById('activityChart').getContext('2d');
        const activityChart = new Chart(activityCtx, {
            type: 'line',
            data: {
                labels: <?php echo $chartLabels; ?>,
                datasets: [
                    {
                        label: 'New Users',
                        data: <?php echo $userGrowthJSON; ?>,
                        borderColor: 'rgba(52, 152, 219, 1)',
                        backgroundColor: 'rgba(52, 152, 219, 0.1)',
                        borderWidth: 2,
                        tension: 0.3,
                        fill: true
                    },
                    {
                        label: 'New Posts',
                        data: <?php echo $postActivityJSON; ?>,
                        borderColor: 'rgba(46, 204, 113, 1)',
                        backgroundColor: 'rgba(46, 204, 113, 0.1)',
                        borderWidth: 2,
                        tension: 0.3,
                        fill: true
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: '<?php echo $chartLabel; ?>'
                    },
                    legend: {
                        position: 'top'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            precision: 0
                        }
                    }
                }
            }
        });

        // Initialize word cloud
        const words = <?php echo $wordCloudJSON; ?>;
        
        if (words.length > 0) {
            const width = document.getElementById('wordCloud').offsetWidth;
            const height = 300;
            
            const layout = d3.layout.cloud()
                .size([width, height])
                .words(words)
                .padding(5)
                .rotate(() => ~~(Math.random() * 2) * 90)
                .font("Impact")
                .fontSize(d => Math.sqrt(d.value) * 5)
                .on("end", draw);
                
            layout.start();
            
            function draw(words) {
                d3.select("#wordCloud").append("svg")
                    .attr("width", layout.size()[0])
                    .attr("height", layout.size()[1])
                    .append("g")
                    .attr("transform", `translate(${layout.size()[0] / 2},${layout.size()[1] / 2})`)
                    .selectAll("text")
                    .data(words)
                    .enter().append("text")
                    .style("font-size", d => `${d.size}px`)
                    .style("font-family", "Impact")
                    .style("fill", (d, i) => d3.schemeCategory10[i % 10])
                    .attr("text-anchor", "middle")
                    .attr("transform", d => `translate(${d.x},${d.y})rotate(${d.rotate})`)
                    .text(d => d.text);
            }
        } else {
            document.getElementById('wordCloud').innerHTML = '<div class="no-content"><p>No data available for word cloud</p></div>';
        }
    </script>
</body>
</html> 