<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/session.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Set header to JSON
header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['status' => 'error', 'message' => 'You must be logged in to report content']);
    exit;
}

$user_id = $_SESSION['user_id'];
$response = ['status' => 'error', 'message' => 'Invalid request'];

// Check if this is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Get the action from the request
    $action = isset($_POST['action']) ? $_POST['action'] : '';
    
    switch ($action) {
        case 'submit':
            // Required parameters
            if (!isset($_POST['content_type']) || !isset($_POST['content_id']) || 
                !isset($_POST['reason']) || !isset($_POST['description'])) {
                $response = ['status' => 'error', 'message' => 'Missing required parameters'];
                break;
            }
            
            // Sanitize inputs
            $content_type = mysqli_real_escape_string($conn, $_POST['content_type']);
            $content_id = (int)$_POST['content_id'];
            $reason = mysqli_real_escape_string($conn, $_POST['reason']);
            $description = mysqli_real_escape_string($conn, $_POST['description']);
            
            // Validate content_type
            if (!in_array($content_type, ['post', 'comment', 'user'])) {
                $response = ['status' => 'error', 'message' => 'Invalid content type'];
                break;
            }
            
            // Check if the content exists
            $content_exists = false;
            if ($content_type === 'post') {
                $check = $conn->query("SELECT 1 FROM posts WHERE id = $content_id");
                $content_exists = $check && $check->num_rows > 0;
            } elseif ($content_type === 'comment') {
                $check = $conn->query("SELECT 1 FROM comments WHERE id = $content_id");
                $content_exists = $check && $check->num_rows > 0;
            } elseif ($content_type === 'user') {
                $check = $conn->query("SELECT 1 FROM users WHERE id = $content_id");
                $content_exists = $check && $check->num_rows > 0;
            }
            
            if (!$content_exists) {
                $response = ['status' => 'error', 'message' => 'The reported content does not exist'];
                break;
            }
            
            // Check if user already reported this content
            $check = $conn->query("SELECT 1 FROM reported_content 
                                  WHERE reporter_id = $user_id 
                                  AND content_type = '$content_type' 
                                  AND content_id = $content_id 
                                  AND status IN ('pending', 'reviewed')");
            
            if ($check && $check->num_rows > 0) {
                $response = ['status' => 'error', 'message' => 'You have already reported this content'];
                break;
            }
            
            // Add the report
            $stmt = $conn->prepare("INSERT INTO reported_content 
                                  (reporter_id, content_type, content_id, reason, description) 
                                  VALUES (?, ?, ?, ?, ?)");
            
            $stmt->bind_param("isiss", $user_id, $content_type, $content_id, $reason, $description);
            
            if ($stmt->execute()) {
                $report_id = $stmt->insert_id;
                $stmt->close();
                
                // Get report category ID (or create if not exists)
                $category_id = 0;
                $category_result = $conn->query("SELECT id FROM reports WHERE category = '$reason'");
                
                if ($category_result && $category_result->num_rows > 0) {
                    $category_id = $category_result->fetch_assoc()['id'];
                    
                    // Update report count
                    $conn->query("UPDATE reports SET report_count = report_count + 1 WHERE id = $category_id");
                } else {
                    // Create new category
                    $conn->query("INSERT INTO reports (category) VALUES ('$reason')");
                    $category_id = $conn->insert_id;
                }
                
                // Add mapping between report and reported content
                if ($category_id > 0) {
                    $conn->query("INSERT INTO report_content_map (report_id, reported_content_id) 
                                VALUES ($category_id, $report_id)");
                }
                
                $response = [
                    'status' => 'success',
                    'message' => 'Report submitted successfully. Thank you for helping keep Expressify safe!',
                    'report_id' => $report_id
                ];
            } else {
                $response = ['status' => 'error', 'message' => 'Failed to submit report: ' . $stmt->error];
            }
            break;
            
        case 'check':
            // Check if user has reported a specific content
            if (!isset($_POST['content_type']) || !isset($_POST['content_id'])) {
                $response = ['status' => 'error', 'message' => 'Missing required parameters'];
                break;
            }
            
            $content_type = mysqli_real_escape_string($conn, $_POST['content_type']);
            $content_id = (int)$_POST['content_id'];
            
            // Validate content_type
            if (!in_array($content_type, ['post', 'comment', 'user'])) {
                $response = ['status' => 'error', 'message' => 'Invalid content type'];
                break;
            }
            
            $check = $conn->query("SELECT id, status FROM reported_content 
                                  WHERE reporter_id = $user_id 
                                  AND content_type = '$content_type' 
                                  AND content_id = $content_id");
            
            if ($check && $check->num_rows > 0) {
                $report_info = $check->fetch_assoc();
                $response = [
                    'status' => 'success',
                    'has_reported' => true,
                    'report_status' => $report_info['status'],
                    'report_id' => $report_info['id']
                ];
            } else {
                $response = [
                    'status' => 'success',
                    'has_reported' => false
                ];
            }
            break;
            
        default:
            $response = ['status' => 'error', 'message' => 'Invalid action'];
            break;
    }
}

// Return response
echo json_encode($response); 