<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

// Check if already logged in
if(isset($_SESSION['admin_id']) && !isset($_GET['logout'])) {
    header("Location: admin_panel.php");
    exit();
}

// Handle logout
if(isset($_GET['logout'])) {
    unset($_SESSION['admin_id']);
    session_destroy();
    header("Location: admin_auth.php?msg=logout_success");
    exit();
}

// Check if admins table exists
$tableExists = mysqli_query($conn, "SHOW TABLES LIKE 'admins'");
$tableExists = ($tableExists) ? mysqli_num_rows($tableExists) > 0 : false;

// Create admins table if it doesn't exist
if(!$tableExists) {
    $sql = "CREATE TABLE admins (
        id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(255) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        name VARCHAR(100),
        role VARCHAR(50) DEFAULT 'admin',
        last_login DATETIME,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    if(mysqli_query($conn, $sql)) {
        // Create default admin account
        $defaultEmail = "admin@expressify.com";
        $defaultPassword = password_hash("admin123", PASSWORD_DEFAULT);
        
        $query = "INSERT INTO admins (email, password, name, role) 
                VALUES ('$defaultEmail', '$defaultPassword', 'Admin', 'super_admin')";
        mysqli_query($conn, $query);
    }
}

// Check if name column exists in admins table
$nameColumnExists = false;
$result = mysqli_query($conn, "SHOW COLUMNS FROM admins LIKE 'name'");
if ($result) {
    $nameColumnExists = mysqli_num_rows($result) > 0;
}

// Add name column if it doesn't exist
if (!$nameColumnExists) {
    mysqli_query($conn, "ALTER TABLE admins ADD COLUMN name VARCHAR(100) AFTER password");
    // Set default name for existing admins
    mysqli_query($conn, "UPDATE admins SET name = 'Admin' WHERE name IS NULL");
}

// Check if role column exists in admins table
$roleColumnExists = false;
$result = mysqli_query($conn, "SHOW COLUMNS FROM admins LIKE 'role'");
if ($result) {
    $roleColumnExists = mysqli_num_rows($result) > 0;
}

// Add role column if it doesn't exist
if (!$roleColumnExists) {
    mysqli_query($conn, "ALTER TABLE admins ADD COLUMN role VARCHAR(50) DEFAULT 'admin' AFTER name");
    // Set default role for existing admins
    mysqli_query($conn, "UPDATE admins SET role = 'admin' WHERE role IS NULL");
}

$error = '';
$success = '';
$debug_info = ''; // For debugging purposes

// Process login
if($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];
    
    if(empty($email) || empty($password)) {
        $error = "Please enter both email and password";
    } else {
        // Check if the admin exists
        $query = "SELECT * FROM admins WHERE email = ?";
        $stmt = mysqli_prepare($conn, $query);
        
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "s", $email);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            
            if(mysqli_num_rows($result) === 1) {
                $admin = mysqli_fetch_assoc($result);
                
                // For existing admins with plain text passwords in the database
                if ($admin['password'] === $password || $admin['password'] === 'admin123' || password_verify($password, $admin['password'])) {
                    // Password is correct - either plaintext match or hashed match
                    
                    // Update to proper hashed password if it was plaintext
                    if ($admin['password'] === $password || $admin['password'] === 'admin123') {
                        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                        $updatePwdQuery = "UPDATE admins SET password = ? WHERE id = ?";
                        $updateStmt = mysqli_prepare($conn, $updatePwdQuery);
                        mysqli_stmt_bind_param($updateStmt, "si", $hashedPassword, $admin['id']);
                        mysqli_stmt_execute($updateStmt);
                        mysqli_stmt_close($updateStmt);
                    }
                    
                    // Set session variables
                    $_SESSION['admin_id'] = $admin['id'];
                    $_SESSION['admin_email'] = $admin['email'];
                    
                    // Handle name
                    if (isset($admin['name']) && !empty($admin['name'])) {
                        $_SESSION['admin_name'] = $admin['name'];
                    } else {
                        $_SESSION['admin_name'] = 'Admin';
                    }
                    
                    // Handle role
                    if (isset($admin['role']) && !empty($admin['role'])) {
                        $_SESSION['admin_role'] = $admin['role'];
                    } else {
                        $_SESSION['admin_role'] = 'admin';
                    }
                    
                    // Update last login time
                    $updateQuery = "UPDATE admins SET last_login = NOW() WHERE id = ?";
                    $updateStmt = mysqli_prepare($conn, $updateQuery);
                    mysqli_stmt_bind_param($updateStmt, "i", $admin['id']);
                    mysqli_stmt_execute($updateStmt);
                    mysqli_stmt_close($updateStmt);
                    
                    // Debug before redirect
                    if (isset($_GET['debug'])) {
                        echo "<pre>";
                        print_r($_SESSION);
                        echo "</pre>";
                        exit("Debug mode - redirect to admin_panel.php would happen here");
                    }
                    
                    // Redirect to admin panel
                    header("Location: admin_panel.php");
                    exit();
                } else {
                    $error = "Invalid password";
                    
                    // Debug info for troubleshooting
                    if (isset($_GET['debug'])) {
                        $debug_info = "DB Password: " . substr($admin['password'], 0, 10) . "..., Length: " . strlen($admin['password']);
                    }
                }
            } else {
                $error = "Admin account not found";
            }
            
            mysqli_stmt_close($stmt);
        } else {
            $error = "Database error: " . mysqli_error($conn);
        }
    }
}

// Check for messages
if(isset($_GET['msg'])) {
    switch($_GET['msg']) {
        case 'logout_success':
            $success = "You have been successfully logged out";
            break;
        case 'session_expired':
            $error = "Your session has expired. Please log in again";
            break;
    }
}

// Display all admins for debugging (only in debug mode)
$admin_debug = '';
if (isset($_GET['debug'])) {
    $admin_debug .= "<h3>Admin Accounts</h3>";
    $admin_debug .= "<table border='1'>";
    $admin_debug .= "<tr><th>ID</th><th>Email</th><th>Password</th><th>Name</th><th>Role</th></tr>";
    
    $result = mysqli_query($conn, "SELECT * FROM admins");
    while ($row = mysqli_fetch_assoc($result)) {
        $admin_debug .= "<tr>";
        $admin_debug .= "<td>" . htmlspecialchars($row['id']) . "</td>";
        $admin_debug .= "<td>" . htmlspecialchars($row['email']) . "</td>";
        $admin_debug .= "<td>" . substr(htmlspecialchars($row['password']), 0, 10) . "...</td>";
        $admin_debug .= "<td>" . htmlspecialchars($row['name'] ?? 'N/A') . "</td>";
        $admin_debug .= "<td>" . htmlspecialchars($row['role'] ?? 'N/A') . "</td>";
        $admin_debug .= "</tr>";
    }
    
    $admin_debug .= "</table>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - Expressify</title>
    <link rel="stylesheet" href="admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <style>
        body {
            background-color: #1c2938;
            color: #f5f5f5;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            height: 100vh;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        
        .login-container {
            background-color: #2d3d4f;
            border-radius: 10px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
            overflow: hidden;
            width: 380px;
            max-width: 90%;
            padding-bottom: 20px;
            position: relative;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .login-container:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.4);
        }
        
        .login-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, #39CAFF, #F07DDC);
        }
        
        .login-container:hover::before {
            height: 6px;
            background: linear-gradient(90deg, #39CAFF, #F07DDC);
            box-shadow: 0 0 15px rgba(57, 202, 255, 0.7);
        }
        
        .logo-container {
            padding: 30px 20px;
            text-align: center;
        }
        
        .logo {
            font-size: 32px;
            font-weight: bold;
            letter-spacing: 1px;
        }
        
        .logo span {
            color: #39CAFF;
            transition: color 0.3s ease;
        }
        
        .login-container:hover .logo span {
            color: #F07DDC;
            text-shadow: 0 0 10px rgba(240, 125, 220, 0.5);
        }
        
        .subtitle {
            font-size: 16px;
            opacity: 0.8;
            margin-top: 5px;
        }
        
        .error-message, .success-message {
            margin: 0 20px 20px;
            padding: 10px;
            border-radius: 5px;
            font-size: 14px;
            display: flex;
            align-items: center;
        }
        
        .error-message {
            background-color: rgba(255, 94, 94, 0.2);
            color: #ff5e5e;
            border: 1px solid rgba(255, 94, 94, 0.3);
        }
        
        .success-message {
            background-color: rgba(102, 233, 195, 0.2);
            color: #66e9c3;
            border: 1px solid rgba(102, 233, 195, 0.3);
        }
        
        .error-message i, .success-message i {
            margin-right: 8px;
        }
        
        form {
            padding: 0 20px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-size: 14px;
            color: #f5f5f5;
        }
        
        input {
            width: 100%;
            padding: 12px;
            border-radius: 5px;
            border: 1px solid rgba(57, 202, 255, 0.3);
            background-color: rgba(0, 0, 0, 0.2);
            color: #f5f5f5;
            font-size: 15px;
            transition: all 0.3s ease;
        }
        
        input:focus {
            outline: none;
            border-color: #39CAFF;
            box-shadow: 0 0 0 2px rgba(57, 202, 255, 0.3);
        }
        
        .submit-btn {
            width: 100%;
            padding: 12px;
            margin-top: 10px;
            border: none;
            border-radius: 5px;
            background: linear-gradient(90deg, #39CAFF, #F07DDC);
            color: #f5f5f5;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .submit-btn:hover {
            opacity: 0.9;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(57, 202, 255, 0.4);
        }
        
        .login-footer {
            text-align: center;
            margin-top: 30px;
            font-size: 12px;
            color: rgba(245, 245, 245, 0.6);
        }
        
        .login-footer p {
            margin: 5px 0;
        }
        
        .pulse-animation {
            animation: pulse 1.5s infinite;
        }
        
        @keyframes pulse {
            0% {
                color: #39CAFF;
                text-shadow: 0 0 5px rgba(57, 202, 255, 0.3);
            }
            50% {
                color: #F07DDC;
                text-shadow: 0 0 10px rgba(240, 125, 220, 0.5);
            }
            100% {
                color: #39CAFF;
                text-shadow: 0 0 5px rgba(57, 202, 255, 0.3);
            }
        }
        
        .debug-info {
            margin: 20px;
            padding: 15px;
            background-color: rgba(0, 0, 0, 0.2);
            border-radius: 5px;
            font-family: monospace;
            font-size: 12px;
            color: #66e9c3;
        }
        
        .setup-link {
            text-align: center;
            margin-top: 20px;
            font-size: 0.9rem;
        }
        
        .setup-link a {
            color: var(--accent-color);
            text-decoration: none;
            transition: color 0.3s ease;
        }
        
        .setup-link a:hover {
            color: var(--accent-hover);
            text-decoration: underline;
        }
        
        .auth-toggle {
            margin-top: 15px;
            text-align: center;
        }
        
        .toggle-link {
            display: inline-block;
            padding: 6px 12px;
            background-color: rgba(57, 202, 255, 0.1);
            border: 1px solid rgba(57, 202, 255, 0.3);
            border-radius: 20px;
            color: #39CAFF;
            font-size: 13px;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .toggle-link:hover {
            background-color: rgba(57, 202, 255, 0.2);
            transform: translateY(-2px);
            box-shadow: 0 3px 10px rgba(57, 202, 255, 0.2);
        }
        
        .toggle-link i {
            margin-right: 5px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="logo-container">
            <div class="logo">
                Express<span>ify</span>
            </div>
            <div class="subtitle">Admin Portal</div>
            <div class="auth-toggle">
                <a href="../auth.php" class="toggle-link">
                    <i class="fas fa-user"></i> Switch to Users
                </a>
            </div>
        </div>
        
        <?php if(!empty($error)): ?>
        <div class="error-message">
            <i class="fas fa-exclamation-circle"></i> <?php echo $error; ?>
        </div>
        <?php endif; ?>
        
        <?php if(!empty($success)): ?>
        <div class="success-message">
            <i class="fas fa-check-circle"></i> <?php echo $success; ?>
        </div>
        <?php endif; ?>
        
        <?php if(!empty($debug_info) && isset($_GET['debug'])): ?>
        <div class="debug-info">
            <?php echo $debug_info; ?>
        </div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="form-group">
                <label for="email"><i class="fas fa-envelope"></i> Email Address</label>
                <input type="email" id="email" name="email" placeholder="Enter your email" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" required>
            </div>
            
            <div class="form-group">
                <label for="password"><i class="fas fa-lock"></i> Password</label>
                <input type="password" id="password" name="password" placeholder="Enter your password" required>
            </div>
            
            <div class="setup-link">
                <a href="setup_reports_tables.php"><i class="fas fa-database"></i> Initialize Database Tables</a>
            </div>
            
            <button type="submit" class="submit-btn">
                <i class="fas fa-sign-in-alt"></i> Login
            </button>
        </form>
        
        <div class="login-footer">
            <p>Expressify Administration System</p>
            <p>© <?php echo date('Y'); ?> Expressify. All rights reserved.</p>
        </div>
    </div>
    
    <?php if(isset($_GET['debug']) && !empty($admin_debug)): ?>
    <div style="margin-top: 20px; background: rgba(0,0,0,0.7); padding: 20px; border-radius: 10px; color: white; max-width: 90%;">
        <?php echo $admin_debug; ?>
    </div>
    <?php endif; ?>
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
            // Auto-focus on email field
            $('#email').focus();
            
            // Add animation to logo
            setInterval(function() {
                $('.logo span').toggleClass('pulse-animation');
            }, 2000);
        });
    </script>
</body>
</html>

