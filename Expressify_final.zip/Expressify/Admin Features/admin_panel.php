<?php
require_once '../includes/session.php';
require_once '../includes/config.php';
require_once '../includes/functions.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if admin is logged in
if(!isset($_SESSION['admin_id'])) {
    header("Location: admin_auth.php");
    exit();
}

// Get admin info
$admin_id = $_SESSION['admin_id'];
$admin_name = $_SESSION['admin_name'] ?? 'Admin';
$admin_role = $_SESSION['admin_role'] ?? 'admin';

// Check if reported_content table exists
$table_exists = false;
$create_table_error = null;

try {
    $result = $conn->query("SHOW TABLES LIKE 'reported_content'");
    $table_exists = $result->num_rows > 0;
    
    // Create the reported_content table if it doesn't exist
    if (!$table_exists) {
        $createTableSQL = "CREATE TABLE reported_content (
            id INT PRIMARY KEY AUTO_INCREMENT,
            reporter_id INT NOT NULL,
            content_type ENUM('post', 'comment', 'user') NOT NULL,
            content_id INT NOT NULL,
            reason VARCHAR(100) NOT NULL,
            description TEXT,
            status ENUM('pending', 'reviewed', 'resolved', 'dismissed') DEFAULT 'pending',
            admin_id INT NULL,
            admin_notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX (content_type, content_id),
            INDEX (status),
            INDEX (reporter_id)
        ) CHARSET=utf8mb4";
        
        if ($conn->query($createTableSQL) === TRUE) {
            $table_exists = true;
        } else {
            $create_table_error = "Unable to create reported_content table: " . $conn->error;
        }
    }
} catch (Exception $e) {
    $create_table_error = "Error checking/creating reported_content table: " . $e->getMessage();
}

// Get stats for dashboard
$userCount = 0;
$postCount = 0;
$reportCount = 0;
$newUsersToday = 0;

// Get total users
$userQuery = $conn->query("SELECT COUNT(*) as total FROM users");
if($userQuery) {
    $userCount = $userQuery->fetch_assoc()['total'];
}

// Get total posts
$postQuery = $conn->query("SELECT COUNT(*) as total FROM posts");
if($postQuery) {
    $postCount = $postQuery->fetch_assoc()['total'];
}

// Get total reports
$checkReportsTable = $conn->query("SHOW TABLES LIKE 'reports'");
if($checkReportsTable->num_rows > 0) {
    $reportQuery = $conn->query("SELECT COUNT(*) as total FROM reports");
    if($reportQuery) {
        $reportCount = $reportQuery->fetch_assoc()['total'];
    }
}

// Get new users today
$today = date('Y-m-d');
$newUsersQuery = $conn->query("SELECT COUNT(*) as total FROM users WHERE DATE(created_at) = '$today'");
if($newUsersQuery) {
    $newUsersToday = $newUsersQuery->fetch_assoc()['total'];
}

// Get recent users
$recentUsers = [];
$recentUsersQuery = $conn->query("SELECT id, username, email, profile_picture, created_at FROM users ORDER BY created_at DESC LIMIT 5");
if($recentUsersQuery) {
    while($user = $recentUsersQuery->fetch_assoc()) {
        $recentUsers[] = $user;
    }
}

// Get recent posts
$recentPosts = [];
$recentPostsQuery = $conn->query("SELECT p.id, p.content, p.created_at, u.username, u.profile_picture 
                                 FROM posts p
                                 JOIN users u ON p.user_id = u.id
                                 ORDER BY p.created_at DESC LIMIT 5");
if($recentPostsQuery) {
    while($post = $recentPostsQuery->fetch_assoc()) {
        $recentPosts[] = $post;
    }
}

// Function to format date
function formatDate($date) {
    return date('M d, Y', strtotime($date));
}

// Function to truncate text
function truncateText($text, $length = 100) {
    if(strlen($text) <= $length) {
        return $text;
    }
    return substr($text, 0, $length) . '...';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Expressify Admin</title>
    <link rel="stylesheet" href="admin_style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
</head>
<body>
    <div class="admin-container">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-brand">
                <h1>Express<span>ify</span></h1>
                <p>Admin Panel</p>
            </div>
            <ul class="sidebar-menu">
                <li><a href="admin_panel.php" class="active">
                    <i class="fas fa-tachometer-alt"></i> Dashboard
                </a></li>
                <li><a href="admin_user_management.php">
                    <i class="fas fa-users"></i> User Management
                </a></li>
                <li><a href="admin_post_management.php">
                    <i class="fas fa-file-alt"></i> Post Management
                </a></li>
                <li><a href="content_analysis.php">
                    <i class="fas fa-chart-line"></i> Content Analysis
                </a></li>
                <li><a href="admin_settings.php">
                    <i class="fas fa-cog"></i> Settings
                </a></li>
            </ul>
            <div class="sidebar-footer">
                <a href="../index.php"><i class="fas fa-sign-out-alt"></i> Back to Site</a>
                <a href="admin_auth.php?logout=1"><i class="fas fa-power-off"></i> Logout</a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <div class="header">
                <h1>Dashboard</h1>
                <div class="user-actions">
                    <a href="#" title="Notifications"><i class="fas fa-bell"></i></a>
                    <a href="#" title="Profile"><i class="fas fa-user-circle"></i> Admin</a>
                    <a href="admin_auth.php?logout=true" title="Logout"><i class="fas fa-sign-out-alt"></i></a>
                </div>
            </div>

            <?php if(isset($create_table_error)): ?>
            <div class="system-alert">
                <i class="fas fa-exclamation-triangle"></i>
                <div class="alert-content">
                    <strong>System Notice:</strong> <?php echo $create_table_error; ?>
                    <p>Some features may not be available until this is resolved.</p>
                </div>
            </div>
            <?php endif; ?>

            <!-- Stats Cards -->
            <div class="stats-container">
                <div class="stat-card">
                    <div class="stat-card-icon" style="background-color: rgba(52, 152, 219, 0.2);">
                        <i class="fas fa-users" style="color: #3498db;"></i>
                    </div>
                    <div class="stat-card-info">
                        <h3>Total Users</h3>
                        <p class="stat-number"><?php echo $userCount; ?></p>
                        <p class="stat-change positive">+<?php echo $newUsersToday; ?> today</p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-card-icon" style="background-color: rgba(46, 204, 113, 0.2);">
                        <i class="fas fa-file-alt" style="color: #2ecc71;"></i>
                    </div>
                    <div class="stat-card-info">
                        <h3>Total Posts</h3>
                        <p class="stat-number"><?php echo $postCount; ?></p>
                    </div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-card-icon" style="background-color: rgba(231, 76, 60, 0.2);">
                        <i class="fas fa-flag" style="color: #e74c3c;"></i>
                    </div>
                    <div class="stat-card-info">
                        <h3>Reports</h3>
                        <p class="stat-number"><?php echo $reportCount; ?></p>
                    </div>
                </div>
            </div>

            <!-- Recent Activity -->
            <div class="dashboard-row">
                <div class="dashboard-card">
                    <div class="card-header">
                        <h3><i class="fas fa-users"></i> Recently Registered Users</h3>
                        <a href="admin_user_management.php" class="view-all">View All</a>
                    </div>
                    <div class="card-content">
                        <?php if(count($recentUsers) > 0): ?>
                            <div class="table-responsive">
                                <table class="dashboard-table">
                                    <thead>
                                        <tr>
                                            <th>User</th>
                                            <th>Email</th>
                                            <th>Joined</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($recentUsers as $user): ?>
                                        <tr>
                                            <td>
                                                <div class="user-info">
                                                    <img src="<?php echo !empty($user['profile_picture']) ? '../' . $user['profile_picture'] : '../assets/default_profile.png'; ?>" alt="Profile">
                                                    <span><?php echo htmlspecialchars($user['username']); ?></span>
                                                </div>
                                            </td>
                                            <td><?php echo htmlspecialchars($user['email']); ?></td>
                                            <td><?php echo formatDate($user['created_at']); ?></td>
                                            <td>
                                                <a href="admin_user_management.php?view=<?php echo $user['id']; ?>" class="btn btn-sm btn-primary">
                                                    <i class="fas fa-eye"></i> View
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="no-content">
                                <p>No users found</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="dashboard-card">
                    <div class="card-header">
                        <h3><i class="fas fa-file-alt"></i> Recent Posts</h3>
                        <a href="admin_post_management.php" class="view-all">View All</a>
                    </div>
                    <div class="card-content">
                        <?php if(count($recentPosts) > 0): ?>
                            <div class="recent-posts">
                                <?php foreach($recentPosts as $post): ?>
                                <div class="recent-post-item">
                                    <div class="post-author">
                                        <img src="<?php echo !empty($post['profile_picture']) ? '../' . $post['profile_picture'] : '../assets/default_profile.png'; ?>" alt="Profile">
                                        <div>
                                            <span class="author-name"><?php echo htmlspecialchars($post['username']); ?></span>
                                            <span class="post-date"><?php echo formatDate($post['created_at']); ?></span>
                                        </div>
                                    </div>
                                    <div class="post-preview">
                                        <?php echo htmlspecialchars(truncateText($post['content'], 100)); ?>
                                    </div>
                                    <div class="post-actions">
                                        <a href="admin_post_management.php?action=view&id=<?php echo $post['id']; ?>" class="btn btn-sm btn-primary">
                                            <i class="fas fa-eye"></i> View
                                        </a>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <div class="no-content">
                                <p>No posts found</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="dashboard-card full-width">
                <div class="card-header">
                    <h3><i class="fas fa-bolt"></i> Quick Actions</h3>
                </div>
                <div class="card-content">
                    <div class="quick-actions">
                        <a href="admin_user_management.php" class="quick-action-card">
                            <i class="fas fa-user-plus"></i>
                            <span>Manage Users</span>
                        </a>
                        <a href="admin_post_management.php" class="quick-action-card">
                            <i class="fas fa-edit"></i>
                            <span>Manage Posts</span>
                        </a>
                        <a href="admin_report_management.php" class="quick-action-card">
                            <i class="fas fa-flag"></i>
                            <span>Handle Reports</span>
                        </a>
                        <a href="content_analysis.php" class="quick-action-card">
                            <i class="fas fa-chart-line"></i>
                            <span>View Analytics</span>
                        </a>
                        <a href="admin_settings.php" class="quick-action-card">
                            <i class="fas fa-cog"></i>
                            <span>Settings</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <style>
        /* Additional styles for dashboard */
        .dashboard-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        
        .dashboard-table th, .dashboard-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid rgba(57, 202, 255, 0.2);
        }
        
        .dashboard-table th {
            background-color: rgba(0, 0, 0, 0.2);
            color: var(--text-color);
            font-weight: 500;
        }
        
        .dashboard-table tr:hover {
            background-color: rgba(57, 202, 255, 0.05);
        }
        
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 20px;
            padding: 15px;
        }
        
        .quick-action-card {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px;
            background-color: rgba(0, 0, 0, 0.2);
            border: 1px solid rgba(57, 202, 255, 0.3);
            border-radius: var(--border-radius);
            color: var(--text-color);
            text-decoration: none;
            transition: all 0.3s ease;
            text-align: center;
        }
        
        .quick-action-card:hover {
            transform: translateY(-5px);
            background-color: rgba(57, 202, 255, 0.2);
            box-shadow: 0 5px 15px rgba(57, 202, 255, 0.2);
        }
        
        .quick-action-card i {
            font-size: 24px;
            margin-bottom: 10px;
            color: var(--accent-color);
        }
        
        .no-data {
            padding: 20px;
            text-align: center;
            color: var(--text-color);
            opacity: 0.7;
        }
        
        .btn-sm {
            padding: 5px 10px;
            font-size: 12px;
        }
        
        .system-alert {
            margin: 0 15px 20px;
            padding: 15px;
            border-radius: 5px;
            background-color: rgba(255, 155, 0, 0.1);
            border: 1px solid rgba(255, 155, 0, 0.3);
            display: flex;
            align-items: flex-start;
        }
        
        .system-alert i {
            color: #ff9b00;
            font-size: 20px;
            margin-right: 15px;
            margin-top: 2px;
        }
        
        .alert-content {
            flex: 1;
        }
        
        .alert-content strong {
            display: block;
            margin-bottom: 5px;
            color: #ff9b00;
        }
        
        .alert-content p {
            margin: 5px 0 0;
            opacity: 0.8;
        }

        .sidebar-footer {
            margin-top: auto;
            padding: 20px;
            border-top: 1px solid var(--border);
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        
        .sidebar-footer a {
            display: flex;
            align-items: center;
            gap: 10px;
            color: var(--text-secondary);
            text-decoration: none;
            padding: 10px 15px;
            border-radius: 6px;
            transition: all 0.2s ease;
        }
        
        .sidebar-footer a:hover {
            background-color: var(--card-bg-hover);
            color: var(--accent);
        }
    </style>
</body>
</html>
