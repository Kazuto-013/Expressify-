<?php
require_once '../includes/session.php';
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once 'admin_sidebar.php';

// Check if admin is logged in
if(!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// Initialize variables
$timeframe = isset($_GET['timeframe']) ? $_GET['timeframe'] : '7days';
$contentType = isset($_GET['content_type']) ? $_GET['content_type'] : 'all';
$analysisType = isset($_GET['analysis_type']) ? $_GET['analysis_type'] : 'overview';

// Get date range based on timeframe
$endDate = date('Y-m-d H:i:s');
switch($timeframe) {
    case '24hours':
        $startDate = date('Y-m-d H:i:s', strtotime('-24 hours'));
        break;
    case '7days':
        $startDate = date('Y-m-d H:i:s', strtotime('-7 days'));
        break;
    case '30days':
        $startDate = date('Y-m-d H:i:s', strtotime('-30 days'));
        break;
    case 'custom':
        $startDate = isset($_GET['start_date']) ? $_GET['start_date'] : date('Y-m-d H:i:s', strtotime('-7 days'));
        $endDate = isset($_GET['end_date']) ? $_GET['end_date'] : date('Y-m-d H:i:s');
        break;
    default:
        $startDate = date('Y-m-d H:i:s', strtotime('-7 days'));
}

// Check and add quality_score column if it doesn't exist
$alterQueries = [
    "ALTER TABLE content_analysis 
     ADD COLUMN IF NOT EXISTS quality_score DECIMAL(3,2) DEFAULT 0.00",
    
    "ALTER TABLE content_analysis 
     ADD COLUMN IF NOT EXISTS readability_score DECIMAL(3,2) DEFAULT 0.00",
     
    "ALTER TABLE content_analysis 
     ADD COLUMN IF NOT EXISTS emotion_scores JSON DEFAULT NULL"
];

foreach ($alterQueries as $query) {
    try {
        $conn->query($query);
    } catch (Exception $e) {
        // Log error but continue with other queries
        error_log("Error executing query: " . $e->getMessage());
        continue;
    }
}

// Create content_analysis table if it doesn't exist
$createTableQuery = "CREATE TABLE IF NOT EXISTS content_analysis (
    id INT PRIMARY KEY AUTO_INCREMENT,
    content_id INT NOT NULL,
    content_type ENUM('post', 'comment') NOT NULL,
    toxicity_score DECIMAL(3,2) DEFAULT 0.00,
    sentiment_score DECIMAL(3,2) DEFAULT 0.00,
    spam_probability DECIMAL(3,2) DEFAULT 0.00,
    engagement_score DECIMAL(3,2) DEFAULT 0.00,
    quality_score DECIMAL(3,2) DEFAULT 0.00,
    readability_score DECIMAL(3,2) DEFAULT 0.00,
    emotion_scores JSON DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (content_id) REFERENCES posts(id) ON DELETE CASCADE
)";

try {
    $conn->query($createTableQuery);
} catch (Exception $e) {
    error_log("Error creating content_analysis table: " . $e->getMessage());
}

// Create numbers table if it doesn't exist (used for string splitting)
$createNumbersTable = "CREATE TABLE IF NOT EXISTS numbers (
    n INT PRIMARY KEY AUTO_INCREMENT
)";

try {
    $conn->query($createNumbersTable);
    
    // Populate numbers table if empty (only need numbers 1 to 100 for word splitting)
    $checkNumbers = "SELECT COUNT(*) as count FROM numbers";
    $result = $conn->query($checkNumbers);
    $count = $result->fetch_assoc()['count'];
    
    if ($count == 0) {
        $insertNumbers = "INSERT INTO numbers (n) VALUES ";
        $values = array();
        for ($i = 1; $i <= 100; $i++) {
            $values[] = "($i)";
        }
        $insertNumbers .= implode(',', $values);
        $conn->query($insertNumbers);
    }
} catch (Exception $e) {
    error_log("Error creating/populating numbers table: " . $e->getMessage());
}

// Function to get content metrics
function getContentMetrics($conn, $startDate, $endDate, $contentType) {
    $metrics = [
        'total_content' => 0,
        'avg_toxicity' => 0,
        'avg_sentiment' => 0,
        'avg_engagement' => 0,
        'flagged_content' => 0,
        'positive_content' => 0,
        'negative_content' => 0,
        'neutral_content' => 0
    ];

    $whereClause = $contentType !== 'all' ? "AND content_type = ?" : "";
    
    $query = "SELECT 
        COUNT(*) as total,
        AVG(toxicity_score) as avg_toxicity,
        AVG(sentiment_score) as avg_sentiment,
        AVG(engagement_score) as avg_engagement,
        SUM(CASE WHEN toxicity_score > 0.7 THEN 1 ELSE 0 END) as flagged,
        SUM(CASE WHEN sentiment_score > 0.3 THEN 1 ELSE 0 END) as positive,
        SUM(CASE WHEN sentiment_score < -0.3 THEN 1 ELSE 0 END) as negative,
        SUM(CASE WHEN sentiment_score BETWEEN -0.3 AND 0.3 THEN 1 ELSE 0 END) as neutral
        FROM content_analysis
        WHERE created_at BETWEEN ? AND ? $whereClause";

    $stmt = $conn->prepare($query);
    
    if($contentType !== 'all') {
        $stmt->bind_param("sss", $startDate, $endDate, $contentType);
        } else {
        $stmt->bind_param("ss", $startDate, $endDate);
    }
    
    $stmt->execute();
    $result = $stmt->get_result()->fetch_assoc();
    
    if($result) {
        $metrics = [
            'total_content' => $result['total'],
            'avg_toxicity' => round($result['avg_toxicity'] * 100, 2),
            'avg_sentiment' => round($result['avg_sentiment'] * 100, 2),
            'avg_engagement' => round($result['avg_engagement'] * 100, 2),
            'flagged_content' => $result['flagged'],
            'positive_content' => $result['positive'],
            'negative_content' => $result['negative'],
            'neutral_content' => $result['neutral']
        ];
    }
    
    return $metrics;
}

// Get trending topics
function getTrendingTopics($conn, $startDate, $endDate) {
    try {
        $query = "SELECT word, COUNT(*) as frequency 
                 FROM (
                     SELECT DISTINCT p.id,
                            LOWER(
                                SUBSTRING_INDEX(
                                    SUBSTRING_INDEX(
                                        REPLACE(REPLACE(REPLACE(content, '.', ' '), ',', ' '), '!', ' '),
                                        ' ',
                                        n
                                    ),
                                    ' ',
                                    -1
                                )
                            ) as word
                     FROM posts p
                     CROSS JOIN numbers n
                     WHERE n <= (
                         LENGTH(content) - LENGTH(REPLACE(content, ' ', '')) + 1
                     )
                     AND p.created_at BETWEEN ? AND ?
                 ) as words
                 WHERE LENGTH(word) > 3
                 AND word NOT IN ('this', 'that', 'these', 'those', 'then', 'than', 'they', 'them', 'what', 'when', 'where', 'which', 'with')
                 GROUP BY word
                 HAVING frequency > 1
                 ORDER BY frequency DESC
                 LIMIT 10";
                 
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ss", $startDate, $endDate);
        $stmt->execute();
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    } catch (Exception $e) {
        error_log("Error in getTrendingTopics: " . $e->getMessage());
        return [];
    }
}

// Get user engagement metrics
function getUserEngagementMetrics($conn, $startDate, $endDate) {
    $query = "SELECT 
        u.username,
        COUNT(DISTINCT p.id) as post_count,
        COUNT(DISTINCT c.id) as comment_count,
        COUNT(DISTINCT l.id) as like_count,
        (COUNT(DISTINCT p.id) + COUNT(DISTINCT c.id) + COUNT(DISTINCT l.id)) as total_engagement
        FROM users u
        LEFT JOIN posts p ON u.id = p.user_id AND p.created_at BETWEEN ? AND ?
        LEFT JOIN comments c ON u.id = c.user_id AND c.created_at BETWEEN ? AND ?
        LEFT JOIN likes l ON u.id = l.user_id AND l.created_at BETWEEN ? AND ?
        GROUP BY u.id
        ORDER BY total_engagement DESC
        LIMIT 10";
        
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssssss", $startDate, $endDate, $startDate, $endDate, $startDate, $endDate);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

// Get content metrics
$metrics = getContentMetrics($conn, $startDate, $endDate, $contentType);
$trendingTopics = getTrendingTopics($conn, $startDate, $endDate);
$userEngagement = getUserEngagementMetrics($conn, $startDate, $endDate);

// Get overall statistics
$stats_query = "
    SELECT 
        COALESCE(AVG(toxicity_score), 0) as avg_toxicity,
        COALESCE(AVG(sentiment_score), 0) as avg_sentiment,
        COALESCE(AVG(spam_probability), 0) as avg_spam,
        COALESCE(AVG(CASE WHEN quality_score IS NOT NULL THEN quality_score ELSE 0 END), 0) as avg_quality,
        COALESCE(AVG(CASE WHEN readability_score IS NOT NULL THEN readability_score ELSE 0 END), 0) as avg_readability,
        COUNT(*) as total_analyzed
    FROM content_analysis
";

try {
    $stats_result = $conn->query($stats_query);
    if (!$stats_result) {
        // If the query fails, try a simpler version without the new columns
        $stats_query = "
            SELECT 
                COALESCE(AVG(toxicity_score), 0) as avg_toxicity,
                COALESCE(AVG(sentiment_score), 0) as avg_sentiment,
                COALESCE(AVG(spam_probability), 0) as avg_spam,
                0 as avg_quality,
                0 as avg_readability,
                COUNT(*) as total_analyzed
            FROM content_analysis
        ";
        $stats_result = $conn->query($stats_query);
    }
    $overall_stats = $stats_result->fetch_assoc();
} catch (Exception $e) {
    error_log("Error getting statistics: " . $e->getMessage());
    $overall_stats = [
        'avg_toxicity' => 0,
        'avg_sentiment' => 0,
        'avg_spam' => 0,
        'avg_quality' => 0,
        'avg_readability' => 0,
        'total_analyzed' => 0
    ];
}

// Get trend data for the last 30 days with proper column handling
$trend_query = "
    SELECT 
        DATE(created_at) as date,
        COALESCE(AVG(toxicity_score), 0) as toxicity,
        COALESCE(AVG(sentiment_score), 0) as sentiment,
        COALESCE(AVG(CASE WHEN quality_score IS NOT NULL THEN quality_score ELSE 0 END), 0) as quality
    FROM content_analysis
    WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    GROUP BY DATE(created_at)
    ORDER BY date
";

try {
    $trend_result = $conn->query($trend_query);
    if (!$trend_result) {
        // Fallback query without quality_score
        $trend_query = "
            SELECT 
                DATE(created_at) as date,
                COALESCE(AVG(toxicity_score), 0) as toxicity,
                COALESCE(AVG(sentiment_score), 0) as sentiment,
                0 as quality
            FROM content_analysis
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
            GROUP BY DATE(created_at)
            ORDER BY date
        ";
        $trend_result = $conn->query($trend_query);
    }
    $trend_data = [];
    while ($row = $trend_result->fetch_assoc()) {
        $trend_data[] = $row;
    }
} catch (Exception $e) {
    error_log("Error getting trend data: " . $e->getMessage());
    $trend_data = [];
}

// Get distribution of sentiment scores
$sentiment_dist_query = "
    SELECT 
        CASE 
            WHEN sentiment_score < 0.2 THEN 'Very Negative'
            WHEN sentiment_score < 0.4 THEN 'Negative'
            WHEN sentiment_score < 0.6 THEN 'Neutral'
            WHEN sentiment_score < 0.8 THEN 'Positive'
            ELSE 'Very Positive'
        END as sentiment_category,
        COUNT(*) as count
    FROM content_analysis
    GROUP BY sentiment_category
    ORDER BY sentiment_category
";
$sentiment_dist_result = $conn->query($sentiment_dist_query);
$sentiment_distribution = [];
while ($row = $sentiment_dist_result->fetch_assoc()) {
    $sentiment_distribution[] = $row;
}

// Get content type analysis
$content_type_query = "
    SELECT 
        content_type,
        AVG(toxicity_score) as avg_toxicity,
        AVG(sentiment_score) as avg_sentiment,
        COUNT(*) as count
    FROM content_analysis
    GROUP BY content_type
";
$content_type_result = $conn->query($content_type_query);
$content_type_stats = [];
while ($row = $content_type_result->fetch_assoc()) {
    $content_type_stats[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Content Analysis - Expressify Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* Main content styles */
        .admin-main {
            margin-left: var(--sidebar-width);
            padding: 2rem;
            transition: margin-left var(--transition-speed) ease;
        }

        .admin-sidebar.collapsed + .admin-main {
            margin-left: var(--sidebar-collapsed-width);
        }

        @media (max-width: 768px) {
            .admin-main {
                margin-left: 0;
            }
        }

        /* Rest of your existing styles */
        .content-wrapper {
            padding: 15px;
            max-width: 1200px;
            margin: 0 auto;
        }

        .header {
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 10px;
        }

        .header h1 {
            font-size: 20px;
            margin: 0;
        }

        .filters {
            display: flex;
            gap: 10px;
        }

        .filters select {
            padding: 5px 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            background: white;
            font-size: 13px;
        }

        .dashboard-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
            margin-bottom: 20px;
        }

        .metric-card {
            background: white;
            padding: 15px;
            border-radius: 6px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }

        .metric-title {
            color: #666;
            font-size: 13px;
            margin-bottom: 8px;
        }

        .metric-value {
            font-size: 20px;
            font-weight: bold;
            color: #333;
        }

        .charts-row {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 15px;
            margin-bottom: 15px;
        }

        .chart-container {
            background: white;
            padding: 15px;
            border-radius: 6px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }

        .chart-title {
            font-size: 14px;
            color: #333;
            margin-bottom: 10px;
        }

        .small-chart {
            height: 200px !important;
        }

        .pie-chart {
            height: 200px !important;
        }

        .bottom-charts {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
        }

        .mini-chart {
            height: 150px !important;
        }

        @media (max-width: 1024px) {
            .dashboard-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .charts-row {
                grid-template-columns: 1fr;
            }

            .bottom-charts {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                gap: 10px;
                align-items: flex-start;
            }

            .filters {
                width: 100%;
                flex-wrap: wrap;
            }

            .bottom-charts {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <?php 
    require_once '../includes/session.php';
    require_once '../includes/config.php';
    require_once 'admin_sidebar.php';
    
    // Your existing PHP code here
    ?>

    <main class="admin-main">
        <div class="content-wrapper">
            <div class="header">
                <h1>Content Analysis</h1>
                <div class="filters">
                    <select id="timeRange">
                        <option value="7d" selected>Last 7 Days</option>
                        <option value="30d">Last 30 Days</option>
                        <option value="90d">Last 90 Days</option>
                    </select>
                    <select id="contentType">
                        <option value="all" selected>All Content</option>
                        <option value="posts">Posts</option>
                        <option value="comments">Comments</option>
                    </select>
                </div>
            </div>

            <div class="dashboard-grid">
                <div class="metric-card">
                    <div class="metric-title">Safety Score</div>
                    <div class="metric-value" id="safetyScore">-</div>
                </div>
                <div class="metric-card">
                    <div class="metric-title">Sentiment Score</div>
                    <div class="metric-value" id="sentimentScore">-</div>
                </div>
                <div class="metric-card">
                    <div class="metric-title">Engagement Rate</div>
                    <div class="metric-value" id="engagementScore">-</div>
                </div>
                <div class="metric-card">
                    <div class="metric-title">Total Analyzed</div>
                    <div class="metric-value" id="totalAnalyzed">-</div>
                </div>
            </div>

            <div class="charts-row">
                <div class="chart-container">
                    <div class="chart-title">Content Analysis Trends</div>
                    <canvas id="trendsChart" class="small-chart"></canvas>
                </div>
                <div class="chart-container">
                    <div class="chart-title">Content Distribution</div>
                    <canvas id="distributionChart" class="pie-chart"></canvas>
                </div>
            </div>

            <div class="bottom-charts">
                <div class="chart-container">
                    <div class="chart-title">Safety Metrics</div>
                    <canvas id="safetyChart" class="mini-chart"></canvas>
                </div>
                <div class="chart-container">
                    <div class="chart-title">Engagement Trends</div>
                    <canvas id="engagementChart" class="mini-chart"></canvas>
                </div>
                <div class="chart-container">
                    <div class="chart-title">Content Types</div>
                    <canvas id="contentTypeChart" class="mini-chart"></canvas>
                </div>
            </div>
        </div>
    </main>

    <script>
        // Initialize charts with smaller sizes
        const trendsChart = new Chart(document.getElementById('trendsChart'), {
            type: 'line',
            data: {
                labels: [],
                datasets: [
                    {
                        label: 'Safety',
                        borderColor: '#4CAF50',
                        data: []
                    },
                    {
                        label: 'Sentiment',
                        borderColor: '#2196F3',
                        data: []
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                            font: { size: 11 }
                        }
                    },
                    x: {
                        ticks: {
                            font: { size: 11 }
                        }
                    }
                },
                plugins: {
                    legend: {
                        position: 'top',
                        labels: {
                            font: { size: 11 }
                        }
                    }
                }
            }
        });

        const distributionChart = new Chart(document.getElementById('distributionChart'), {
            type: 'doughnut',
            data: {
                labels: ['Safe', 'Moderate', 'Risky'],
                datasets: [{
                    data: [70, 20, 10],
                    backgroundColor: ['#4CAF50', '#FFC107', '#F44336']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'right',
                        labels: {
                            font: { size: 11 }
                          }
                    }
                }
            }
        });

        const safetyChart = new Chart(document.getElementById('safetyChart'), {
            type: 'bar',
            data: {
                labels: ['Toxic', 'Spam', 'Safe'],
                datasets: [{
                    data: [15, 25, 60],
                    backgroundColor: ['#F44336', '#FFC107', '#4CAF50']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                            font: { size: 10 }
                        }
                    },
                    x: {
                        ticks: {
                            font: { size: 10 }
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });

        const engagementChart = new Chart(document.getElementById('engagementChart'), {
            type: 'line',
            data: {
                labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
                datasets: [{
                    label: 'Engagement',
                    data: [65, 75, 70, 80, 85],
                    borderColor: '#2196F3'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                            font: { size: 10 }
                        }
                    },
                    x: {
                        ticks: {
                            font: { size: 10 }
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
        
        const contentTypeChart = new Chart(document.getElementById('contentTypeChart'), {
            type: 'pie',
            data: {
                labels: ['Posts', 'Comments'],
                datasets: [{
                    data: [60, 40],
                    backgroundColor: ['#2196F3', '#9C27B0']
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'right',
                        labels: {
                            font: { size: 10 }
                        }
                    }
                }
            }
        });
        
        // Function to update dashboard data
        async function updateDashboard() {
            const timeRange = document.getElementById('timeRange').value;
            const contentType = document.getElementById('contentType').value;
            
            try {
                const response = await fetch(`get_analysis_data.php?timeRange=${timeRange}&contentType=${contentType}`);
                const data = await response.json();
                
                // Update metrics
                document.getElementById('safetyScore').textContent = `${data.safety_score}%`;
                document.getElementById('sentimentScore').textContent = `${data.sentiment_score}%`;
                document.getElementById('engagementScore').textContent = `${data.engagement_rate}%`;
                document.getElementById('totalAnalyzed').textContent = data.total_analyzed;
                
                // Update charts
                updateCharts(data);
                
            } catch (error) {
                console.error('Error updating dashboard:', error);
            }
        }

        function updateCharts(data) {
            // Update trends chart
            trendsChart.data.labels = data.trends.dates;
            trendsChart.data.datasets[0].data = data.trends.safety;
            trendsChart.data.datasets[1].data = data.trends.sentiment;
            trendsChart.update();

            // Update other charts with their respective data
            distributionChart.data.datasets[0].data = data.distribution;
            distributionChart.update();

            safetyChart.data.datasets[0].data = data.safety_metrics;
            safetyChart.update();

            engagementChart.data.datasets[0].data = data.engagement_trend;
            engagementChart.update();

            contentTypeChart.data.datasets[0].data = data.content_distribution;
            contentTypeChart.update();
        }

        // Add event listeners
        document.getElementById('timeRange').addEventListener('change', updateDashboard);
        document.getElementById('contentType').addEventListener('change', updateDashboard);

        // Initial load
        updateDashboard();
    </script>
</body>
</html>
