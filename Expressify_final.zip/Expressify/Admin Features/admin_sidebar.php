<?php
if(!isset($_SESSION['admin_id'])) {
    header("Location: admin_login.php");
    exit();
}

// Get current page name
$current_page = basename($_SERVER['PHP_SELF']);
?>

<div class="admin-sidebar">
    <div class="sidebar-header">
        <div class="logo">
            <i class="fas fa-shield-alt"></i>
            <span>Expressify Admin</span>
        </div>
        <button class="sidebar-toggle">
            <i class="fas fa-bars"></i>
        </button>
    </div>

    <nav class="sidebar-nav">
        <ul>
            <li class="<?php echo $current_page === 'admin_dashboard.php' ? 'active' : ''; ?>">
                <a href="admin_dashboard.php">
                    <i class="fas fa-home"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="<?php echo $current_page === 'admin_user_management.php' ? 'active' : ''; ?>">
                <a href="admin_user_management.php">
                    <i class="fas fa-users"></i>
                    <span>User Management</span>
                </a>
            </li>
            <li class="<?php echo $current_page === 'admin_content_management.php' ? 'active' : ''; ?>">
                <a href="admin_content_management.php">
                    <i class="fas fa-file-alt"></i>
                    <span>Content Management</span>
                </a>
            </li>
            <li class="<?php echo $current_page === 'admin_analysis.php' ? 'active' : ''; ?>">
                <a href="admin_analysis.php">
                    <i class="fas fa-chart-bar"></i>
                    <span>Content Analysis</span>
                </a>
            </li>
            <li class="<?php echo $current_page === 'admin_settings.php' ? 'active' : ''; ?>">
                <a href="admin_settings.php">
                    <i class="fas fa-cog"></i>
                    <span>Settings</span>
                </a>
            </li>
        </ul>
    </nav>

    <div class="sidebar-footer">
        <div class="admin-info">
            <img src="<?php echo isset($_SESSION['admin_avatar']) ? $_SESSION['admin_avatar'] : 'assets/default-avatar.png'; ?>" 
                 alt="Admin Avatar" class="admin-avatar">
            <div class="admin-details">
                <span class="admin-name"><?php echo $_SESSION['admin_username'] ?? 'Admin'; ?></span>
                <span class="admin-role">Administrator</span>
            </div>
        </div>
        <div class="footer-actions">
            <a href="admin_profile.php" class="footer-btn" title="Profile">
                <i class="fas fa-user"></i>
            </a>
            <a href="admin_settings.php" class="footer-btn" title="Settings">
                <i class="fas fa-cog"></i>
            </a>
            <a href="admin_logout.php" class="footer-btn" title="Logout">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </div>
    </div>
</div>

<style>
:root {
    --sidebar-width: 260px;
    --sidebar-collapsed-width: 70px;
    --primary-color: #4a90e2;
    --secondary-color: #2c3e50;
    --bg-dark: #1a1f2c;
    --bg-darker: #151923;
    --text-primary: #e4e6eb;
    --text-secondary: #b0b3b8;
    --border-color: #2d3748;
    --hover-bg: rgba(255, 255, 255, 0.1);
    --transition-speed: 0.3s;
}

.admin-sidebar {
    position: fixed;
    left: 0;
    top: 0;
    bottom: 0;
    width: var(--sidebar-width);
    background-color: var(--bg-dark);
    color: var(--text-primary);
    display: flex;
    flex-direction: column;
    transition: width var(--transition-speed) ease;
    z-index: 1000;
    box-shadow: 2px 0 5px rgba(0, 0, 0, 0.2);
}

.sidebar-header {
    padding: 1.5rem;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 1px solid var(--border-color);
    background-color: var(--bg-darker);
}

.logo {
    display: flex;
    align-items: center;
    gap: 0.8rem;
    font-size: 1.2rem;
    font-weight: 600;
}

.logo i {
    font-size: 1.5rem;
    color: var(--primary-color);
}

.sidebar-toggle {
    background: none;
    border: none;
    color: var(--text-secondary);
    cursor: pointer;
    padding: 0.5rem;
    display: none;
}

.sidebar-nav {
    flex: 1;
    overflow-y: auto;
    padding: 1rem 0;
}

.sidebar-nav ul {
    list-style: none;
    padding: 0;
    margin: 0;
}

.sidebar-nav li {
    margin: 0.2rem 0;
}

.sidebar-nav a {
    display: flex;
    align-items: center;
    padding: 0.8rem 1.5rem;
    color: var(--text-secondary);
    text-decoration: none;
    transition: all var(--transition-speed) ease;
    gap: 1rem;
}

.sidebar-nav a:hover {
    background-color: var(--hover-bg);
    color: var(--text-primary);
}

.sidebar-nav li.active a {
    background-color: var(--primary-color);
    color: white;
}

.sidebar-nav i {
    width: 1.5rem;
    text-align: center;
}

.sidebar-footer {
    padding: 1rem 1.5rem;
    border-top: 1px solid var(--border-color);
    background-color: var(--bg-darker);
}

.admin-info {
    display: flex;
    align-items: center;
    gap: 1rem;
    padding-bottom: 1rem;
    border-bottom: 1px solid var(--border-color);
    margin-bottom: 1rem;
}

.admin-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    object-fit: cover;
}

.admin-details {
    display: flex;
    flex-direction: column;
}

.admin-name {
    font-weight: 600;
    color: var(--text-primary);
}

.admin-role {
    font-size: 0.8rem;
    color: var(--text-secondary);
}

.footer-actions {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.footer-btn {
    color: var(--text-secondary);
    text-decoration: none;
    padding: 0.5rem;
    border-radius: 0.5rem;
    transition: all var(--transition-speed) ease;
}

.footer-btn:hover {
    color: var(--text-primary);
    background-color: var(--hover-bg);
}

/* Collapsed sidebar styles */
.admin-sidebar.collapsed {
    width: var(--sidebar-collapsed-width);
}

.admin-sidebar.collapsed .logo span,
.admin-sidebar.collapsed .sidebar-nav span,
.admin-sidebar.collapsed .admin-details {
    display: none;
}

.admin-sidebar.collapsed .admin-info {
    justify-content: center;
}

.admin-sidebar.collapsed .footer-actions {
    flex-direction: column;
    gap: 1rem;
}

/* Responsive styles */
@media (max-width: 768px) {
    .admin-sidebar {
        transform: translateX(-100%);
    }

    .admin-sidebar.mobile-active {
        transform: translateX(0);
    }

    .sidebar-toggle {
        display: block;
    }
}

/* Scrollbar styling */
.sidebar-nav::-webkit-scrollbar {
    width: 5px;
}

.sidebar-nav::-webkit-scrollbar-track {
    background: var(--bg-darker);
}

.sidebar-nav::-webkit-scrollbar-thumb {
    background: var(--border-color);
    border-radius: 3px;
}

.sidebar-nav::-webkit-scrollbar-thumb:hover {
    background: var(--text-secondary);
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const sidebar = document.querySelector('.admin-sidebar');
    const toggle = document.querySelector('.sidebar-toggle');
    
    // Toggle sidebar on button click
    toggle.addEventListener('click', () => {
        sidebar.classList.toggle('collapsed');
        if (window.innerWidth <= 768) {
            sidebar.classList.toggle('mobile-active');
        }
    });

    // Handle window resize
    window.addEventListener('resize', () => {
        if (window.innerWidth > 768) {
            sidebar.classList.remove('mobile-active');
        }
    });

    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', (e) => {
        if (window.innerWidth <= 768 && 
            !sidebar.contains(e.target) && 
            sidebar.classList.contains('mobile-active')) {
            sidebar.classList.remove('mobile-active');
        }
    });
});
</script> 