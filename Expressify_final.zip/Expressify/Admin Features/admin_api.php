<?php
require_once '../includes/session.php';
require_once '../includes/config.php';

// Check if admin is logged in
if(!isset($_SESSION['admin_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Unauthorized access']);
    exit();
}

$response = ['success' => false, 'message' => 'Invalid request'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $userId = isset($_POST['user_id']) ? (int)$_POST['user_id'] : 0;

    if ($userId <= 0) {
        $response['message'] = 'Invalid user ID';
        echo json_encode($response);
        exit();
    }

    switch ($action) {
        case 'edit':
            if (isset($_POST['username']) && isset($_POST['email'])) {
                $username = trim($_POST['username']);
                $email = trim($_POST['email']);
                $status = $_POST['status'] ?? 'active';

                $stmt = $conn->prepare("UPDATE users SET username = ?, email = ?, status = ? WHERE id = ?");
                $stmt->bind_param("sssi", $username, $email, $status, $userId);
                
                if ($stmt->execute()) {
                    $response = ['success' => true, 'message' => 'User updated successfully'];
                } else {
                    $response = ['success' => false, 'message' => 'Failed to update user'];
                }
            }
            break;

        case 'ban':
            $stmt = $conn->prepare("UPDATE users SET status = 'banned' WHERE id = ?");
            $stmt->bind_param("i", $userId);
            
            if ($stmt->execute()) {
                $response = ['success' => true, 'message' => 'User banned successfully'];
            } else {
                $response = ['success' => false, 'message' => 'Failed to ban user'];
            }
            break;

        case 'activate':
            $stmt = $conn->prepare("UPDATE users SET status = 'active' WHERE id = ?");
            $stmt->bind_param("i", $userId);
            
            if ($stmt->execute()) {
                $response = ['success' => true, 'message' => 'User activated successfully'];
            } else {
                $response = ['success' => false, 'message' => 'Failed to activate user'];
            }
            break;

        case 'delete':
            // Start transaction
            $conn->begin_transaction();
            try {
                // First, record the deletion
                $stmt = $conn->prepare("INSERT INTO deleted_users (user_id) VALUES (?)");
                $stmt->bind_param("i", $userId);
                $stmt->execute();

                // Update user status to 'deleted' instead of actually deleting
                $stmt = $conn->prepare("UPDATE users SET status = 'deleted' WHERE id = ?");
                $stmt->bind_param("i", $userId);
                
                if ($stmt->execute()) {
                    // Delete user's posts
                    $stmt = $conn->prepare("DELETE FROM posts WHERE user_id = ?");
                    $stmt->bind_param("i", $userId);
                    $stmt->execute();

                    // Delete user's comments
                    $stmt = $conn->prepare("DELETE FROM comments WHERE user_id = ?");
                    $stmt->bind_param("i", $userId);
                    $stmt->execute();

                    // Delete user's likes
                    $stmt = $conn->prepare("DELETE FROM likes WHERE user_id = ?");
                    $stmt->bind_param("i", $userId);
                    $stmt->execute();

                    // Delete user's friends/friend requests if table exists
                    $result = $conn->query("SHOW TABLES LIKE 'friends'");
                    if ($result->num_rows > 0) {
                        $stmt = $conn->prepare("DELETE FROM friends WHERE user_id = ? OR friend_id = ?");
                        $stmt->bind_param("ii", $userId, $userId);
                        $stmt->execute();
                    }

                    // Delete user's notifications if table exists
                    $result = $conn->query("SHOW TABLES LIKE 'notifications'");
                    if ($result->num_rows > 0) {
                        $stmt = $conn->prepare("DELETE FROM notifications WHERE user_id = ?");
                        $stmt->bind_param("i", $userId);
                        $stmt->execute();
                    }

                    $conn->commit();
                    $response = ['success' => true, 'message' => 'User deleted successfully'];
                } else {
                    throw new Exception("Failed to update user status");
                }
            } catch (Exception $e) {
                $conn->rollback();
                $response = ['success' => false, 'message' => 'Failed to delete user: ' . $e->getMessage()];
            }
            break;
    }
}

header('Content-Type: application/json');
echo json_encode($response);
?> 