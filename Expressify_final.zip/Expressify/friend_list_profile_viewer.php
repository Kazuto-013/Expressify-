<?php
require 'session.php';
require 'config.php';
require 'theme.php';

$current_user_id = $_SESSION['user_id'];
$message = '';

// Check if a friend's user ID is provided
if (!isset($_GET['id'])) {
    header('Location: friends.php');
    exit;
}

$profile_user_id = $_GET['id'];

// Verify user exists
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $profile_user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header('Location: friends.php');
    exit;
}

$profile_user = $result->fetch_assoc();

// Get unread notifications count for the current user
$stmt = $conn->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0");
$stmt->bind_param("i", $current_user_id);
$stmt->execute();
$unread_count = $stmt->get_result()->fetch_assoc()['count'];

// Determine friendship status
$friendship_query = "
    SELECT status, sender_id 
    FROM friend_requests 
    WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)
";
$stmt = $conn->prepare($friendship_query);
$stmt->bind_param("iiii", $current_user_id, $profile_user_id, $profile_user_id, $current_user_id);
$stmt->execute();
$friend_result = $stmt->get_result();

$friendship_status = 'none';
if ($friend_result->num_rows > 0) {
    $friend_data = $friend_result->fetch_assoc();
    
    if ($friend_data['status'] === 'pending') {
        $friendship_status = ($friend_data['sender_id'] == $current_user_id) 
            ? 'pending_sent' 
            : 'pending_received';
    } elseif ($friend_data['status'] === 'accepted') {
        $friendship_status = 'accepted';
    }
}

// Get user's posts with media, like counts and comment counts
$stmt = $conn->prepare("
    SELECT 
        posts.*,
        users.username,
        users.profile_picture,
        media.file_path,
        media.file_type,
        COUNT(DISTINCT likes.id) as like_count,
        COUNT(DISTINCT comments.id) as comment_count,
        MAX(CASE WHEN likes.user_id = ? THEN 1 ELSE 0 END) as user_liked
    FROM posts 
    JOIN users ON posts.user_id = users.id
    LEFT JOIN media ON posts.media_id = media.id
    LEFT JOIN likes ON posts.id = likes.post_id
    LEFT JOIN comments ON posts.id = comments.post_id
    WHERE posts.user_id = ?
    GROUP BY posts.id
    ORDER BY posts.created_at DESC
");
$stmt->bind_param("ii", $current_user_id, $profile_user_id);
$stmt->execute();
$posts_result = $stmt->get_result();

// Get friend count
$friendCountQuery = "SELECT COUNT(*) as friend_count 
                    FROM friend_requests 
                    WHERE status = 'accepted' AND (sender_id = ? OR receiver_id = ?)";
$friendStmt = $conn->prepare($friendCountQuery);
$friendStmt->bind_param("ii", $profile_user_id, $profile_user_id);
$friendStmt->execute();
$friendResult = $friendStmt->get_result();
$friendCount = $friendResult->fetch_assoc()['friend_count'];

// Get mutual friends count if viewing another user's profile
$mutualFriendsCount = 0;
if ($profile_user_id !== $_SESSION['user_id']) {
    $mutualQuery = "SELECT COUNT(*) as mutual_count
                   FROM (
                       SELECT IF(sender_id = ?, receiver_id, sender_id) as friend_id
                       FROM friend_requests
                       WHERE status = 'accepted' AND (sender_id = ? OR receiver_id = ?)
                   ) AS my_friends
                   JOIN (
                       SELECT IF(sender_id = ?, receiver_id, sender_id) as friend_id
                       FROM friend_requests
                       WHERE status = 'accepted' AND (sender_id = ? OR receiver_id = ?)
                   ) AS their_friends
                   ON my_friends.friend_id = their_friends.friend_id";
    $mutualStmt = $conn->prepare($mutualQuery);
    $mutualStmt->bind_param("iiiiii", 
        $_SESSION['user_id'], $_SESSION['user_id'], $_SESSION['user_id'],
        $profile_user_id, $profile_user_id, $profile_user_id
    );
    $mutualStmt->execute();
    $mutualResult = $mutualStmt->get_result();
    $mutualFriendsCount = $mutualResult->fetch_assoc()['mutual_count'];
}

// Get posts count
$stmt = $conn->prepare("SELECT COUNT(*) as count FROM posts WHERE user_id = ?");
$stmt->bind_param("i", $profile_user_id);
$stmt->execute();
$posts_count = $stmt->get_result()->fetch_assoc()['count'];

// Get all friends of this user
$friends_list_query = "
    SELECT 
        u.id, 
        u.username, 
        u.profile_picture,
        u.bio
    FROM users u
    JOIN friend_requests fr ON 
        (fr.sender_id = ? AND fr.receiver_id = u.id) OR 
        (fr.sender_id = u.id AND fr.receiver_id = ?)
    WHERE fr.status = 'accepted'
    ORDER BY u.username
";
$stmt = $conn->prepare($friends_list_query);
$stmt->bind_param("ii", $profile_user_id, $profile_user_id);
$stmt->execute();
$friends_list = $stmt->get_result();

// Get mutual friends
$mutual_friends_query = "
    SELECT 
        u.id, 
        u.username, 
        u.profile_picture,
        u.bio
    FROM users u
    JOIN friend_requests fr1 ON 
        (fr1.sender_id = ? AND fr1.receiver_id = u.id) OR 
        (fr1.sender_id = u.id AND fr1.receiver_id = ?)
    JOIN friend_requests fr2 ON 
        (fr2.sender_id = ? AND fr2.receiver_id = u.id) OR 
        (fr2.sender_id = u.id AND fr2.receiver_id = ?)
    WHERE fr1.status = 'accepted' AND fr2.status = 'accepted'
    ORDER BY u.username
";
$stmt = $conn->prepare($mutual_friends_query);
$stmt->bind_param("iiii", $current_user_id, $current_user_id, $profile_user_id, $profile_user_id);
$stmt->execute();
$mutual_friends_list = $stmt->get_result();
?>
<!DOCTYPE html>
<html data-theme="<?php echo htmlspecialchars($current_theme); ?>">
<head>
    <title><?php echo htmlspecialchars($profile_user['username']); ?> - Expressify</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
<div class="container">
    <nav class="navbar">
        <div class="nav-brand">
            <h2>Expressify</h2>
        </div>
        <div class="nav-links">
            <a href="home.php" class="nav-item"><i class="fas fa-home"></i> Home</a>
            <a href="posts.php" class="nav-item"><i class="fas fa-pen"></i> Create Post</a>
            <a href="explore.php" class="nav-item"><i class="fas fa-compass"></i> Explore</a>
            <a href="notifications.php" class="nav-item">
                <i class="fas fa-bell"></i> Notifications
                <?php if ($unread_count > 0): ?>
                    <span class="notification-badge"><?php echo $unread_count; ?></span>
                <?php endif; ?>
            </a>
            <a href="profile.php" class="nav-item"><i class="fas fa-user"></i> My Profile</a>
            <a href="friends.php" class="nav-item active"><i class="fas fa-users"></i> Friends</a>
            <a href="settings.php" class="nav-item"><i class="fas fa-cog"></i> Settings</a>
            <a href="logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
        <div class="nav-toggle">
            <i class="fas fa-bars"></i>
        </div>
    </nav>

    <div class="content">
        <div class="profile-container">
            <?php echo $message; ?>
            
            <div class="profile-header">
                <div class="profile-left">
                    <div class="profile-picture-container">
                        <div class="profile-picture">
                            <img src="<?php echo !empty($profile_user['profile_picture']) ? htmlspecialchars($profile_user['profile_picture']) : 'assets/default-avatar.png'; ?>" 
                                 alt="Profile Picture" id="profilePreview">
                        </div>
                    </div>
                    
                    <div class="profile-stats">
                        <div class="stat-item">
                            <span class="stat-value"><?php echo $posts_count; ?></span>
                            <span class="stat-label">Posts</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-value"><?php echo $friendCount; ?></span>
                            <span class="stat-label">Friends</span>
                        </div>
                        <?php if ($profile_user_id !== $_SESSION['user_id']): ?>
                        <div class="stat-item">
                            <span class="stat-value"><?php echo $mutualFriendsCount; ?></span>
                            <span class="stat-label">Mutual Friends</span>
                        </div>
                        <?php endif; ?>
                    </div>

                    <!-- Friends Dropdown -->
                    <div class="friends-dropdown" id="friendsDropdown">
                        <div class="dropdown-header">
                            <h4><i class="fas fa-user-friends"></i> Friends</h4>
                            <button class="close-dropdown" onclick="toggleFriendsList()"><i class="fas fa-times"></i></button>
                        </div>
                        <div class="dropdown-content">
                            <?php if ($friends_list->num_rows > 0): ?>
                                <?php while ($friend = $friends_list->fetch_assoc()): ?>
                                    <div class="friend-item">
                                        <img src="<?php echo !empty($friend['profile_picture']) ? htmlspecialchars($friend['profile_picture']) : 'assets/default-avatar.png'; ?>" 
                                            alt="<?php echo htmlspecialchars($friend['username']); ?>" class="friend-avatar">
                                        <div class="friend-info">
                                            <span class="friend-username"><?php echo htmlspecialchars($friend['username']); ?></span>
                                            <?php if (!empty($friend['bio'])): ?>
                                                <span class="friend-bio"><?php echo htmlspecialchars(substr($friend['bio'], 0, 50)) . (strlen($friend['bio']) > 50 ? '...' : ''); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <a href="friend_list_profile_viewer.php?id=<?php echo $friend['id']; ?>" class="view-friend-btn">
                                            <i class="fas fa-user"></i> View
                                        </a>
                                    </div>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <p class="no-friends">No friends to show.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <!-- Mutual Friends Dropdown -->
                    <div class="friends-dropdown mutual-dropdown" id="mutualFriendsDropdown">
                        <div class="dropdown-header">
                            <h4><i class="fas fa-users"></i> Mutual Friends</h4>
                            <button class="close-dropdown" onclick="toggleMutualFriendsList()"><i class="fas fa-times"></i></button>
                        </div>
                        <div class="dropdown-content">
                            <?php if ($mutual_friends_list->num_rows > 0): ?>
                                <?php while ($friend = $mutual_friends_list->fetch_assoc()): ?>
                                    <div class="friend-item">
                                        <img src="<?php echo !empty($friend['profile_picture']) ? htmlspecialchars($friend['profile_picture']) : 'assets/default-avatar.png'; ?>" 
                                            alt="<?php echo htmlspecialchars($friend['username']); ?>" class="friend-avatar">
                                        <div class="friend-info">
                                            <span class="friend-username"><?php echo htmlspecialchars($friend['username']); ?></span>
                                            <?php if (!empty($friend['bio'])): ?>
                                                <span class="friend-bio"><?php echo htmlspecialchars(substr($friend['bio'], 0, 50)) . (strlen($friend['bio']) > 50 ? '...' : ''); ?></span>
                                            <?php endif; ?>
                                        </div>
                                        <a href="friend_list_profile_viewer.php?id=<?php echo $friend['id']; ?>" class="view-friend-btn">
                                            <i class="fas fa-user"></i> View
                                        </a>
                                    </div>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <p class="no-friends">No mutual friends to show.</p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="friendship-actions">
                        <?php if ($profile_user_id != $current_user_id): ?>
                            <?php switch($friendship_status) {
                                case 'none': ?>
                                    <button class="btn primary friend-btn" onclick="handleFriendRequest(<?php echo $profile_user_id; ?>, 'send')">
                                        <i class="fas fa-user-plus"></i> Add Friend
                                    </button>
                                    <?php break;
                                case 'pending_sent': ?>
                                    <button class="btn secondary friend-btn" onclick="handleFriendRequest(<?php echo $profile_user_id; ?>, 'cancel')">
                                        <i class="fas fa-user-clock"></i> Cancel Request
                                    </button>
                                    <?php break;
                                case 'pending_received': ?>
                                    <div class="friend-request-actions">
                                        <button class="btn primary friend-btn" onclick="handleFriendRequest(<?php echo $profile_user_id; ?>, 'accept')">
                                            <i class="fas fa-check"></i> Accept
                                        </button>
                                        <button class="btn secondary friend-btn" onclick="handleFriendRequest(<?php echo $profile_user_id; ?>, 'cancel')">
                                            <i class="fas fa-times"></i> Reject
                                        </button>
                                    </div>
                                    <?php break;
                                case 'accepted': ?>
                                    <button class="btn secondary friend-btn" onclick="handleFriendRequest(<?php echo $profile_user_id; ?>, 'unfriend')">
                                        <i class="fas fa-user-minus"></i> Unfriend
                                    </button>
                                    <?php break;
                            } ?>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="profile-right">
                    <div class="profile-details">
                        <h3><i class="fas fa-user-circle"></i> Profile Details</h3>
                        <div class="details-content">
                            <div class="detail-item">
                                <span class="detail-label"><i class="fas fa-user"></i> Username</span>
                                <span class="detail-value"><?php echo htmlspecialchars($profile_user['username']); ?></span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label"><i class="fas fa-envelope"></i> Email</span>
                                <span class="detail-value"><?php echo htmlspecialchars($profile_user['email']); ?></span>
                            </div>
                            <div class="detail-item">
                                <span class="detail-label"><i class="fas fa-info-circle"></i> Bio</span>
                                <div class="detail-value bio-text"><?php echo !empty($profile_user['bio']) ? nl2br(htmlspecialchars($profile_user['bio'])) : '<em>No bio added yet</em>'; ?></div>
                            </div>
                        </div>
                    </div>
                    <?php if ($profile_user['id'] !== $_SESSION['user_id']): ?>
                    <div class="profile-actions">
                        <button class="report-btn" onclick="reportContent('profile', <?php echo $profile_user['id']; ?>, <?php echo $profile_user['id']; ?>)">
                            <i class="fas fa-flag"></i> Report Profile
                        </button>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="user-posts">
                <h3><i class="fas fa-pencil-alt"></i> <?php echo htmlspecialchars($profile_user['username']); ?>'s Posts</h3>
                <div class="posts-grid">
                    <?php if ($posts_result->num_rows > 0): ?>
                        <?php while ($post = $posts_result->fetch_assoc()): ?>
                            <div class="post" data-post-id="<?php echo $post['id']; ?>">
                                <div class="post-header">
                                    <div class="post-user">
                                        <img src="<?php echo !empty($post['profile_picture']) ? htmlspecialchars($post['profile_picture']) : 'assets/default-avatar.png'; ?>" 
                                             alt="Profile Picture" class="post-avatar">
                                        <div class="post-info">
                                            <span class="username"><?php echo htmlspecialchars($post['username']); ?></span>
                                            <span class="post-date"><?php echo date('M d, Y', strtotime($post['created_at'])); ?></span>
                                        </div>
                                    </div>
                                </div>

                                <div class="post-content">
                                    <p><?php echo nl2br(htmlspecialchars($post['content'])); ?></p>
                                    <?php if (!empty($post['file_path'])): ?>
                                        <div class="post-media">
                                            <?php if (strpos($post['file_type'], 'image/') !== false || in_array($post['file_type'], ['jpg', 'jpeg', 'png', 'gif'])): ?>
                                                <img src="<?php echo htmlspecialchars($post['file_path']); ?>" alt="Post image" class="post-image">
                                            <?php elseif (strpos($post['file_type'], 'video/') !== false || in_array($post['file_type'], ['mp4', 'mov'])): ?>
                                                <video controls class="post-video">
                                                    <source src="<?php echo htmlspecialchars($post['file_path']); ?>" type="<?php echo htmlspecialchars($post['file_type']); ?>">
                                                    Your browser does not support the video tag.
                                                </video>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <div class="post-actions">
                                    <button class="like-btn <?php echo $post['user_liked'] ? 'liked' : ''; ?>" 
                                            data-post-id="<?php echo $post['id']; ?>"
                                            onclick="likePost(<?php echo $post['id']; ?>)">
                                        <i class="<?php echo $post['user_liked'] ? 'fas' : 'far'; ?> fa-heart"></i>
                                        <span class="like-count"><?php echo $post['like_count']; ?></span>
                                    </button>
                                    <button class="comment-btn" data-post-id="<?php echo $post['id']; ?>" onclick="toggleComments(<?php echo $post['id']; ?>)">
                                        <i class="far fa-comment"></i>
                                        <span class="comment-count"><?php echo $post['comment_count']; ?></span>
                                    </button>
                                </div>

                                <div class="comments-section" id="comments-<?php echo $post['id']; ?>" style="display: none;">
                                    <div class="comments-container" id="comments-container-<?php echo $post['id']; ?>">
                                        <!-- Comments will be loaded here -->
                                    </div>
                                    <div class="comment-form">
                                        <textarea class="comment-input" id="comment-input-<?php echo $post['id']; ?>" placeholder="Write a comment..."></textarea>
                                        <button class="comment-submit" onclick="addComment(<?php echo $post['id']; ?>)">
                                            <i class="fas fa-paper-plane"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <p class="no-posts">No posts to show.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.querySelector('.nav-toggle').addEventListener('click', function() {
    document.querySelector('.nav-links').classList.toggle('active');
});

async function handleFriendRequest(userId, action) {
    try {
        const response = await fetch('api/friend_request.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                userId: userId,
                action: action
            })
        });

        const data = await response.json();
        
        if (data.success) {
            const friendshipActions = document.querySelector('.friendship-actions');
            let newButton = '';
            
            switch(data.newStatus) {
                case 'none':
                    newButton = `
                        <button class="btn primary friend-btn" onclick="handleFriendRequest(${userId}, 'send')">
                            <i class="fas fa-user-plus"></i> Add Friend
                        </button>`;
                    break;
                case 'pending_sent':
                    newButton = `
                        <button class="btn secondary friend-btn" onclick="handleFriendRequest(${userId}, 'cancel')">
                            <i class="fas fa-user-clock"></i> Cancel Request
                        </button>`;
                    break;
                case 'accepted':
                    newButton = `
                        <button class="btn secondary friend-btn" onclick="handleFriendRequest(${userId}, 'unfriend')">
                            <i class="fas fa-user-minus"></i> Unfriend
                        </button>`;
                    break;
            }
            
            friendshipActions.innerHTML = newButton;
            
            // Show notification
            showNotification(data.message, 'success');
        } else {
            showNotification(data.message, 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        showNotification('An error occurred. Please try again.', 'error');
    }
}

function showNotification(message, type) {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
        ${message}
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.classList.add('fade-out');
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

async function toggleComments(postId) {
    const commentsSection = document.getElementById(`comments-${postId}`);
    const commentsContainer = document.getElementById(`comments-container-${postId}`);
    
    if (commentsSection.style.display === 'none') {
        commentsSection.style.display = 'block';
        
        // Fetch comments for this post
        try {
            const response = await fetch(`api/comments.php?post_id=${postId}`);
            const data = await response.json();
            
            if (data.success) {
                // Render comments
                commentsContainer.innerHTML = '';
                
                if (data.comments.length === 0) {
                    commentsContainer.innerHTML = '<p class="no-comments">No comments yet. Be the first to comment!</p>';
                } else {
                    data.comments.forEach(comment => {
                        const commentHtml = `
                            <div class="comment">
                                <img src="${comment.profile_picture || 'assets/default-avatar.png'}" alt="${comment.username}" class="comment-avatar">
                                <div class="comment-content">
                                    <div class="comment-header">
                                        <span class="comment-username">${comment.username}</span>
                                        <span class="comment-date">${formatDate(comment.created_at)}</span>
                                    </div>
                                    <p>${comment.content}</p>
                                </div>
                            </div>
                        `;
                        commentsContainer.innerHTML += commentHtml;
                    });
                }
            } else {
                commentsContainer.innerHTML = '<p class="error">Failed to load comments.</p>';
            }
        } catch (error) {
            console.error('Error:', error);
            commentsContainer.innerHTML = '<p class="error">An error occurred while loading comments.</p>';
        }
    } else {
        commentsSection.style.display = 'none';
    }
}

async function addComment(postId) {
    const commentInput = document.getElementById(`comment-input-${postId}`);
    const content = commentInput.value.trim();
    
    if (!content) return;
    
    try {
        const response = await fetch('api/comments.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                post_id: postId,
                content: content
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Clear input
            commentInput.value = '';
            
            // Update comment count
            const commentCountElement = document.querySelector(`.post[data-post-id="${postId}"] .comment-count`);
            commentCountElement.textContent = parseInt(commentCountElement.textContent) + 1;
            
            // Reload comments
            toggleComments(postId);
            toggleComments(postId);
        } else {
            showNotification(data.message, 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        showNotification('An error occurred. Please try again.', 'error');
    }
}

async function likePost(postId) {
    try {
        const response = await fetch('api/likes.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                post_id: postId
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            const likeBtn = document.querySelector(`.post[data-post-id="${postId}"] .like-btn`);
            const likeIcon = likeBtn.querySelector('i');
            const likeCount = likeBtn.querySelector('.like-count');
            
            if (data.liked) {
                likeIcon.classList.remove('far');
                likeIcon.classList.add('fas');
                likeBtn.classList.add('liked');
            } else {
                likeIcon.classList.remove('fas');
                likeIcon.classList.add('far');
                likeBtn.classList.remove('liked');
            }
            
            likeCount.textContent = data.likeCount;
        } else {
            showNotification(data.message, 'error');
        }
    } catch (error) {
        console.error('Error:', error);
        showNotification('An error occurred. Please try again.', 'error');
    }
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function toggleFriendsList() {
    const dropdown = document.getElementById('friendsDropdown');
    const mutualDropdown = document.getElementById('mutualFriendsDropdown');
    
    if (mutualDropdown.classList.contains('active')) {
        mutualDropdown.classList.remove('active');
    }
    
    dropdown.classList.toggle('active');
}

function toggleMutualFriendsList() {
    const dropdown = document.getElementById('mutualFriendsDropdown');
    const friendsDropdown = document.getElementById('friendsDropdown');
    
    if (friendsDropdown.classList.contains('active')) {
        friendsDropdown.classList.remove('active');
    }
    
    dropdown.classList.toggle('active');
}

// Close dropdowns when clicking outside
document.addEventListener('click', function(event) {
    const friendsDropdown = document.getElementById('friendsDropdown');
    const mutualDropdown = document.getElementById('mutualFriendsDropdown');
    const friendsStat = document.querySelector('.friends-stat');
    const mutualStat = document.querySelector('.mutual-stat');
    
    if (!friendsDropdown.contains(event.target) && !friendsStat.contains(event.target)) {
        friendsDropdown.classList.remove('active');
    }
    
    if (!mutualDropdown.contains(event.target) && !mutualStat.contains(event.target)) {
        mutualDropdown.classList.remove('active');
    }
});

function reportContent(contentType, contentId, reportedId) {
    const reason = prompt('Please provide a reason for reporting this profile:');
    if (!reason) return;

    fetch('includes/report_handler.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `content_type=${contentType}&content_id=${contentId}&reported_id=${reportedId}&reason=${encodeURIComponent(reason)}`
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
        if (data.success) {
            // Optionally refresh the page or update UI
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred while submitting the report.');
    });
}
</script>

<style>
/* Friend Stats Styling */
.friends-stat, .mutual-stat {
    cursor: pointer;
    position: relative;
    transition: transform 0.2s ease;
}

.friends-stat:hover, .mutual-stat:hover {
    transform: translateY(-2px);
}

/* Friends Dropdown Styling */
.friends-dropdown {
    position: absolute;
    width: 300px;
    max-height: 400px;
    background: var(--bg-primary);
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    z-index: 1000;
    left: 0;
    top: 100%;
    margin-top: 10px;
    display: none;
    overflow: hidden;
    transition: all 0.3s ease;
    border: 1px solid var(--border-color);
}

.friends-dropdown.active {
    display: block;
    animation: fadeIn 0.3s ease;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
}

.dropdown-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 15px;
    background: var(--bg-secondary);
    border-bottom: 1px solid var(--border-color);
}

.dropdown-header h4 {
    margin: 0;
    display: flex;
    align-items: center;
    gap: 8px;
    color: var(--text-primary);
    font-size: 16px;
}

.close-dropdown {
    background: none;
    border: none;
    color: var(--text-secondary);
    cursor: pointer;
    font-size: 16px;
    padding: 5px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: background 0.2s ease;
}

.close-dropdown:hover {
    background: rgba(0, 0, 0, 0.05);
    color: var(--text-primary);
}

.dropdown-content {
    max-height: 350px;
    overflow-y: auto;
    padding: 10px 0;
}

.friend-item {
    display: flex;
    align-items: center;
    padding: 10px 15px;
    transition: background 0.2s ease;
    cursor: default;
}

.friend-item:hover {
    background: var(--bg-secondary);
}

.friend-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    object-fit: cover;
    margin-right: 12px;
}

.friend-info {
    flex: 1;
    display: flex;
    flex-direction: column;
}

.friend-username {
    font-weight: 500;
    color: var(--text-primary);
}

.friend-bio {
    font-size: 12px;
    color: var(--text-secondary);
    margin-top: 2px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.view-friend-btn {
    background: var(--primary-color);
    color: white;
    border: none;
    padding: 6px 12px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 12px;
    display: flex;
    align-items: center;
    gap: 5px;
    text-decoration: none;
    transition: background 0.2s ease;
}

.view-friend-btn:hover {
    background: var(--primary-color-dark);
}

.no-friends {
    text-align: center;
    padding: 15px;
    color: var(--text-secondary);
    font-style: italic;
}

/* Scrollbar styling for dropdown content */
.dropdown-content::-webkit-scrollbar {
    width: 8px;
}

.dropdown-content::-webkit-scrollbar-track {
    background: var(--bg-primary);
}

.dropdown-content::-webkit-scrollbar-thumb {
    background: var(--border-color);
    border-radius: 4px;
}

.dropdown-content::-webkit-scrollbar-thumb:hover {
    background: var(--text-secondary);
}

/* Responsive styling */
@media (max-width: 768px) {
    .friends-dropdown {
        width: 280px;
        left: 50%;
        transform: translateX(-50%);
    }
}

@media (max-width: 480px) {
    .friends-dropdown {
        width: 90%;
        max-width: 300px;
    }
}

/* Add to existing styles */
.report-btn {
    background: none;
    border: none;
    color: var(--text-secondary);
    cursor: pointer;
    padding: 8px 16px;
    font-size: 0.9em;
    transition: all 0.3s ease;
    opacity: 0.7;
    border-radius: 20px;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.report-btn:hover {
    color: var(--danger-color);
    background: rgba(var(--danger-color-rgb), 0.1);
    opacity: 1;
}

.profile-actions {
    display: flex;
    gap: 1rem;
    margin-top: 1rem;
}
</style>
</body>
</html>
