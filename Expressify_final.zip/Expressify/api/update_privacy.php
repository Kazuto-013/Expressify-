<?php
require '../session.php';
require '../config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit;
}

$user_id = $_SESSION['user_id'];

// Get privacy settings from form
$is_private = isset($_POST['is_private']) ? 1 : 0;
$show_activity = isset($_POST['show_activity']) ? 1 : 0;

// Check if user settings exist
$stmt = $conn->prepare("SELECT id FROM settings WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Update existing settings
    $stmt = $conn->prepare("UPDATE settings SET is_private = ?, show_activity = ? WHERE user_id = ?");
    $stmt->bind_param("iii", $is_private, $show_activity, $user_id);
} else {
    // Insert new settings
    $stmt = $conn->prepare("INSERT INTO settings (user_id, is_private, show_activity) VALUES (?, ?, ?)");
    $stmt->bind_param("iii", $user_id, $is_private, $show_activity);
}

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Privacy settings updated successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to update privacy settings']);
}

// Check if password change was requested
if (!empty($_POST['current_password']) && !empty($_POST['new_password']) && !empty($_POST['confirm_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Verify passwords match
    if ($new_password !== $confirm_password) {
        echo json_encode(['success' => false, 'message' => 'New passwords do not match']);
        exit;
    }
    
    // Verify current password
    $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    
    if (!password_verify($current_password, $user['password'])) {
        echo json_encode(['success' => false, 'message' => 'Current password is incorrect']);
        exit;
    }
    
    // Update password
    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
    $stmt->bind_param("si", $hashed_password, $user_id);
    
    if ($stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Password updated successfully']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to update password']);
    }
}

$stmt->close();
$conn->close();
?> 