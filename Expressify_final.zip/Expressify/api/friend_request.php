<?php
require '../session.php';
require '../config.php';
require '../functions.php';

header('Content-Type: application/json');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Please log in to manage friend requests']);
    exit;
}

// Get the POST data
$data = json_decode(file_get_contents('php://input'), true);
$targetUserId = $data['userId'] ?? null;
$action = $data['action'] ?? null;
$currentUserId = $_SESSION['user_id'];

// Validate input
if (!$targetUserId || !$action) {
    echo json_encode(['success' => false, 'message' => 'Invalid request parameters']);
    exit;
}

// Validate that target user exists
try {
    $conn->begin_transaction();

    // Get usernames for notification messages
    $stmt = $conn->prepare("SELECT username FROM users WHERE id = ?");
    $stmt->bind_param("i", $currentUserId);
    $stmt->execute();
    $sender = $stmt->get_result()->fetch_assoc();

    $stmt->bind_param("i", $targetUserId);
    $stmt->execute();
    $receiver = $stmt->get_result()->fetch_assoc();

    switch ($action) {
        case 'send':
            // Check if users are already friends or have pending requests
            $stmt = $conn->prepare("
                SELECT 
                    id,
                    sender_id,
                    receiver_id,
                    status
                FROM friend_requests 
                WHERE (sender_id = ? AND receiver_id = ?) 
                   OR (sender_id = ? AND receiver_id = ?)
            ");
            $stmt->bind_param("iiii", $currentUserId, $targetUserId, $targetUserId, $currentUserId);
            $stmt->execute();
            $existingRequest = $stmt->get_result()->fetch_assoc();
            
            if ($existingRequest) {
                if ($existingRequest['status'] === 'accepted') {
                    $conn->rollback();
                    echo json_encode(['success' => false, 'message' => 'You are already friends with this user']);
                    exit;
                }
                if ($existingRequest['status'] === 'pending') {
                    if ($existingRequest['sender_id'] == $currentUserId) {
                        $conn->rollback();
                        echo json_encode(['success' => false, 'message' => 'You have already sent a friend request to this user']);
                    } else {
                        $conn->rollback();
                        echo json_encode(['success' => false, 'message' => 'This user has already sent you a friend request']);
                    }
                    exit;
                }
            }
            
            // Send new request
            $stmt = $conn->prepare("INSERT INTO friend_requests (sender_id, receiver_id, status) VALUES (?, ?, 'pending')");
            $stmt->bind_param("ii", $currentUserId, $targetUserId);
            if ($stmt->execute()) {
                // Create notification for friend request
                createNotification(
                    $conn,
                    $targetUserId,
                    'friend_request',
                    "{$sender['username']} sent you a friend request",
                    $currentUserId,
                    null
                );
                $response = [
                    'success' => true, 
                    'newStatus' => 'pending_sent',
                    'message' => 'Friend request sent successfully'
                ];
            }
            break;
            
        case 'accept':
            // Verify the request exists and is pending
            $stmt = $conn->prepare("
                SELECT id 
                FROM friend_requests 
                WHERE sender_id = ? 
                AND receiver_id = ? 
                AND status = 'pending'
            ");
            $stmt->bind_param("ii", $targetUserId, $currentUserId);
            $stmt->execute();
            
            if (!$stmt->get_result()->fetch_assoc()) {
                $conn->rollback();
                echo json_encode(['success' => false, 'message' => 'No pending friend request found']);
                exit;
            }
            
            // Accept the request
            $stmt = $conn->prepare("UPDATE friend_requests SET status = 'accepted' WHERE sender_id = ? AND receiver_id = ?");
            $stmt->bind_param("ii", $targetUserId, $currentUserId);
            if ($stmt->execute()) {
                // Create notification for accepted request
                createNotification(
                    $conn,
                    $targetUserId,
                    'friend_request_accepted',
                    "{$sender['username']} accepted your friend request",
                    $currentUserId,
                    null
                );
                $response = [
                    'success' => true,
                    'newStatus' => 'friends',
                    'message' => 'Friend request accepted'
                ];
            }
            break;
            
        case 'reject':
        case 'cancel':
            // Handle both rejecting received requests and canceling sent requests
            $stmt = $conn->prepare("DELETE FROM friend_requests WHERE 
                (sender_id = ? AND receiver_id = ?) OR 
                (sender_id = ? AND receiver_id = ?)");
            $stmt->bind_param("iiii", $currentUserId, $targetUserId, $targetUserId, $currentUserId);
            if ($stmt->execute()) {
                // Create notification for rejected request if it was pending
                if ($action === 'reject') {
                    createNotification(
                        $conn,
                        $targetUserId,
                        'friend_request_rejected',
                        "{$sender['username']} rejected your friend request",
                        $currentUserId,
                        null
                    );
                }
                $response = [
                    'success' => true,
                    'newStatus' => 'none',
                    'message' => $action === 'reject' ? 'Friend request rejected' : 'Friend request cancelled'
                ];
            }
            break;
            
        case 'unfriend':
            // Remove friendship
            $stmt = $conn->prepare("DELETE FROM friend_requests WHERE 
                (sender_id = ? AND receiver_id = ?) OR 
                (sender_id = ? AND receiver_id = ?)");
            $stmt->bind_param("iiii", $currentUserId, $targetUserId, $targetUserId, $currentUserId);
            if ($stmt->execute()) {
                $response = [
                    'success' => true,
                    'newStatus' => 'none',
                    'message' => 'Friend removed successfully'
                ];
            }
            break;
            
        default:
            throw new Exception('Invalid action');
    }

    $conn->commit();
    echo json_encode($response);

} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

$conn->close(); 