<?php
require '../session.php';
require '../config.php';
require '../functions.php';

header('Content-Type: application/json');

// Get the action and post ID from the request
$action = isset($_GET['action']) ? $_GET['action'] : '';
$post_id = isset($_GET['post_id']) ? (int)$_GET['post_id'] : 0;

if (!$post_id) {
    echo json_encode(['success' => false, 'message' => 'Post ID is required']);
    exit;
}

$user_id = $_SESSION['user_id'] ?? 0;

if (!$user_id) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit;
}

try {
    switch ($action) {
        case 'add':
            $comment = isset($_POST['comment']) ? trim($_POST['comment']) : '';
            
            if (empty($comment)) {
                echo json_encode(['success' => false, 'message' => 'Comment cannot be empty']);
                exit;
            }
            
            // Add comment
            $stmt = $conn->prepare("INSERT INTO comments (user_id, post_id, content) VALUES (?, ?, ?)");
            $stmt->bind_param("iis", $user_id, $post_id, $comment);
            
            if ($stmt->execute()) {
                // Get comment details for response
                $comment_id = $stmt->insert_id;
                $stmt = $conn->prepare("
                    SELECT 
                        c.*,
                        u.username,
                        u.profile_picture 
                    FROM comments c 
                    JOIN users u ON c.user_id = u.id 
                    WHERE c.id = ?
                ");
                $stmt->bind_param("i", $comment_id);
                $stmt->execute();
                $comment_data = $stmt->get_result()->fetch_assoc();
                
                // Use simple date format instead of timeAgo
                $created_at = new DateTime($comment_data['created_at']);
                $comment_data['created_at'] = $created_at->format('M d, Y H:i');
                
                // Add can_delete flag
                $comment_data['can_delete'] = true;
                $comment_data['profile_pic'] = $comment_data['profile_picture'];
                
                // Add comment property to be compatible with the frontend
                $comment_data['comment'] = $comment_data['content'];
                
                echo json_encode(['success' => true, 'comment' => $comment_data]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to add comment']);
            }
            break;
            
        case 'delete':
            $comment_id = isset($_GET['comment_id']) ? (int)$_GET['comment_id'] : 0;
            
            if (!$comment_id) {
                echo json_encode(['success' => false, 'message' => 'Comment ID is required']);
                exit;
            }
            
            // Verify comment ownership
            $stmt = $conn->prepare("SELECT user_id FROM comments WHERE id = ?");
            $stmt->bind_param("i", $comment_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 0) {
                echo json_encode(['success' => false, 'message' => 'Comment not found']);
                exit;
            }
            
            $comment = $result->fetch_assoc();
            if ($comment['user_id'] != $user_id) {
                echo json_encode(['success' => false, 'message' => 'You can only delete your own comments']);
                exit;
            }
            
            // Delete comment
            $stmt = $conn->prepare("DELETE FROM comments WHERE id = ?");
            $stmt->bind_param("i", $comment_id);
            
            if ($stmt->execute()) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to delete comment']);
            }
            break;
            
        case 'get':
            $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
            $limit = 10;
            $offset = ($page - 1) * $limit;
            
            // Get comments with user details
            $stmt = $conn->prepare("
                SELECT c.*, u.username, u.profile_pic 
                FROM comments c 
                JOIN users u ON c.user_id = u.id 
                WHERE c.post_id = ? 
                ORDER BY c.created_at DESC 
                LIMIT ? OFFSET ?
            ");
            $stmt->bind_param("iii", $post_id, $limit, $offset);
            $stmt->execute();
            $comments = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            
            // Format timestamps
            foreach ($comments as &$comment) {
                $comment['created_at'] = timeAgo($comment['created_at']);
            }
            
            // Get total count for pagination
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM comments WHERE post_id = ?");
            $stmt->bind_param("i", $post_id);
            $stmt->execute();
            $total = $stmt->get_result()->fetch_assoc()['count'];
            
            echo json_encode([
                'success' => true,
                'comments' => $comments,
                'total' => $total,
                'pages' => ceil($total / $limit)
            ]);
            break;
        
        default:
            echo json_encode(['success' => false, 'message' => 'Invalid action']);
            break;
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'An error occurred: ' . $e->getMessage()]);
}
?> 