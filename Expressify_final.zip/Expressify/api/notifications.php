<?php
// Add debug information and error logging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../session.php';
require_once '../config.php';
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        // Check if notifications table exists
        $check_table = $conn->query("SHOW TABLES LIKE 'notifications'");
        if ($check_table->num_rows === 0) {
            // Table doesn't exist, return empty notifications
            echo json_encode(['notifications' => [], 'message' => 'Notifications table not found']);
            exit;
        }
        
        // Fetch notifications
        $query = "SELECT n.*, u.username, u.profile_picture,
                       p.content as post_content,
                       COALESCE(n.content, n.message) as display_content
                FROM notifications n 
                LEFT JOIN users u ON n.sender_id = u.id 
                LEFT JOIN posts p ON n.post_id = p.id
                WHERE n.user_id = ? 
                ORDER BY n.created_at DESC 
                LIMIT 10";
        
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $notifications = [];
        while ($row = $result->fetch_assoc()) {
            // Format content - use display_content which combines content and message fields
            $content = $row['display_content'] ?? 'You have a new notification';
            $username = $row['username'] ?? 'Someone';
            
            $notifications[] = [
                'id' => $row['id'],
                'type' => $row['type'] ?? 'general',
                'content' => $content,
                'username' => $username,
                'post_content' => isset($row['post_content']) ? substr($row['post_content'], 0, 50) . (strlen($row['post_content']) > 50 ? '...' : '') : '',
                'is_read' => (bool)($row['is_read'] ?? false),
                'created_at' => $row['created_at'] ?? date('Y-m-d H:i:s'),
                'profile_picture' => $row['profile_picture'] ?? 'assets/default-avatar.png'
            ];
        }
        
        echo json_encode(['notifications' => $notifications, 'success' => true]);
    } catch (Exception $e) {
        // Log the error
        error_log('Notification Error: ' . $e->getMessage());
        http_response_code(500);
        echo json_encode([
            'notifications' => [],
            'error' => 'Failed to load notifications',
            'debug' => $e->getMessage(),
            'success' => false
        ]);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // For application/x-www-form-urlencoded
        if (isset($_POST['action'])) {
            $action = $_POST['action'];
        } else {
            // For JSON requests
            $input = json_decode(file_get_contents('php://input'), true);
            $action = $input['action'] ?? '';
            if (!empty($input)) {
                $_POST = $input;
            }
        }
        
        if ($action === 'mark_read') {
            // Mark notification as read
            $notification_id = $_POST['notification_id'] ?? null;
            
            if ($notification_id) {
                $query = "UPDATE notifications SET is_read = TRUE WHERE id = ? AND user_id = ?";
                $stmt = $conn->prepare($query);
                $stmt->bind_param("ii", $notification_id, $user_id);
                
                if ($stmt->execute()) {
                    echo json_encode(['success' => true]);
                } else {
                    throw new Exception("Failed to update notification: " . $conn->error);
                }
            } else {
                http_response_code(400);
                echo json_encode(['error' => 'Notification ID required', 'success' => false]);
            }
        } elseif ($action === 'mark_all_read') {
            // Mark all notifications as read
            $query = "UPDATE notifications SET is_read = TRUE WHERE user_id = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("i", $user_id);
            
            if ($stmt->execute()) {
                echo json_encode(['success' => true]);
            } else {
                throw new Exception("Failed to update notifications: " . $conn->error);
            }
        } else {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid action', 'action_received' => $action, 'success' => false]);
        }
    } catch (Exception $e) {
        error_log('Notification Error: ' . $e->getMessage());
        http_response_code(500);
        echo json_encode(['error' => $e->getMessage(), 'success' => false]);
    }
} else {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed', 'success' => false]);
} 