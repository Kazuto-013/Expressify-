<?php
require '../session.php';
require '../config.php';
require '../functions.php';

header('Content-Type: application/json');

// Get the action from the request
$action = isset($_GET['action']) ? $_GET['action'] : '';

switch ($action) {
    case 'time_ago':
        if (isset($_GET['timestamp'])) {
            $timestamp = strtotime($_GET['timestamp']);
            echo json_encode(['success' => true, 'formatted' => timeAgo($timestamp)]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Timestamp is required']);
        }
        break;
        
    case 'date_format':
        if (isset($_GET['date'])) {
            $date = new DateTime($_GET['date']);
            $formatted = $date->format('M d, Y');
            echo json_encode(['success' => true, 'formatted' => $formatted]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Date is required']);
        }
        break;
        
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
        break;
}

// Helper function to format time ago
function timeAgo($timestamp) {
    $seconds = time() - $timestamp;
    
    if ($seconds < 60) {
        return 'just now';
    }
    
    $minutes = floor($seconds / 60);
    if ($minutes < 60) {
        return $minutes . ' minutes ago';
    }
    
    $hours = floor($minutes / 60);
    if ($hours < 24) {
        return $hours . ' hours ago';
    }
    
    $days = floor($hours / 24);
    if ($days < 7) {
        return $days . ' days ago';
    }
    
    $weeks = floor($days / 7);
    if ($weeks < 4) {
        return $weeks . ' weeks ago';
    }
    
    $months = floor($days / 30);
    if ($months < 12) {
        return $months . ' months ago';
    }
    
    $years = floor($months / 12);
    return $years . ' years ago';
}
?> 