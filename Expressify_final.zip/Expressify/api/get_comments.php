<?php
require '../session.php';
require '../config.php';
require '../functions.php';

header('Content-Type: application/json');

$post_id = isset($_GET['post_id']) ? (int)$_GET['post_id'] : 0;

if (!$post_id) {
    echo json_encode(['success' => false, 'message' => 'Post ID is required']);
    exit;
}

try {
    // Get comments with user details
    $query = "
        SELECT 
            c.*,
            u.username,
            u.profile_picture,
            (c.user_id = ?) as can_delete
        FROM comments c
        JOIN users u ON c.user_id = u.id
        WHERE c.post_id = ?
        ORDER BY c.created_at DESC
    ";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $_SESSION['user_id'], $post_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $comments = [];
    while ($comment = $result->fetch_assoc()) {
        // Use simple date format instead of timeAgo
        $created_at = new DateTime($comment['created_at']);
        $comment['created_at'] = $created_at->format('M d, Y H:i');
        
        // Add comment property to match what frontend expects
        $comment['comment'] = $comment['content'];
        
        $comments[] = $comment;
    }

    echo json_encode([
        'success' => true,
        'comments' => $comments
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'An error occurred while fetching comments: ' . $e->getMessage()
    ]);
}
?> 