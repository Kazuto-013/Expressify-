<?php
require '../session.php';
require '../config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit;
}

$user_id = $_SESSION['user_id'];
$theme = $_POST['theme'] ?? 'light';

// Validate theme
if (!in_array($theme, ['light', 'dark'])) {
    echo json_encode(['success' => false, 'message' => 'Invalid theme value']);
    exit;
}

// Update theme in settings table
$stmt = $conn->prepare("SELECT id FROM settings WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // Settings record exists, update it
    $stmt = $conn->prepare("UPDATE settings SET theme = ? WHERE user_id = ?");
    $stmt->bind_param("si", $theme, $user_id);
} else {
    // No settings record, create one
    $stmt = $conn->prepare("INSERT INTO settings (user_id, theme) VALUES (?, ?)");
    $stmt->bind_param("is", $user_id, $theme);
}

if ($stmt->execute()) {
    // Update session
    $_SESSION['theme'] = $theme;
    echo json_encode(['success' => true, 'message' => 'Theme updated successfully', 'theme' => $theme]);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to update theme']);
}

$stmt->close();
$conn->close();
?> 