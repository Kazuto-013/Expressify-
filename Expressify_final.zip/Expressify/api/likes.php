<?php
require '../session.php';
require '../config.php';
require '../functions.php';

header('Content-Type: application/json');

// Get the action and post ID from the request
$action = isset($_GET['action']) ? $_GET['action'] : '';
$post_id = isset($_GET['post_id']) ? (int)$_GET['post_id'] : 0;

if (!$post_id) {
    echo json_encode(['success' => false, 'message' => 'Post ID is required']);
    exit;
}

$user_id = $_SESSION['user_id'];

switch ($action) {
    case 'like':
        // Check if user already liked the post
        $stmt = $conn->prepare("SELECT id FROM likes WHERE user_id = ? AND post_id = ?");
        $stmt->bind_param("ii", $user_id, $post_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            echo json_encode(['success' => false, 'message' => 'You already liked this post']);
            exit;
        }
        
        // Add like
        $stmt = $conn->prepare("INSERT INTO likes (user_id, post_id) VALUES (?, ?)");
        $stmt->bind_param("ii", $user_id, $post_id);
        
        if ($stmt->execute()) {
            // Get updated like count
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM likes WHERE post_id = ?");
            $stmt->bind_param("i", $post_id);
            $stmt->execute();
            $count = $stmt->get_result()->fetch_assoc()['count'];
            
            echo json_encode(['success' => true, 'count' => $count]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to like post']);
        }
        break;
        
    case 'unlike':
        // Remove like
        $stmt = $conn->prepare("DELETE FROM likes WHERE user_id = ? AND post_id = ?");
        $stmt->bind_param("ii", $user_id, $post_id);
        
        if ($stmt->execute()) {
            // Get updated like count
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM likes WHERE post_id = ?");
            $stmt->bind_param("i", $post_id);
            $stmt->execute();
            $count = $stmt->get_result()->fetch_assoc()['count'];
            
            echo json_encode(['success' => true, 'count' => $count]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to unlike post']);
        }
        break;
        
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
        break;
}
?> 