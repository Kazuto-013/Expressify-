<?php
require_once 'includes/session.php';
require_once 'includes/config.php';

// Get unread notifications count
$unread_count = 0;
$stmt = $conn->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$result = $stmt->get_result();
if ($row = $result->fetch_assoc()) {
    $unread_count = $row['count'];
}

// Get user's current settings
$userId = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// Get user's reports
$stmt = $conn->prepare("SELECT r.*, 
                              u.username as reported_username,
                              CASE 
                                WHEN r.content_type = 'post' THEN (SELECT content FROM posts WHERE id = r.content_id)
                                WHEN r.content_type = 'comment' THEN (SELECT content FROM comments WHERE id = r.content_id)
                                ELSE NULL 
                              END as content_preview
                       FROM reports r
                       JOIN users u ON r.reported_id = u.id
                       WHERE r.reporter_id = ?
                       ORDER BY r.created_at DESC");
$stmt->bind_param("i", $userId);
$stmt->execute();
$reports = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Handle settings updates
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'update_account':
                // Handle account settings update
                $username = trim($_POST['username']);
                $email = trim($_POST['email']);
                $bio = trim($_POST['bio']);
                
                $stmt = $conn->prepare("UPDATE users SET username = ?, email = ?, bio = ? WHERE id = ?");
                $stmt->bind_param("sssi", $username, $email, $bio, $userId);
                $stmt->execute();
                break;

            case 'change_password':
                $current_password = $_POST['current_password'];
                $new_password = $_POST['new_password'];
                $confirm_password = $_POST['confirm_password'];
                
                // Verify that new passwords match
                if ($new_password !== $confirm_password) {
                    $message = '<div class="alert error">New passwords do not match.</div>';
                    break;
                }
                
                // Get user's current password hash
                $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
                $stmt->bind_param("i", $userId);
                $stmt->execute();
                $result = $stmt->get_result();
                $user_data = $result->fetch_assoc();
                
                // Verify current password
                if (!password_verify($current_password, $user_data['password'])) {
                    $message = '<div class="alert error">Current password is incorrect.</div>';
                    break;
                }
                
                // Hash new password
                $new_password_hash = password_hash($new_password, PASSWORD_DEFAULT);
                
                // Update password
                $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                $stmt->bind_param("si", $new_password_hash, $userId);
                
                if ($stmt->execute()) {
                    $message = '<div class="alert success">Password updated successfully!</div>';
                } else {
                    $message = '<div class="alert error">Failed to update password.</div>';
                }
                break;

            case 'update_privacy':
                // Handle privacy settings update
                $private_account = isset($_POST['private_account']) ? 1 : 0;
                $show_activity = isset($_POST['show_activity']) ? 1 : 0;
                
                $stmt = $conn->prepare("UPDATE users SET private_account = ?, show_activity = ? WHERE id = ?");
                $stmt->bind_param("iii", $private_account, $show_activity, $userId);
                $stmt->execute();
                break;

            case 'update_appearance':
                // Handle appearance settings update using users table
    $theme = $_POST['theme'];
                
                $stmt = $conn->prepare("UPDATE users SET theme = ? WHERE id = ?");
                $stmt->bind_param("si", $theme, $userId);
                
    if ($stmt->execute()) {
                    $_SESSION['theme'] = $theme; // Update session theme
                    $message = '<div class="alert success">Theme updated successfully!</div>';
                } else {
                    $message = '<div class="alert error">Failed to update theme.</div>';
                }
                break;
        }
        
        // Redirect to prevent form resubmission
        header("Location: settings.php?section=" . $_POST['action'] . (isset($message) ? "&message=" . urlencode($message) : ""));
        exit();
    }
}

// Get current section
$section = isset($_GET['section']) ? $_GET['section'] : 'account';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - Expressify</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .settings-container {
            display: flex;
            gap: 30px;
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background: var(--bg-primary);
            border-radius: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .settings-sidebar {
            flex: 0 0 280px;
            background: var(--card-bg);
            border-radius: 12px;
            padding: 25px;
            height: fit-content;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        }

        .settings-content {
            flex: 1;
            background: var(--card-bg);
            border-radius: 12px;
            padding: 30px;
            min-height: 600px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
        }

        .settings-nav {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .settings-nav li {
            margin-bottom: 15px;
        }

        .settings-nav a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 14px 18px;
            color: var(--text-primary);
            text-decoration: none;
            border-radius: 10px;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .settings-nav a:hover {
            background: var(--bg-hover);
            transform: translateX(5px);
        }

        .settings-nav a.active {
            background: var(--accent-color);
            color: white;
            transform: translateX(5px);
        }

        .settings-nav i {
            font-size: 1.2em;
            width: 24px;
            text-align: center;
        }

        .settings-section {
            display: none;
            animation: fadeIn 0.4s ease-out;
        }

        .settings-section.active {
            display: block;
        }

        .settings-section h2 {
            color: var(--text-primary);
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--border-color);
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 1.8em;
        }

        .settings-section h2 i {
            color: var(--accent-color);
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            margin-bottom: 10px;
            color: var(--text-primary);
            font-weight: 500;
            font-size: 1.1em;
        }

        .form-group input[type="text"],
        .form-group input[type="email"],
        .form-group input[type="password"],
        .form-group textarea,
        .form-group select {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            background: var(--input-bg);
            color: var(--text-primary);
            font-size: 1em;
            transition: all 0.3s ease;
        }

        .form-group input:focus,
        .form-group textarea:focus,
        .form-group select:focus {
            border-color: var(--accent-color);
            box-shadow: 0 0 0 3px rgba(var(--accent-color-rgb), 0.2);
            outline: none;
        }

        .form-group textarea {
            min-height: 120px;
            resize: vertical;
        }

        .btn-submit {
            background: var(--accent-color);
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1.1em;
            font-weight: 500;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .btn-submit:hover {
            background: var(--accent-color-hover);
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .btn-submit:active {
            transform: translateY(0);
        }

        .switch-container {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 20px;
            padding: 15px;
            background: var(--bg-secondary);
            border-radius: 10px;
            transition: all 0.3s ease;
        }

        .switch-container:hover {
            background: var(--bg-hover);
        }

        .switch {
            position: relative;
            display: inline-block;
            width: 60px;
            height: 30px;
        }

        .switch input {
            opacity: 0;
            width: 0;
            height: 0;
        }

        .slider {
            position: absolute;
            cursor: pointer;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: var(--border-color);
            transition: .4s;
            border-radius: 30px;
        }

        .slider:before {
            position: absolute;
            content: "";
            height: 22px;
            width: 22px;
            left: 4px;
            bottom: 4px;
            background-color: white;
            transition: .4s;
            border-radius: 50%;
        }

        input:checked + .slider {
            background-color: var(--accent-color);
        }

        input:checked + .slider:before {
            transform: translateX(30px);
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @media (max-width: 768px) {
            .settings-container {
                flex-direction: column;
            }

            .settings-sidebar {
                flex: none;
                width: 100%;
            }

            .settings-content {
                padding: 20px;
            }
        }

        /* Enhanced Navbar Styling */
        .navbar {
            background: var(--card-bg);
            padding: 1rem 2rem;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 1000;
            margin-bottom: 2rem;
        }

        .nav-brand {
            display: flex;
            align-items: center;
            gap: 1rem;
            font-size: 1.5rem;
            font-weight: 600;
            color: var(--text-primary);
        }

        .nav-brand img.logo {
            width: 40px;
            height: 40px;
            border-radius: 8px;
        }

        .nav-menu {
            display: flex;
            align-items: center;
            gap: 1.5rem;
        }

        .nav-link {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: var(--text-secondary);
            text-decoration: none;
            padding: 0.5rem 1rem;
            border-radius: 8px;
            transition: all 0.3s ease;
            font-weight: 500;
        }

        .nav-link:hover {
            color: var(--accent-color);
            background: var(--bg-hover);
            transform: translateY(-2px);
        }

        .nav-link.active {
            color: var(--accent-color);
            background: var(--bg-hover);
        }

        .nav-link i {
            font-size: 1.2rem;
        }

        /* Enhanced Button Styling */
        .btn-save-appearance {
            background: linear-gradient(45deg, var(--accent-color), var(--accent-color-hover));
            color: white;
            border: none;
            padding: 1rem 2rem;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .btn-save-appearance:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
            background: linear-gradient(45deg, var(--accent-color-hover), var(--accent-color));
        }

        .btn-save-appearance:active {
            transform: translateY(0);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        }

        .btn-save-appearance i {
            font-size: 1.2rem;
        }

        /* Enhanced Reports Section */
        .reports-list {
            display: grid;
            gap: 1.5rem;
            margin-top: 1.5rem;
        }

        .report-card {
            background: var(--bg-secondary);
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            border: 1px solid var(--border-color);
        }

        .report-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .report-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
            padding-bottom: 1rem;
            border-bottom: 1px solid var(--border-color);
        }

        .report-content {
            background: var(--bg-primary);
            padding: 1rem;
            border-radius: 8px;
            margin: 1rem 0;
            font-style: italic;
            color: var(--text-secondary);
        }

        .report-status {
            padding: 0.5rem 1rem;
            border-radius: 20px;
            font-size: 0.875rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .status-pending {
            background: var(--warning-color);
            color: var(--bg-primary);
        }

        .status-reviewed {
            background: var(--info-color);
            color: white;
        }

        .status-resolved {
            background: var(--success-color);
            color: white;
        }

        .status-dismissed {
            background: var(--danger-color);
            color: white;
        }

        .report-reason {
            margin: 1rem 0;
            padding: 1rem;
            background: var(--bg-hover);
            border-radius: 8px;
            font-weight: 500;
        }

        .admin-response {
            margin-top: 1rem;
            padding: 1rem;
            background: var(--accent-color-light);
            border-radius: 8px;
            border-left: 4px solid var(--accent-color);
        }

        .report-date {
            color: var(--text-secondary);
            font-size: 0.875rem;
            margin-top: 1rem;
        }

        /* Alert Messages */
        .alert {
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            animation: slideIn 0.3s ease-out;
        }

        .alert.success {
            background: var(--success-color-light);
            color: var(--success-color);
            border: 1px solid var(--success-color);
        }

        .alert.error {
            background: var(--danger-color-light);
            color: var(--danger-color);
            border: 1px solid var(--danger-color);
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .navbar {
                padding: 1rem;
            }

            .nav-menu {
                display: none;
                position: fixed;
                top: 70px;
                left: 0;
                right: 0;
                background: var(--card-bg);
                padding: 1rem;
                flex-direction: column;
                gap: 0.5rem;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            }

            .nav-menu.active {
                display: flex;
            }

            .nav-toggle {
                display: block;
            }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="nav-brand">
                <img src="assets/logo.png" alt="Expressify Logo" class="logo">
                <span>Expressify</span>
        </div>
        <div class="nav-menu">
            <a href="home.php" class="nav-link"><i class="fas fa-home"></i> Home</a>
            <a href="explore.php" class="nav-link"><i class="fas fa-compass"></i> Explore</a>
            <a href="posts.php" class="nav-link"><i class="fas fa-plus-circle"></i> Create</a>
            <a href="notifications.php" class="nav-link">
                <i class="fas fa-bell"></i> Notifications
                <?php if ($unread_count > 0): ?>
                    <span class="notification-badge"><?php echo $unread_count; ?></span>
                <?php endif; ?>
            </a>
            <a href="profile.php" class="nav-link"><i class="fas fa-user"></i> Profile</a>
            <a href="settings.php" class="nav-link active"><i class="fas fa-cog"></i> Settings</a>
            <a href="logout.php" class="nav-link"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
        <div class="nav-toggle">
            <i class="fas fa-bars"></i>
        </div>
    </nav>

        <div class="settings-container">
        <div class="settings-sidebar">
            <ul class="settings-nav">
                <li>
                    <a href="?section=account" class="<?php echo $section === 'account' ? 'active' : ''; ?>">
                        <i class="fas fa-user"></i> Account Settings
                    </a>
                </li>
                <li>
                    <a href="?section=privacy" class="<?php echo $section === 'privacy' ? 'active' : ''; ?>">
                        <i class="fas fa-lock"></i> Privacy
                    </a>
                </li>
                <li>
                    <a href="?section=appearance" class="<?php echo $section === 'appearance' ? 'active' : ''; ?>">
                        <i class="fas fa-paint-brush"></i> Appearance
                    </a>
                </li>
                <li>
                    <a href="?section=reports" class="<?php echo $section === 'reports' ? 'active' : ''; ?>">
                        <i class="fas fa-flag"></i> Reports
                    </a>
                </li>
            </ul>
        </div>

        <div class="settings-content">
            <!-- Account Settings Section -->
            <div class="settings-section <?php echo $section === 'account' ? 'active' : ''; ?>" id="account">
                <h2><i class="fas fa-user"></i> Account Settings</h2>
                <form method="POST" action="">
                    <input type="hidden" name="action" value="update_account">
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                    </div>
                    <div class="form-group">
                        <label for="bio">Bio</label>
                        <textarea id="bio" name="bio"><?php echo htmlspecialchars($user['bio'] ?? ''); ?></textarea>
                    </div>
                    <button type="submit" class="btn-submit">Save Changes</button>
                </form>

                <div class="password-change-section">
                    <h3><i class="fas fa-key"></i> Change Password</h3>
                    <form id="passwordForm" method="POST" action="settings.php">
                        <input type="hidden" name="action" value="change_password">
                        
                        <div class="form-group">
                            <label for="current_password">Current Password</label>
                            <input type="password" id="current_password" name="current_password" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="new_password">New Password</label>
                            <input type="password" id="new_password" name="new_password" required 
                                   pattern=".{8,}" title="Password must be at least 8 characters long">
                        </div>
                        
                        <div class="form-group">
                            <label for="confirm_password">Confirm New Password</label>
                            <input type="password" id="confirm_password" name="confirm_password" required>
                        </div>
                        
                        <button type="submit" class="btn btn-primary btn-submit">Change Password</button>
                    </form>
                </div>
            </div>

            <!-- Privacy Section -->
            <div class="settings-section <?php echo $section === 'privacy' ? 'active' : ''; ?>" id="privacy">
                <h2><i class="fas fa-lock"></i> Privacy Settings</h2>
                <form method="POST" action="">
                    <input type="hidden" name="action" value="update_privacy">
                    <div class="switch-container">
                        <label class="switch">
                            <input type="checkbox" name="private_account" <?php echo ($user['private_account'] ?? 0) ? 'checked' : ''; ?>>
                            <span class="slider"></span>
                        </label>
                        <span>Private Account</span>
                    </div>
                    <div class="switch-container">
                        <label class="switch">
                            <input type="checkbox" name="show_activity" <?php echo ($user['show_activity'] ?? 1) ? 'checked' : ''; ?>>
                            <span class="slider"></span>
                        </label>
                        <span>Show Activity Status</span>
                    </div>
                    <button type="submit" class="btn-submit">Save Privacy Settings</button>
                </form>
            </div>

            <!-- Appearance Section -->
            <div class="settings-section <?php echo $section === 'appearance' ? 'active' : ''; ?>" id="appearance">
                <h2><i class="fas fa-paint-brush"></i> Appearance</h2>
                <form method="POST" action="settings.php">
                    <input type="hidden" name="action" value="update_appearance">
                    
                    <div class="form-group">
                        <label for="theme">Theme</label>
                        <select id="theme" name="theme">
                            <option value="light" <?php echo ($user['theme'] === 'light') ? 'selected' : ''; ?>>Light</option>
                            <option value="dark" <?php echo ($user['theme'] === 'dark') ? 'selected' : ''; ?>>Dark</option>
                            <option value="unite" <?php echo ($user['theme'] === 'unite') ? 'selected' : ''; ?>>Unite</option>
                            <option value="system" <?php echo ($user['theme'] === 'system') ? 'selected' : ''; ?>>System Default</option>
                        </select>
                </div>
                    
                    <button type="submit" class="btn-save-appearance">
                        <i class="fas fa-save"></i> Save Changes
                    </button>
                </form>
            </div>

            <!-- Reports Section -->
            <div class="settings-section <?php echo $section === 'reports' ? 'active' : ''; ?>" id="reports">
                <h2><i class="fas fa-flag"></i> Your Reports</h2>
                
                <?php if (isset($message)): ?>
                    <div class="alert <?php echo strpos($message, 'success') !== false ? 'success' : 'error'; ?>">
                        <i class="fas <?php echo strpos($message, 'success') !== false ? 'fa-check-circle' : 'fa-exclamation-circle'; ?>"></i>
                        <?php echo $message; ?>
                    </div>
                <?php endif; ?>

                <div class="reports-list">
                    <?php if (empty($reports)): ?>
                        <div class="empty-state">
                            <i class="fas fa-clipboard-list"></i>
                            <p>You haven't submitted any reports yet.</p>
                        </div>
                    <?php else: ?>
                        <?php foreach ($reports as $report): ?>
                            <div class="report-card">
                                <div class="report-header">
                                    <div>
                                        <strong>Reported User:</strong>
                                        <?php echo htmlspecialchars($report['reported_username']); ?>
                                        <span class="report-type">(<?php echo ucfirst($report['content_type']); ?>)</span>
                                    </div>
                                    <span class="report-status status-<?php echo $report['status']; ?>">
                                        <?php echo ucfirst($report['status']); ?>
                                    </span>
                                </div>
                                <?php if ($report['content_preview']): ?>
                                    <div class="report-content">
                                        <?php echo htmlspecialchars(substr($report['content_preview'], 0, 100)) . '...'; ?>
                                    </div>
                                <?php endif; ?>
                                <div class="report-reason">
                                    <i class="fas fa-exclamation-circle"></i>
                                    <strong>Reason:</strong> <?php echo htmlspecialchars($report['reason']); ?>
                                </div>
                                <?php if ($report['admin_response']): ?>
                                    <div class="admin-response">
                                        <i class="fas fa-comment-dots"></i>
                                        <strong>Admin Response:</strong> <?php echo htmlspecialchars($report['admin_response']); ?>
                                    </div>
                                <?php endif; ?>
                                <div class="report-date">
                                    <i class="fas fa-clock"></i>
                                    Submitted: <?php echo date('M j, Y g:i A', strtotime($report['created_at'])); ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // Update the section visibility logic
document.addEventListener('DOMContentLoaded', function() {
        // Get the current section from URL or default to 'account'
        const urlParams = new URLSearchParams(window.location.search);
        const currentSection = urlParams.get('section') || 'account';

        // Show the current section
        showSection(currentSection);

        // Add click handlers to navigation links
        document.querySelectorAll('.settings-nav a').forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const section = this.getAttribute('href').replace('?section=', '');
                showSection(section);
                
                // Update URL without page reload
                window.history.pushState({}, '', `?section=${section}`);
                
                // Update active state of nav links
                document.querySelectorAll('.settings-nav a').forEach(l => l.classList.remove('active'));
                this.classList.add('active');
            });
        });
    });

    function showSection(sectionId) {
        // Hide all sections
        document.querySelectorAll('.settings-section').forEach(section => {
            section.classList.remove('active');
        });

        // Show the selected section
        const targetSection = document.getElementById(sectionId);
        if (targetSection) {
            targetSection.classList.add('active');
        }

        // Update active state in navigation
        document.querySelectorAll('.settings-nav a').forEach(link => {
            if (link.getAttribute('href') === `?section=${sectionId}`) {
                link.classList.add('active');
            } else {
                link.classList.remove('active');
            }
        });
    }

    // Add report functionality
    function submitReport(contentType, contentId, reportedId) {
        const reason = prompt('Please provide a reason for your report:');
        if (!reason) return;

        fetch('includes/report_handler.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `content_type=${contentType}&content_id=${contentId}&reported_id=${reportedId}&reason=${encodeURIComponent(reason)}`
        })
        .then(response => response.json())
        .then(data => {
            alert(data.message);
            if (data.success) {
                window.location.reload();
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while submitting the report');
        });
    }

    // Theme switcher
    document.getElementById('theme').addEventListener('change', function() {
        document.body.className = this.value + '-theme';
        localStorage.setItem('theme', this.value);
    });

    // Load saved theme
    document.addEventListener('DOMContentLoaded', function() {
        const savedTheme = '<?php echo $user['theme'] ?? 'system'; ?>';
        if (savedTheme) {
            document.getElementById('theme').value = savedTheme;
            document.body.className = savedTheme + '-theme';
        }
    });

    // Password validation
    document.getElementById('passwordForm').addEventListener('submit', function(e) {
        const newPassword = document.getElementById('new_password').value;
        const confirmPassword = document.getElementById('confirm_password').value;
        
        if (newPassword !== confirmPassword) {
            e.preventDefault();
            showNotification('New passwords do not match', 'error');
            return;
        }
        
        if (newPassword.length < 8) {
            e.preventDefault();
            showNotification('Password must be at least 8 characters long', 'error');
            return;
        }
    });

    // Add mobile menu toggle functionality
    document.querySelector('.nav-toggle')?.addEventListener('click', function() {
        document.querySelector('.nav-menu').classList.toggle('active');
    });

    // Close mobile menu when clicking outside
    document.addEventListener('click', function(e) {
        const navMenu = document.querySelector('.nav-menu');
        const navToggle = document.querySelector('.nav-toggle');
        
        if (navMenu?.classList.contains('active') && 
            !navMenu.contains(e.target) && 
            !navToggle.contains(e.target)) {
            navMenu.classList.remove('active');
        }
    });
</script>
</body>
</html>
