<?php
session_start();

// Check if user is logged in
if (isset($_SESSION['user_id'])) {
    require_once 'config.php';
    
    // Check if user still exists and is not deleted
    $stmt = $conn->prepare("SELECT status FROM users WHERE id = ?");
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    // If user doesn't exist or is deleted/banned, clear session and redirect
    if (!$user || $user['status'] === 'deleted' || $user['status'] === 'banned') {
        // Store message for auth page
        $_SESSION['auth_message'] = "Your account has been removed by admin. Please contact the support administration.";
        
        // Clear all session data
        session_unset();
        session_destroy();
        
        // Start new session for message
        session_start();
        $_SESSION['auth_message'] = "Your account has been removed by admin. Please contact the support administration.";
        
        // Redirect to login page
        header("Location: auth.php");
        exit();
    }
}
?>