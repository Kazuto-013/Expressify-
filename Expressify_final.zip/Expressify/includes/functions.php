<?php
/**
 * Common utility functions for Expressify
 */

/**
 * Sanitize user input to prevent XSS attacks
 * 
 * @param string $input The input string to sanitize
 * @return string Sanitized string
 */
function sanitize_input($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

/**
 * Format a timestamp into a human-readable time ago format
 * 
 * @param string $datetime MySQL datetime string
 * @return string Human readable time (e.g. "2 hours ago")
 */
function timeAgo($datetime) {
    $time = strtotime($datetime);
    $now = time();
    $diff = $now - $time;
    
    if ($diff < 60) {
        return 'Just now';
    } elseif ($diff < 3600) {
        $mins = floor($diff / 60);
        return $mins . ' ' . ($mins == 1 ? 'minute' : 'minutes') . ' ago';
    } elseif ($diff < 86400) {
        $hours = floor($diff / 3600);
        return $hours . ' ' . ($hours == 1 ? 'hour' : 'hours') . ' ago';
    } elseif ($diff < 604800) {
        $days = floor($diff / 86400);
        return $days . ' ' . ($days == 1 ? 'day' : 'days') . ' ago';
    } elseif ($diff < 2592000) {
        $weeks = floor($diff / 604800);
        return $weeks . ' ' . ($weeks == 1 ? 'week' : 'weeks') . ' ago';
    } elseif ($diff < 31536000) {
        $months = floor($diff / 2592000);
        return $months . ' ' . ($months == 1 ? 'month' : 'months') . ' ago';
    } else {
        $years = floor($diff / 31536000);
        return $years . ' ' . ($years == 1 ? 'year' : 'years') . ' ago';
    }
}

/**
 * Generate a random string
 * 
 * @param int $length Length of the random string
 * @return string Random string
 */
function generate_random_string($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}

/**
 * Check if user is admin
 * 
 * @param int $user_id User ID to check
 * @param mysqli $conn MySQL connection
 * @return bool True if user is admin
 */
function is_admin($user_id, $conn) {
    $stmt = mysqli_prepare($conn, "SELECT id FROM admins WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);
    $count = mysqli_stmt_num_rows($stmt);
    mysqli_stmt_close($stmt);
    return $count > 0;
}

/**
 * Log admin action
 * 
 * @param int $admin_id Admin ID
 * @param string $action Action performed
 * @param string $target_type Type of target (user, post, etc.)
 * @param int $target_id ID of the target
 * @param mysqli $conn MySQL connection
 * @param string $details Additional details (optional)
 * @return bool Success or failure
 */
function log_admin_action($admin_id, $action, $target_type, $target_id, $conn, $details = '') {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    
    $stmt = mysqli_prepare($conn, "INSERT INTO admin_logs (admin_id, action, target_type, target_id, details, ip_address) 
                                  VALUES (?, ?, ?, ?, ?, ?)");
    mysqli_stmt_bind_param($stmt, "ississ", $admin_id, $action, $target_type, $target_id, $details, $ip);
    $result = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    
    return $result;
}

// Generate a random password
function generateRandomPassword($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*()-_';
    $password = '';
    $characterCount = strlen($characters);
    
    for ($i = 0; $i < $length; $i++) {
        $password .= $characters[rand(0, $characterCount - 1)];
    }
    
    return $password;
}

// Validate email
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Format file size
function formatFileSize($bytes) {
    if ($bytes >= 1073741824) {
        $bytes = number_format($bytes / 1073741824, 2) . ' GB';
    } elseif ($bytes >= 1048576) {
        $bytes = number_format($bytes / 1048576, 2) . ' MB';
    } elseif ($bytes >= 1024) {
        $bytes = number_format($bytes / 1024, 2) . ' KB';
    } elseif ($bytes > 1) {
        $bytes = $bytes . ' bytes';
    } elseif ($bytes == 1) {
        $bytes = $bytes . ' byte';
    } else {
        $bytes = '0 bytes';
    }
    return $bytes;
}

// Create session file for tracking login state
function createSession() {
    if (!isset($_SESSION)) {
        session_start();
    }
}

// Check if user is logged in
function isLoggedIn() {
    if (isset($_SESSION['user_id'])) {
        return true;
    }
    return false;
}

// Redirect to a URL
function redirect($url) {
    header("Location: $url");
    exit();
}

// Log errors
function logError($errorMessage, $errorType = 'general') {
    $logFile = __DIR__ . '/../logs/' . date('Y-m-d') . '_' . $errorType . '.log';
    $directory = dirname($logFile);
    
    // Create directory if it doesn't exist
    if (!is_dir($directory)) {
        mkdir($directory, 0755, true);
    }
    
    $timestamp = date('Y-m-d H:i:s');
    $logMessage = "[$timestamp] $errorMessage" . PHP_EOL;
    
    // Append to log file
    file_put_contents($logFile, $logMessage, FILE_APPEND);
}
?> 