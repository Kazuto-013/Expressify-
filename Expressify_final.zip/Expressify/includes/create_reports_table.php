<?php
require_once 'config.php';

// Create reports table
$createReportsTable = "CREATE TABLE IF NOT EXISTS `reports` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `reporter_id` int(11) NOT NULL,
    `reported_id` int(11) NOT NULL,
    `content_id` int(11) DEFAULT NULL,
    `content_type` enum('post','comment','profile') NOT NULL,
    `reason` text NOT NULL,
    `status` enum('pending','reviewed','resolved','dismissed') NOT NULL DEFAULT 'pending',
    `admin_response` text DEFAULT NULL,
    `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `reporter_id` (`reporter_id`),
    KEY `reported_id` (`reported_id`),
    FOREIGN KEY (`reporter_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
    FOREIGN KEY (`reported_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

try {
    if ($conn->query($createReportsTable)) {
        echo "Reports table created successfully";
    }
} catch (Exception $e) {
    echo "Error creating reports table: " . $e->getMessage();
}
?> 