<?php
function renderComment($comment, $currentUserId) {
    $isOwnComment = $comment['user_id'] == $currentUserId;
    ?>
    <div class="comment" data-comment-id="<?php echo $comment['id']; ?>">
        <div class="comment-header">
            <div class="comment-user-info">
                <img src="<?php echo !empty($comment['profile_picture']) ? $comment['profile_picture'] : 'assets/images/default_avatar.png'; ?>" 
                     alt="<?php echo htmlspecialchars($comment['username']); ?>" 
                     class="comment-avatar">
                <div class="comment-user-details">
                    <a href="profile.php?id=<?php echo $comment['user_id']; ?>" class="comment-username">
                        <?php echo htmlspecialchars($comment['username']); ?>
                    </a>
                    <span class="comment-date"><?php echo date('M j, Y g:i A', strtotime($comment['created_at'])); ?></span>
                </div>
            </div>
            <div class="comment-actions">
                <?php if (!$isOwnComment): ?>
                    <button onclick="submitReport('comment', <?php echo $comment['id']; ?>, <?php echo $comment['user_id']; ?>)" 
                            class="btn-report" title="Report Comment">
                        <i class="fas fa-flag"></i>
                    </button>
                <?php endif; ?>
                <?php if ($isOwnComment): ?>
                    <button class="btn-delete" onclick="deleteComment(<?php echo $comment['id']; ?>)">
                        <i class="fas fa-trash"></i>
                    </button>
                <?php endif; ?>
            </div>
        </div>
        <div class="comment-content">
            <?php echo nl2br(htmlspecialchars($comment['content'])); ?>
        </div>
    </div>
    <?php
}
?> 