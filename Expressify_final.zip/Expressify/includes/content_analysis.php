<?php
class ContentAnalysis {
    private $conn;
    private $toxic_words;
    private $spam_patterns;
    
    public function __construct($conn) {
        $this->conn = $conn;
        $this->initializeToxicWords();
        $this->initializeSpamPatterns();
    }
    
    private function initializeToxicWords() {
        // Load toxic words from database or file
        $this->toxic_words = [
            // Hate speech
            'hate', 'kill', 'die', 'stupid', 'idiot', 'dumb', 'retard', 'moron',
            'fool', 'jerk', 'asshole', 'bastard', 'bitch', 'cunt', 'whore', 'slut',
            'nazi', 'racist', 'sexist', 'homophobic', 'transphobic',
            
            // Violence
            'murder', 'suicide', 'shoot', 'stab', 'attack', 'fight', 'war', 'bomb',
            'terrorist', 'kill', 'death', 'dead', 'die', 'dying', 'deadly',
            
            // Harassment
            'stalk', 'harass', 'bully', 'threat', 'intimidate', 'abuse', 'harassment',
            'bullying', 'stalking', 'threatening', 'intimidation', 'abusive',
            
            // Discrimination
            'racist', 'sexist', 'homophobic', 'transphobic', 'xenophobic', 'bigot',
            'prejudice', 'discriminate', 'discrimination', 'stereotype', 'bias',
            
            // Explicit content
            'porn', 'sex', 'nude', 'naked', 'explicit', 'adult', 'xxx', 'nsfw',
            'fuck', 'shit', 'damn', 'hell', 'crap', 'piss', 'ass', 'bitch',
            
            // Scam/Spam related
            'scam', 'fraud', 'fake', 'phishing', 'virus', 'malware', 'hack', 'cheat',
            'steal', 'rob', 'scammer', 'fraudster', 'hacker', 'cheater', 'thief'
        ];
    }
    
    private function initializeSpamPatterns() {
        $this->spam_patterns = [
            // Commercial patterns
            '/\b(buy|cheap|discount|offer|price|sale|sell|shop|store|market|deal)\b/i',
            '/\b(limited|exclusive|special|promotion|coupon|voucher|code)\b/i',
            '/\b(free|gift|bonus|reward|prize|win|winner|lottery|raffle)\b/i',
            
            // Gambling patterns
            '/\b(casino|gambling|lottery|poker|bet|betting|wager|stake|odds)\b/i',
            '/\b(win|winning|jackpot|slot|roulette|blackjack|craps|baccarat)\b/i',
            
            // Pharmaceutical patterns
            '/\b(viagra|cialis|pharmacy|prescription|medication|drug|pill|tablet)\b/i',
            '/\b(health|medical|treatment|cure|remedy|supplement|vitamin)\b/i',
            
            // Financial patterns
            '/\b(earn|income|money|profit|rich|wealth|invest|investment|stock)\b/i',
            '/\b(crypto|bitcoin|ethereum|blockchain|wallet|mining|trading)\b/i',
            '/\b(loan|credit|debt|mortgage|finance|bank|account|payment)\b/i',
            
            // Adult content patterns
            '/\b(adult|porn|sex|xxx|nsfw|explicit|mature|dating|hookup)\b/i',
            '/\b(escort|massage|companion|meet|chat|video|webcam|live)\b/i',
            
            // Social media manipulation
            '/\b(follow|like|share|retweet|subscribe|view|watch|click|visit)\b/i',
            '/\b(boost|promote|viral|trending|popular|famous|influencer)\b/i',
            
            // Suspicious links
            '/\b(http|https|www|.com|.net|.org|.info|.biz|.xyz)\b/i',
            '/\b(link|url|website|site|webpage|page|download|file)\b/i',
            
            // Urgency patterns
            '/\b(urgent|immediate|now|today|limited|expire|expiring|last)\b/i',
            '/\b(hurry|quick|fast|instant|rush|emergency|important|critical)\b/i'
        ];
    }
    
    public function analyzeContent($content, $contentId, $contentType) {
        $toxicityScore = $this->calculateToxicityScore($content);
        $sentimentScore = $this->analyzeSentiment($content);
        $spamProbability = $this->detectSpam($content);
        $engagementScore = $this->calculateEngagementScore($contentId, $contentType);
        $qualityScore = $this->analyzeContentQuality($content);
        $readabilityScore = $this->analyzeReadability($content);
        $emotionScores = $this->analyzeEmotions($content);
        
        // Store analysis results
        $this->storeAnalysisResults(
            $contentId, 
            $contentType, 
            $toxicityScore, 
            $sentimentScore, 
            $spamProbability, 
            $engagementScore,
            $qualityScore,
            $readabilityScore,
            json_encode($emotionScores)
        );
        
        return [
            'toxicity_score' => $toxicityScore,
            'sentiment_score' => $sentimentScore,
            'spam_probability' => $spamProbability,
            'engagement_score' => $engagementScore,
            'quality_score' => $qualityScore,
            'readability_score' => $readabilityScore,
            'emotion_scores' => $emotionScores
        ];
    }
    
    private function calculateToxicityScore($content) {
        $content = strtolower($content);
        $words = str_word_count($content, 1);
        $toxicCount = 0;
        
        foreach ($words as $word) {
            if (in_array($word, $this->toxic_words)) {
                $toxicCount++;
            }
        }
        
        return $toxicCount > 0 ? $toxicCount / count($words) : 0;
    }
    
    private function analyzeSentiment($content) {
        // Initialize positive and negative word lists
        $positive_words = [
            'good', 'great', 'awesome', 'excellent', 'happy',
            'love', 'wonderful', 'fantastic', 'amazing', 'beautiful',
            'best', 'perfect', 'nice', 'brilliant', 'helpful'
        ];
        
        $negative_words = [
            'bad', 'terrible', 'awful', 'horrible', 'sad',
            'hate', 'worst', 'poor', 'disgusting', 'angry',
            'upset', 'disappointed', 'frustrating', 'useless', 'wrong'
        ];
        
        $content = strtolower($content);
        $words = str_word_count($content, 1);
        
        $positive_count = 0;
        $negative_count = 0;
        
        foreach ($words as $word) {
            if (in_array($word, $positive_words)) {
                $positive_count++;
            } elseif (in_array($word, $negative_words)) {
                $negative_count++;
            }
        }
        
        $total_words = count($words);
        if ($total_words === 0) return 0;
        
        return ($positive_count - $negative_count) / $total_words;
    }
    
    private function detectSpam($content) {
        $spamScore = 0;
        $totalPatterns = count($this->spam_patterns);
        
        foreach ($this->spam_patterns as $pattern) {
            if (preg_match($pattern, $content)) {
                $spamScore++;
            }
        }
        
        return $spamScore / $totalPatterns;
    }
    
    private function calculateEngagementScore($contentId, $contentType) {
        $score = 0;
        
        if ($contentType === 'post') {
            // Get likes, comments, and shares for posts
            $query = "SELECT 
                (SELECT COUNT(*) FROM likes WHERE post_id = ?) as like_count,
                (SELECT COUNT(*) FROM comments WHERE post_id = ?) as comment_count,
                (SELECT COUNT(*) FROM shares WHERE post_id = ?) as share_count";
        } else {
            // Get likes and replies for comments
            $query = "SELECT 
                (SELECT COUNT(*) FROM likes WHERE comment_id = ?) as like_count,
                (SELECT COUNT(*) FROM comments WHERE parent_comment_id = ?) as reply_count";
        }
        
        $stmt = $this->conn->prepare($query);
        
        if ($contentType === 'post') {
            $stmt->bind_param("iii", $contentId, $contentId, $contentId);
        } else {
            $stmt->bind_param("ii", $contentId, $contentId);
        }
        
        $stmt->execute();
        $result = $stmt->get_result()->fetch_assoc();
        
        if ($contentType === 'post') {
            $score = ($result['like_count'] * 1) + 
                    ($result['comment_count'] * 2) + 
                    ($result['share_count'] * 3);
        } else {
            $score = ($result['like_count'] * 1) + 
                    ($result['reply_count'] * 2);
        }
        
        // Normalize score between 0 and 1
        $maxScore = $contentType === 'post' ? 100 : 50; // Adjust these values based on your needs
        return min($score / $maxScore, 1);
    }
    
    private function storeAnalysisResults($contentId, $contentType, $toxicityScore, $sentimentScore, $spamProbability, $engagementScore, $qualityScore, $readabilityScore, $emotionScores) {
        $query = "INSERT INTO content_analysis 
                 (content_id, content_type, toxicity_score, sentiment_score, spam_probability, engagement_score, quality_score, readability_score, emotion_scores) 
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                 ON DUPLICATE KEY UPDATE 
                 toxicity_score = VALUES(toxicity_score),
                 sentiment_score = VALUES(sentiment_score),
                 spam_probability = VALUES(spam_probability),
                 engagement_score = VALUES(engagement_score),
                 quality_score = VALUES(quality_score),
                 readability_score = VALUES(readability_score),
                 emotion_scores = VALUES(emotion_scores),
                 updated_at = CURRENT_TIMESTAMP";
                 
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("isddddssss", 
            $contentId, 
            $contentType, 
            $toxicityScore, 
            $sentimentScore, 
            $spamProbability, 
            $engagementScore,
            $qualityScore,
            $readabilityScore,
            $emotionScores
        );
        
        $stmt->execute();
    }
    
    public function getContentAnalysis($contentId, $contentType) {
        $query = "SELECT * FROM content_analysis WHERE content_id = ? AND content_type = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("is", $contentId, $contentType);
        $stmt->execute();
        
        return $stmt->get_result()->fetch_assoc();
    }
    
    public function getFlaggedContent($threshold = 0.7, $limit = 10) {
        $query = "SELECT ca.*, 
                 CASE 
                    WHEN ca.content_type = 'post' THEN p.content 
                    ELSE c.comment_text 
                 END as content,
                 u.username,
                 u.profile_picture
                 FROM content_analysis ca
                 LEFT JOIN posts p ON ca.content_type = 'post' AND ca.content_id = p.id
                 LEFT JOIN comments c ON ca.content_type = 'comment' AND ca.content_id = c.id
                 LEFT JOIN users u ON 
                    CASE 
                        WHEN ca.content_type = 'post' THEN p.user_id = u.id
                        ELSE c.user_id = u.id
                    END
                 WHERE ca.toxicity_score >= ?
                 ORDER BY ca.toxicity_score DESC
                 LIMIT ?";
                 
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("di", $threshold, $limit);
        $stmt->execute();
        
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    
    public function getContentTrends($startDate, $endDate) {
        $query = "SELECT 
                 DATE(ca.created_at) as date,
                 AVG(ca.toxicity_score) as avg_toxicity,
                 AVG(ca.sentiment_score) as avg_sentiment,
                 AVG(ca.engagement_score) as avg_engagement,
                 COUNT(*) as total_content
                 FROM content_analysis ca
                 WHERE ca.created_at BETWEEN ? AND ?
                 GROUP BY DATE(ca.created_at)
                 ORDER BY date";
                 
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ss", $startDate, $endDate);
        $stmt->execute();
        
        return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    }
    
    private function analyzeContentQuality($content) {
        $qualityScore = 0;
        
        // Check content length
        $contentLength = strlen($content);
        if ($contentLength < 10) {
            $qualityScore -= 0.3;
        } elseif ($contentLength > 1000) {
            $qualityScore += 0.2;
        }
        
        // Check for capitalization
        $capitalizedWords = preg_match_all('/\b[A-Z][a-z]+\b/', $content);
        $totalWords = str_word_count($content);
        if ($totalWords > 0) {
            $capitalizationRatio = $capitalizedWords / $totalWords;
            if ($capitalizationRatio > 0.1) {
                $qualityScore += 0.1;
            }
        }
        
        // Check for punctuation
        $punctuationCount = preg_match_all('/[.,!?;:]/', $content);
        if ($punctuationCount > 0) {
            $qualityScore += 0.1;
        }
        
        // Check for paragraph structure
        $paragraphs = preg_split('/\n\s*\n/', $content);
        if (count($paragraphs) > 1) {
            $qualityScore += 0.2;
        }
        
        return max(0, min(1, $qualityScore));
    }
    
    private function analyzeReadability($content) {
        $readabilityScore = 0;
        
        // Count sentences
        $sentences = preg_split('/[.!?]+/', $content);
        $sentenceCount = count($sentences);
        
        // Count words
        $words = str_word_count($content);
        
        // Calculate average sentence length
        if ($sentenceCount > 0) {
            $avgSentenceLength = $words / $sentenceCount;
            if ($avgSentenceLength < 20) {
                $readabilityScore += 0.3;
            } elseif ($avgSentenceLength < 30) {
                $readabilityScore += 0.2;
            }
        }
        
        // Check for complex words (words with 3 or more syllables)
        $complexWords = 0;
        foreach (str_word_count($content, 1) as $word) {
            if (preg_match_all('/[aeiouy]+/i', $word) >= 3) {
                $complexWords++;
            }
        }
        
        if ($words > 0) {
            $complexityRatio = $complexWords / $words;
            if ($complexityRatio < 0.2) {
                $readabilityScore += 0.3;
            } elseif ($complexityRatio < 0.3) {
                $readabilityScore += 0.2;
            }
        }
        
        return max(0, min(1, $readabilityScore));
    }
    
    private function analyzeEmotions($content) {
        $emotions = [
            'joy' => ['happy', 'joy', 'excited', 'delighted', 'pleased', 'glad', 'cheerful', 'ecstatic'],
            'sadness' => ['sad', 'unhappy', 'depressed', 'gloomy', 'miserable', 'heartbroken', 'sorrow'],
            'anger' => ['angry', 'mad', 'furious', 'enraged', 'irritated', 'annoyed', 'outraged'],
            'fear' => ['afraid', 'scared', 'frightened', 'terrified', 'worried', 'anxious', 'nervous'],
            'surprise' => ['surprised', 'amazed', 'astonished', 'shocked', 'stunned', 'astounded'],
            'disgust' => ['disgusted', 'revolted', 'sickened', 'repulsed', 'appalled', 'horrified']
        ];
        
        $emotionScores = [];
        $content = strtolower($content);
        
        foreach ($emotions as $emotion => $words) {
            $count = 0;
            foreach ($words as $word) {
                $count += substr_count($content, $word);
            }
            $emotionScores[$emotion] = $count;
        }
        
        // Normalize scores
        $total = array_sum($emotionScores);
        if ($total > 0) {
            foreach ($emotionScores as &$score) {
                $score = $score / $total;
            }
        }
        
        return $emotionScores;
    }
}

// Example usage:
/*
$analysis = new ContentAnalysis($conn);

// Analyze new content
$result = $analysis->analyzeContent(
    "This is a great post!", // content
    1, // content_id
    'post' // content_type
);

// Get analysis for existing content
$existing = $analysis->getContentAnalysis(1, 'post');

// Get flagged content
$flagged = $analysis->getFlaggedContent();

// Get content trends
$trends = $analysis->getContentTrends(
    date('Y-m-d', strtotime('-7 days')),
    date('Y-m-d')
);
*/ 