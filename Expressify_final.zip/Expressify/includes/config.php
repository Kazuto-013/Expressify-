<?php
// Display errors for troubleshooting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// ******************************************
// IMPORTANT: Configure MySQL credentials here
// ******************************************
$host = "localhost";      // Usually localhost for WAMP
$username = "root";       // Default is root for WAMP
$password = "1234";           // Default for WAMP is blank password

// Simple direct connection 
try {
    // Connect to MySQL server first
    $conn = mysqli_connect($host, $username, $password);
    
    if (!$conn) {
        throw new Exception("Connection failed: " . mysqli_connect_error());
    }
    
    // Create database if it doesn't exist
    $database = "expressify_db";
    if (!mysqli_query($conn, "CREATE DATABASE IF NOT EXISTS `$database`")) {
        throw new Exception("Error creating database: " . mysqli_error($conn));
    }
    
    // Select the database
    if (!mysqli_select_db($conn, $database)) {
        throw new Exception("Error selecting database: " . mysqli_error($conn));
    }
    
    // Set charset
    mysqli_set_charset($conn, "utf8mb4");
    
    // Check if tables need to be created (first run)
    $result = mysqli_query($conn, "SHOW TABLES LIKE 'users'");
    if (!$result || mysqli_num_rows($result) == 0) {
        // Create the required tables
        $tables = [
            // Users table
            "CREATE TABLE IF NOT EXISTS `users` (
                `id` INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                `username` VARCHAR(50) NOT NULL UNIQUE,
                `email` VARCHAR(100) NOT NULL UNIQUE,
                `password` VARCHAR(255) NOT NULL,
                `profile_pic` VARCHAR(255) DEFAULT NULL,
                `bio` TEXT DEFAULT NULL,
                `status` ENUM('active', 'inactive', 'banned') DEFAULT 'active',
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            
            // Posts table
            "CREATE TABLE IF NOT EXISTS `posts` (
                `id` INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                `user_id` INT(11) UNSIGNED NOT NULL,
                `content` TEXT DEFAULT NULL,
                `media` VARCHAR(255) DEFAULT NULL,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            
            // Comments table
            "CREATE TABLE IF NOT EXISTS `comments` (
                `id` INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                `post_id` INT(11) UNSIGNED NOT NULL,
                `user_id` INT(11) UNSIGNED NOT NULL,
                `comment_text` TEXT NOT NULL,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (`post_id`) REFERENCES `posts`(`id`) ON DELETE CASCADE,
                FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            
            // Likes table
            "CREATE TABLE IF NOT EXISTS `likes` (
                `id` INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                `post_id` INT(11) UNSIGNED NOT NULL,
                `user_id` INT(11) UNSIGNED NOT NULL,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY `unique_like` (`post_id`, `user_id`),
                FOREIGN KEY (`post_id`) REFERENCES `posts`(`id`) ON DELETE CASCADE,
                FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            
            // Followers table
            "CREATE TABLE IF NOT EXISTS `followers` (
                `id` INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                `follower_id` INT(11) UNSIGNED NOT NULL,
                `following_id` INT(11) UNSIGNED NOT NULL,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY `unique_follow` (`follower_id`, `following_id`),
                FOREIGN KEY (`follower_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
                FOREIGN KEY (`following_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            
            // Admin table
            "CREATE TABLE IF NOT EXISTS `admins` (
                `id` INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                `email` VARCHAR(255) NOT NULL UNIQUE,
                `password` VARCHAR(255) NOT NULL,
                `name` VARCHAR(100) DEFAULT NULL,
                `role` VARCHAR(50) DEFAULT 'admin',
                `last_login` DATETIME DEFAULT NULL,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            
            // Reported content
            "CREATE TABLE IF NOT EXISTS `reported_content` (
                `id` INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                `reporter_id` INT(11) UNSIGNED NOT NULL,
                `content_type` ENUM('post', 'comment', 'user') NOT NULL,
                `content_id` INT(11) UNSIGNED NOT NULL,
                `reason` VARCHAR(100) NOT NULL,
                `description` TEXT DEFAULT NULL,
                `status` ENUM('pending', 'reviewed', 'actioned', 'dismissed') DEFAULT 'pending',
                `admin_id` INT(11) UNSIGNED DEFAULT NULL,
                `admin_notes` TEXT DEFAULT NULL,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                FOREIGN KEY (`reporter_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
                FOREIGN KEY (`admin_id`) REFERENCES `admins`(`id`) ON DELETE SET NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            
            // Admin logs
            "CREATE TABLE IF NOT EXISTS `admin_logs` (
                `id` INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                `admin_id` INT(11) UNSIGNED NOT NULL,
                `action` VARCHAR(50) NOT NULL,
                `target_type` VARCHAR(50) NOT NULL,
                `target_id` INT(11) UNSIGNED NOT NULL,
                `details` TEXT DEFAULT NULL,
                `ip_address` VARCHAR(45) DEFAULT NULL,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (`admin_id`) REFERENCES `admins`(`id`) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        ];
        
        // Execute each table creation SQL
        foreach ($tables as $table_sql) {
            if (!mysqli_query($conn, $table_sql)) {
                throw new Exception("Error creating table: " . mysqli_error($conn));
            }
        }
        
        // Insert default admin account if admins table was just created
        $admin_check = mysqli_query($conn, "SELECT COUNT(*) as count FROM `admins`");
        $admin_count = mysqli_fetch_assoc($admin_check)['count'];
        
        if ($admin_count == 0) {
            $admin_email = "admin@expressify.com";
            $admin_password = password_hash("admin123", PASSWORD_DEFAULT);
            $sql = "INSERT INTO `admins` (`email`, `password`, `name`, `role`) 
                    VALUES ('$admin_email', '$admin_password', 'Admin', 'super_admin')";
                    
            mysqli_query($conn, $sql);
        }
    }
    
} catch (Exception $e) {
    // Display user-friendly error message
    echo '<div style="background-color: #ffebee; color: #c62828; padding: 20px; margin: 20px; border-radius: 5px; font-family: Arial, sans-serif;">';
    echo '<h2>Database Error</h2>';
    echo '<p>' . $e->getMessage() . '</p>';
    echo '<p>Please check the following:</p>';
    echo '<ul>';
    echo '<li>Ensure WAMP server is running (green icon in system tray)</li>';
    echo '<li>Check MySQL service is active in WAMP</li>';
    echo '<li>Try accessing phpMyAdmin to verify MySQL is working</li>';
    echo '</ul>';
    echo '<p><strong>Connection details:</strong> Host: ' . $host . ', User: ' . $username . ', Password: ' . ($password ? '(set)' : '(empty)') . '</p>';
    echo '</div>';
    die();
}

// Set timezone
date_default_timezone_set('UTC');
?> 