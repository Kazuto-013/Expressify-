<?php
/**
 * Report Functions for Expressify
 * 
 * This file contains various functions related to content reporting and moderation
 */

/**
 * Get report categories
 * 
 * @param bool $active_only Whether to return only active categories
 * @return array Array of report categories
 */
function getReportCategories($active_only = true) {
    global $conn;
    
    $sql = "SELECT id, category, report_count 
            FROM reports 
            " . ($active_only ? "WHERE is_active = 1 " : "") . "
            ORDER BY report_count DESC";
    
    $result = $conn->query($sql);
    $categories = [];
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $categories[] = $row;
        }
    }
    
    return $categories;
}

/**
 * Get pending report count
 * 
 * @return int Number of pending reports
 */
function getPendingReportCount() {
    global $conn;
    
    $sql = "SELECT COUNT(*) as count FROM reported_content WHERE status = 'pending'";
    $result = $conn->query($sql);
    
    if ($result && $result->num_rows > 0) {
        return $result->fetch_assoc()['count'];
    }
    
    return 0;
}

/**
 * Get reports by status
 * 
 * @param string $status Status to filter by (pending, reviewed, resolved, dismissed)
 * @param int $limit Number of reports to return
 * @param int $offset Offset for pagination
 * @return array Array of reports
 */
function getReportsByStatus($status = 'pending', $limit = 20, $offset = 0) {
    global $conn;
    
    $status = mysqli_real_escape_string($conn, $status);
    $limit = (int)$limit;
    $offset = (int)$offset;
    
    $sql = "SELECT rc.*, u_reporter.username as reporter_username, 
            CASE 
                WHEN rc.content_type = 'post' THEN (SELECT content FROM posts WHERE id = rc.content_id)
                WHEN rc.content_type = 'comment' THEN (SELECT comment FROM comments WHERE id = rc.content_id)
                WHEN rc.content_type = 'user' THEN (SELECT username FROM users WHERE id = rc.content_id)
            END as content_preview,
            CASE
                WHEN rc.content_type = 'post' THEN (SELECT user_id FROM posts WHERE id = rc.content_id)
                WHEN rc.content_type = 'comment' THEN (SELECT user_id FROM comments WHERE id = rc.content_id)
                WHEN rc.content_type = 'user' THEN rc.content_id
            END as content_owner_id,
            a.admin_name 
            FROM reported_content rc
            LEFT JOIN users u_reporter ON rc.reporter_id = u_reporter.id
            LEFT JOIN admins a ON rc.admin_id = a.id
            WHERE rc.status = '$status'
            ORDER BY rc.created_at DESC
            LIMIT $limit OFFSET $offset";
    
    $result = $conn->query($sql);
    $reports = [];
    
    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            // Get content owner username
            if ($row['content_owner_id']) {
                $owner_query = $conn->query("SELECT username FROM users WHERE id = " . $row['content_owner_id']);
                if ($owner_query && $owner_query->num_rows > 0) {
                    $row['content_owner_username'] = $owner_query->fetch_assoc()['username'];
                }
            }
            
            // Truncate content preview
            if ($row['content_preview'] && strlen($row['content_preview']) > 100) {
                $row['content_preview'] = substr($row['content_preview'], 0, 100) . '...';
            }
            
            $reports[] = $row;
        }
    }
    
    return $reports;
}

/**
 * Get total count of reports by status
 * 
 * @param string $status Status to filter by
 * @return int Total count
 */
function getReportCountByStatus($status = 'pending') {
    global $conn;
    
    $status = mysqli_real_escape_string($conn, $status);
    
    $sql = "SELECT COUNT(*) as count FROM reported_content WHERE status = '$status'";
    $result = $conn->query($sql);
    
    if ($result && $result->num_rows > 0) {
        return $result->fetch_assoc()['count'];
    }
    
    return 0;
}

/**
 * Update report status
 * 
 * @param int $report_id Report ID
 * @param string $status New status
 * @param int $admin_id Admin ID
 * @param string $notes Admin notes
 * @return bool Success status
 */
function updateReportStatus($report_id, $status, $admin_id, $notes = '') {
    global $conn;
    
    $report_id = (int)$report_id;
    $status = mysqli_real_escape_string($conn, $status);
    $admin_id = (int)$admin_id;
    $notes = mysqli_real_escape_string($conn, $notes);
    
    // Validate status
    if (!in_array($status, ['pending', 'reviewed', 'resolved', 'dismissed'])) {
        return false;
    }
    
    $sql = "UPDATE reported_content 
            SET status = '$status', admin_id = $admin_id, admin_notes = '$notes'
            WHERE id = $report_id";
    
    return $conn->query($sql);
}

/**
 * Log admin action on a report
 * 
 * @param int $report_id Report ID
 * @param int $admin_id Admin ID
 * @param string $action Action taken
 * @param string $notes Additional notes
 * @return bool Success status
 */
function logReportAction($report_id, $admin_id, $action, $notes = '') {
    global $conn;
    
    $report_id = (int)$report_id;
    $admin_id = (int)$admin_id;
    $action = mysqli_real_escape_string($conn, $action);
    $notes = mysqli_real_escape_string($conn, $notes);
    
    // Check if admin_actions table exists, create if not
    $result = $conn->query("SHOW TABLES LIKE 'admin_actions'");
    if ($result->num_rows === 0) {
        $createTableSQL = "CREATE TABLE admin_actions (
            id INT PRIMARY KEY AUTO_INCREMENT,
            admin_id INT NOT NULL,
            action_type VARCHAR(50) NOT NULL,
            related_id INT,
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE CASCADE
        ) CHARSET=utf8mb4";
        
        if (!$conn->query($createTableSQL)) {
            return false;
        }
    }
    
    $sql = "INSERT INTO admin_actions (admin_id, action_type, related_id, notes)
            VALUES ($admin_id, '$action', $report_id, '$notes')";
    
    return $conn->query($sql);
}

/**
 * Get a single report with all details
 * 
 * @param int $report_id Report ID
 * @return array|bool Report data or false if not found
 */
function getReportDetails($report_id) {
    global $conn;
    
    $report_id = (int)$report_id;
    
    $sql = "SELECT rc.*, 
            u_reporter.username as reporter_username,
            u_reporter.email as reporter_email,
            u_reporter.profile_picture as reporter_profile,
            a.admin_name,
            r.category
            FROM reported_content rc
            LEFT JOIN users u_reporter ON rc.reporter_id = u_reporter.id
            LEFT JOIN admins a ON rc.admin_id = a.id
            LEFT JOIN report_content_map rcm ON rc.id = rcm.reported_content_id
            LEFT JOIN reports r ON rcm.report_id = r.id
            WHERE rc.id = $report_id";
    
    $result = $conn->query($sql);
    
    if ($result && $result->num_rows > 0) {
        $report = $result->fetch_assoc();
        
        // Get content details based on type
        if ($report['content_type'] === 'post') {
            $content_query = $conn->query("
                SELECT p.*, u.username, u.profile_picture 
                FROM posts p
                JOIN users u ON p.user_id = u.id
                WHERE p.id = " . $report['content_id']
            );
            
            if ($content_query && $content_query->num_rows > 0) {
                $report['content_details'] = $content_query->fetch_assoc();
            }
        } 
        elseif ($report['content_type'] === 'comment') {
            $content_query = $conn->query("
                SELECT c.*, u.username, u.profile_picture, p.id as post_id, p.content as post_content
                FROM comments c
                JOIN users u ON c.user_id = u.id
                JOIN posts p ON c.post_id = p.id
                WHERE c.id = " . $report['content_id']
            );
            
            if ($content_query && $content_query->num_rows > 0) {
                $report['content_details'] = $content_query->fetch_assoc();
            }
        }
        elseif ($report['content_type'] === 'user') {
            $content_query = $conn->query("
                SELECT id, username, email, bio, profile_picture, cover_pic, status, created_at
                FROM users
                WHERE id = " . $report['content_id']
            );
            
            if ($content_query && $content_query->num_rows > 0) {
                $report['content_details'] = $content_query->fetch_assoc();
            }
        }
        
        return $report;
    }
    
    return false;
}

/**
 * Take action on reported content
 * 
 * @param int $report_id Report ID
 * @param string $action Action to take (delete, hide, warn, ban)
 * @param int $admin_id Admin ID
 * @return bool Success status
 */
function takeActionOnReportedContent($report_id, $action, $admin_id) {
    global $conn;
    
    $report_id = (int)$report_id;
    $action = mysqli_real_escape_string($conn, $action);
    $admin_id = (int)$admin_id;
    
    // Get report details
    $report = getReportDetails($report_id);
    if (!$report) {
        return false;
    }
    
    $content_type = $report['content_type'];
    $content_id = $report['content_id'];
    $success = false;
    
    switch ($action) {
        case 'delete':
            if ($content_type === 'post') {
                $success = $conn->query("DELETE FROM posts WHERE id = $content_id");
            } elseif ($content_type === 'comment') {
                $success = $conn->query("DELETE FROM comments WHERE id = $content_id");
            }
            break;
            
        case 'hide':
            if ($content_type === 'post') {
                // Add 'hidden' column if it doesn't exist
                $result = $conn->query("SHOW COLUMNS FROM posts LIKE 'hidden'");
                if ($result->num_rows === 0) {
                    $conn->query("ALTER TABLE posts ADD COLUMN hidden TINYINT(1) DEFAULT 0");
                }
                $success = $conn->query("UPDATE posts SET hidden = 1 WHERE id = $content_id");
            } elseif ($content_type === 'comment') {
                // Add 'hidden' column if it doesn't exist
                $result = $conn->query("SHOW COLUMNS FROM comments LIKE 'hidden'");
                if ($result->num_rows === 0) {
                    $conn->query("ALTER TABLE comments ADD COLUMN hidden TINYINT(1) DEFAULT 0");
                }
                $success = $conn->query("UPDATE comments SET hidden = 1 WHERE id = $content_id");
            }
            break;
            
        case 'warn':
            if ($content_type === 'user') {
                // Record a warning for this user
                $result = $conn->query("SHOW TABLES LIKE 'user_warnings'");
                if ($result->num_rows === 0) {
                    $conn->query("CREATE TABLE user_warnings (
                        id INT PRIMARY KEY AUTO_INCREMENT,
                        user_id INT NOT NULL,
                        admin_id INT NOT NULL,
                        reason TEXT,
                        report_id INT,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
                        FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE CASCADE
                    ) CHARSET=utf8mb4");
                }
                
                $reason = "Warned due to reported " . $content_type . " #" . $content_id;
                $stmt = $conn->prepare("INSERT INTO user_warnings (user_id, admin_id, reason, report_id) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("iisi", $content_id, $admin_id, $reason, $report_id);
                $success = $stmt->execute();
                $stmt->close();
            }
            break;
            
        case 'ban':
            if ($content_type === 'user') {
                $success = $conn->query("UPDATE users SET status = 'banned' WHERE id = $content_id");
            }
            break;
    }
    
    if ($success) {
        // Update report status to resolved
        updateReportStatus($report_id, 'resolved', $admin_id, "Action taken: $action");
        
        // Log the action
        logReportAction($report_id, $admin_id, "content_$action", "Action taken on " . $content_type . " #" . $content_id);
        
        return true;
    }
    
    return false;
} 