<?php
require_once 'session.php';
require_once 'config.php';
require_once 'functions.php';

// Function to check content for inappropriate words
function checkInappropriateContent($text) {
    $inappropriate_words = array("idiot", "bastard");
    $text = strtolower($text);
    
    foreach ($inappropriate_words as $word) {
        if (strpos($text, $word) !== false) {
            return true;
        }
    }
    return false;
}

// Function to delete inappropriate post
function deleteInappropriatePost($post_id, $conn) {
    try {
        // First delete associated comments
        $delete_comments = "DELETE FROM comments WHERE post_id = ?";
        $stmt = $conn->prepare($delete_comments);
        $stmt->bind_param("i", $post_id);
        $stmt->execute();

        // Then delete the post
        $delete_post = "DELETE FROM posts WHERE id = ?";
        $stmt = $conn->prepare($delete_post);
        $stmt->bind_param("i", $post_id);
        $stmt->execute();

        return true;
    } catch (Exception $e) {
        error_log("Error deleting inappropriate post: " . $e->getMessage());
        return false;
    }
}

// Function to delete inappropriate comment
function deleteInappropriateComment($comment_id, $conn) {
    try {
        $delete_comment = "DELETE FROM comments WHERE id = ?";
        $stmt = $conn->prepare($delete_comment);
        $stmt->bind_param("i", $comment_id);
        $stmt->execute();
        return true;
    } catch (Exception $e) {
        error_log("Error deleting inappropriate comment: " . $e->getMessage());
        return false;
    }
}

// Handle AJAX requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    $response = array('success' => false, 'message' => '');

    // Check post content
    if (isset($_POST['action']) && $_POST['action'] === 'check_post') {
        $post_content = $_POST['content'];
        
        if (checkInappropriateContent($post_content)) {
            if (isset($_POST['post_id'])) {
                if (deleteInappropriatePost($_POST['post_id'], $conn)) {
                    $response = array(
                        'success' => true,
                        'message' => 'Post contains inappropriate content and has been removed.',
                        'warning' => 'Please do not post this type of content. Your post has been deleted.',
                        'post_id' => $_POST['post_id']
                    );
                }
            } else {
                $response = array(
                    'success' => true,
                    'message' => 'Post contains inappropriate content.',
                    'warning' => 'Please do not post this type of content. Your post cannot be submitted.'
                );
            }
        } else {
            $response['success'] = true;
            $response['message'] = 'Content is appropriate';
        }
    }

    // Check comment content
    if (isset($_POST['action']) && $_POST['action'] === 'check_comment') {
        $comment_content = $_POST['content'];
        
        if (checkInappropriateContent($comment_content)) {
            if (isset($_POST['comment_id'])) {
                if (deleteInappropriateComment($_POST['comment_id'], $conn)) {
                    $response = array(
                        'success' => true,
                        'message' => 'Comment contains inappropriate content and has been removed.',
                        'warning' => 'Please do not post this type of content. Your comment has been deleted.',
                        'comment_id' => $_POST['comment_id']
                    );
                }
            } else {
                $response = array(
                    'success' => true,
                    'message' => 'Comment contains inappropriate content.',
                    'warning' => 'Please do not post this type of content. Your comment cannot be submitted.'
                );
            }
        } else {
            $response['success'] = true;
            $response['message'] = 'Content is appropriate';
        }
    }

    echo json_encode($response);
    exit;
}
?>

<!-- Add this JavaScript code to your pages that have posts/comments -->
<script>
// Function to show warning dialog
function showWarningDialog(message) {
    // Remove any existing warning dialogs
    const existingDialog = document.querySelector('.warning-dialog');
    if (existingDialog) {
        existingDialog.remove();
    }

    // Create and show a custom dialog box
    const dialog = document.createElement('div');
    dialog.className = 'warning-dialog';
    dialog.innerHTML = `
        <div class="warning-content">
            <div class="warning-icon">
                <i class="fas fa-exclamation-triangle"></i>
            </div>
            <h3>Warning</h3>
            <p>${message}</p>
            <button onclick="this.closest('.warning-dialog').remove()">OK</button>
        </div>
    `;
    document.body.appendChild(dialog);

    // Add fade-in effect
    setTimeout(() => dialog.classList.add('show'), 10);
}

// Function to check post content
async function checkPostContent(content, postId = null) {
    try {
        const formData = new FormData();
        formData.append('action', 'check_post');
        formData.append('content', content);
        if (postId) formData.append('post_id', postId);

        const response = await fetch('includes/content_moderation.php', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();
        
        if (result.warning) {
            showWarningDialog(result.warning);
            
            // If post was deleted, remove it from the page
            if (result.post_id) {
                const postElement = document.querySelector(`.post[data-post-id="${result.post_id}"]`);
                if (postElement) {
                    postElement.style.animation = 'fadeOut 0.3s ease';
                    setTimeout(() => postElement.remove(), 300);
                }
            }
            return false;
        }
        
        return result.success;
    } catch (error) {
        console.error('Error checking post content:', error);
        return false;
    }
}

// Function to check comment content
async function checkCommentContent(content, commentId = null) {
    try {
        const formData = new FormData();
        formData.append('action', 'check_comment');
        formData.append('content', content);
        if (commentId) formData.append('comment_id', commentId);

        const response = await fetch('includes/content_moderation.php', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();
        
        if (result.warning) {
            showWarningDialog(result.warning);
            
            // If comment was deleted, remove it from the page
            if (result.comment_id) {
                const commentElement = document.querySelector(`.comment[data-comment-id="${result.comment_id}"]`);
                if (commentElement) {
                    commentElement.style.animation = 'fadeOut 0.3s ease';
                    setTimeout(() => commentElement.remove(), 300);
                }
            }
            return false;
        }
        
        return result.success;
    } catch (error) {
        console.error('Error checking comment content:', error);
        return false;
    }
}

// Add this CSS to your stylesheet
const style = document.createElement('style');
style.textContent = `
    .warning-dialog {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.7);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 9999;
        opacity: 0;
        transition: opacity 0.3s ease;
    }

    .warning-dialog.show {
        opacity: 1;
    }

    .warning-content {
        background: white;
        padding: 25px;
        border-radius: 10px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        max-width: 400px;
        width: 90%;
        text-align: center;
        transform: translateY(-20px);
        transition: transform 0.3s ease;
    }

    .warning-dialog.show .warning-content {
        transform: translateY(0);
    }

    .warning-icon {
        color: #dc3545;
        font-size: 48px;
        margin-bottom: 15px;
    }

    .warning-content h3 {
        color: #dc3545;
        margin: 0 0 15px 0;
        font-size: 24px;
    }

    .warning-content p {
        color: #333;
        margin: 0 0 20px 0;
        line-height: 1.5;
    }

    .warning-content button {
        background: #dc3545;
        color: white;
        border: none;
        padding: 10px 25px;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
        transition: background-color 0.2s ease;
    }

    .warning-content button:hover {
        background: #c82333;
    }

    @keyframes fadeOut {
        from { opacity: 1; transform: translateY(0); }
        to { opacity: 0; transform: translateY(-20px); }
    }
`;
document.head.appendChild(style);

// Example usage for post form
document.querySelector('form.post-form')?.addEventListener('submit', async function(e) {
    e.preventDefault();
    const content = this.querySelector('textarea[name="content"]').value;
    
    if (await checkPostContent(content)) {
        this.submit();
    }
});

// Example usage for comment form
document.querySelector('form.comment-form')?.addEventListener('submit', async function(e) {
    e.preventDefault();
    const content = this.querySelector('textarea[name="content"]').value;
    
    if (await checkCommentContent(content)) {
        this.submit();
    }
});

// Check existing content periodically
function checkExistingContent() {
    // Check posts
    document.querySelectorAll('.post-content').forEach(async post => {
        const content = post.textContent;
        const postId = post.closest('.post')?.dataset.postId;
        if (content && postId) {
            await checkPostContent(content, postId);
        }
    });

    // Check comments
    document.querySelectorAll('.comment-content').forEach(async comment => {
        const content = comment.textContent;
        const commentId = comment.closest('.comment')?.dataset.commentId;
        if (content && commentId) {
            await checkCommentContent(content, commentId);
        }
    });
}

// Run check every 5 minutes
setInterval(checkExistingContent, 300000);

// Initial check when page loads
document.addEventListener('DOMContentLoaded', checkExistingContent);
</script> 