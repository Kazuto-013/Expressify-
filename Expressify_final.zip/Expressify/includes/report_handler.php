<?php
require_once 'session.php';
require_once 'config.php';

// Create reports table if it doesn't exist
$create_reports_table = "CREATE TABLE IF NOT EXISTS reported_content (
    id INT PRIMARY KEY AUTO_INCREMENT,
    reporter_id INT NOT NULL,
    content_type ENUM('post', 'comment', 'user') NOT NULL,
    content_id INT NOT NULL,
    reason VARCHAR(100) NOT NULL,
    description TEXT,
    status ENUM('pending', 'reviewed', 'resolved', 'dismissed') DEFAULT 'pending',
    admin_id INT NULL,
    admin_notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX (content_type, content_id),
    INDEX (status),
    INDEX (reporter_id),
    FOREIGN KEY (reporter_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci";

$conn->query($create_reports_table);

// Create admin_notifications table if it doesn't exist
$create_admin_notifications = "CREATE TABLE IF NOT EXISTS admin_notifications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    type VARCHAR(50) NOT NULL,
    content_id INT NOT NULL,
    user_id INT NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
)";

$conn->query($create_admin_notifications);

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ensure user is logged in
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['success' => false, 'message' => 'Please log in to report.']);
        exit;
    }

    try {
        // Start transaction
        $conn->begin_transaction();

        // Validate required fields
        $required_fields = ['content_type', 'content_id', 'reason'];
        foreach ($required_fields as $field) {
            if (!isset($_POST[$field]) || empty($_POST[$field])) {
                throw new Exception('Missing required information.');
            }
        }

        $reporter_id = $_SESSION['user_id'];
        $content_type = $_POST['content_type'];
        $content_id = $_POST['content_id'];
        $reason = $_POST['reason'];
        $description = $_POST['description'] ?? '';

        // Validate content type
        if (!in_array($content_type, ['post', 'comment', 'user'])) {
            throw new Exception('Invalid content type.');
        }

        // Check if report already exists
        $stmt = $conn->prepare("SELECT id FROM reported_content WHERE reporter_id = ? AND content_type = ? AND content_id = ? AND status != 'dismissed'");
        $stmt->bind_param("isi", $reporter_id, $content_type, $content_id);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            throw new Exception('You have already reported this content.');
        }

        // Insert the report
        $stmt = $conn->prepare("INSERT INTO reported_content (reporter_id, content_type, content_id, reason, description, status, created_at) VALUES (?, ?, ?, ?, ?, 'pending', NOW())");
        $stmt->bind_param("isiss", $reporter_id, $content_type, $content_id, $reason, $description);

        if (!$stmt->execute()) {
            throw new Exception('Failed to submit report. Please try again.');
        }

        $report_id = $stmt->insert_id;

        // Create notification for admins
        $stmt = $conn->prepare("INSERT INTO admin_notifications (type, content_id, user_id, message, created_at) VALUES ('report', ?, ?, ?, NOW())");
        $message = "New " . $content_type . " report submitted";
        $stmt->bind_param("iis", $report_id, $reporter_id, $message);
        
        if (!$stmt->execute()) {
            throw new Exception('Failed to create admin notification.');
        }

        // Commit transaction
        $conn->commit();

        echo json_encode([
            'success' => true, 
            'message' => 'Report submitted successfully. Our team will review it shortly.'
        ]);

    } catch (Exception $e) {
        // Rollback transaction on error
        $conn->rollback();
        echo json_encode([
            'success' => false, 
            'message' => $e->getMessage()
        ]);
    }
} else {
    echo json_encode([
        'success' => false, 
        'message' => 'Invalid request method.'
    ]);
}
?> 