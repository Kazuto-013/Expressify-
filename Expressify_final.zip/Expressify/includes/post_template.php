<?php
function renderPost($post, $currentUserId) {
    $isOwnPost = $post['user_id'] == $currentUserId;
    ?>
    <div class="post-card" data-post-id="<?php echo $post['id']; ?>">
        <div class="post-header">
            <div class="post-user-info">
                <img src="<?php echo !empty($post['profile_picture']) ? $post['profile_picture'] : 'assets/images/default_avatar.png'; ?>" 
                     alt="<?php echo htmlspecialchars($post['username']); ?>" 
                     class="post-avatar">
                <div class="post-user-details">
                    <a href="profile.php?id=<?php echo $post['user_id']; ?>" class="post-username">
                        <?php echo htmlspecialchars($post['username']); ?>
                    </a>
                    <span class="post-date"><?php echo date('M j, Y g:i A', strtotime($post['created_at'])); ?></span>
                </div>
            </div>
            <div class="post-actions">
                <?php if (!$isOwnPost): ?>
                    <button onclick="submitReport('post', <?php echo $post['id']; ?>, <?php echo $post['user_id']; ?>)" 
                            class="btn-report" title="Report Post">
                        <i class="fas fa-flag"></i>
                    </button>
                <?php endif; ?>
                <?php if ($isOwnPost): ?>
                    <button class="btn-delete" onclick="deletePost(<?php echo $post['id']; ?>)">
                        <i class="fas fa-trash"></i>
                    </button>
                <?php endif; ?>
            </div>
        </div>
        <div class="post-content">
            <?php echo nl2br(htmlspecialchars($post['content'])); ?>
            <?php if (!empty($post['image'])): ?>
                <img src="<?php echo htmlspecialchars($post['image']); ?>" alt="Post image" class="post-image">
            <?php endif; ?>
        </div>
        <div class="post-footer">
            <div class="post-stats">
                <button class="btn-like <?php echo $post['liked'] ? 'liked' : ''; ?>" 
                        onclick="toggleLike(<?php echo $post['id']; ?>)">
                    <i class="fas fa-heart"></i>
                    <span class="like-count"><?php echo $post['likes_count']; ?></span>
                </button>
                <button class="btn-comment" onclick="focusComment(<?php echo $post['id']; ?>)">
                    <i class="fas fa-comment"></i>
                    <span class="comment-count"><?php echo $post['comments_count']; ?></span>
                </button>
            </div>
        </div>
        <div class="comments-section" id="comments-<?php echo $post['id']; ?>">
            <!-- Comments will be loaded here -->
        </div>
    </div>
    <?php
}
?> 