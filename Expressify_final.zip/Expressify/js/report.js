/**
 * Report functionality for Expressify
 * This file handles the UI interactions for reporting content
 */

// Report form modal
const reportModal = document.createElement('div');
reportModal.id = 'reportModal';
reportModal.className = 'modal-overlay';
reportModal.innerHTML = `
    <div class="report-modal">
        <div class="report-modal-header">
            <h3>Report Content</h3>
            <button class="close-modal"><i class="fas fa-times"></i></button>
        </div>
        <div class="report-modal-body">
            <form id="reportForm">
                <input type="hidden" id="reportContentType" name="content_type" value="">
                <input type="hidden" id="reportContentId" name="content_id" value="">
                
                <div class="form-group">
                    <label for="reportReason">Why are you reporting this content?</label>
                    <select id="reportReason" name="reason" required>
                        <option value="">Select a reason</option>
                        <option value="Spam">Spam</option>
                        <option value="Harassment">Harassment</option>
                        <option value="Violence">Violence</option>
                        <option value="Nudity">Nudity</option>
                        <option value="Hate Speech">Hate Speech</option>
                        <option value="False Information">False Information</option>
                        <option value="Intellectual Property">Intellectual Property</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="reportDescription">Please provide additional details:</label>
                    <textarea id="reportDescription" name="description" rows="4" required></textarea>
                </div>
                
                <div class="form-actions">
                    <button type="button" id="cancelReport" class="btn btn-secondary">Cancel</button>
                    <button type="submit" class="btn btn-primary">Submit Report</button>
                </div>
            </form>
        </div>
    </div>
`;
document.body.appendChild(reportModal);

// Add CSS for the report modal
const reportStyles = document.createElement('style');
reportStyles.innerHTML = `
    .modal-overlay {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: rgba(0, 0, 0, 0.7);
        z-index: 1000;
        align-items: center;
        justify-content: center;
    }
    
    .report-modal {
        background-color: #fff;
        color: #333;
        width: 90%;
        max-width: 500px;
        border-radius: 8px;
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.2);
        overflow: hidden;
    }
    
    .report-modal-header {
        padding: 15px 20px;
        border-bottom: 1px solid #e3e3e3;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .report-modal-header h3 {
        margin: 0;
        font-size: 18px;
    }
    
    .close-modal {
        border: none;
        background: transparent;
        font-size: 18px;
        cursor: pointer;
    }
    
    .report-modal-body {
        padding: 20px;
    }
    
    .form-group {
        margin-bottom: 20px;
    }
    
    .form-group label {
        display: block;
        margin-bottom: 5px;
        font-weight: 500;
    }
    
    .form-group select,
    .form-group textarea {
        width: 100%;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 14px;
    }
    
    .form-actions {
        display: flex;
        justify-content: flex-end;
        gap: 10px;
        margin-top: 20px;
    }
    
    .btn {
        padding: 8px 16px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 14px;
        font-weight: 500;
    }
    
    .btn-primary {
        background-color: #1da1f2;
        color: white;
    }
    
    .btn-secondary {
        background-color: #e3e3e3;
        color: #333;
    }
    
    .report-notification {
        padding: 15px 20px;
        background-color: rgba(29, 161, 242, 0.1);
        border-left: 4px solid #1da1f2;
        margin-bottom: 20px;
        border-radius: 4px;
    }
    
    .report-error {
        background-color: rgba(224, 36, 94, 0.1);
        border-left-color: #e0245e;
    }
    
    .report-success {
        background-color: rgba(23, 191, 99, 0.1);
        border-left-color: #17bf63;
    }
`;
document.head.appendChild(reportStyles);

// Initialize report functionality
document.addEventListener('DOMContentLoaded', function() {
    // Report button click handlers
    document.addEventListener('click', function(e) {
        // Check if clicked element is a report button
        if (e.target.closest('.report-btn')) {
            const reportBtn = e.target.closest('.report-btn');
            const contentType = reportBtn.dataset.contentType;
            const contentId = reportBtn.dataset.contentId;
            
            // Show the report modal
            showReportModal(contentType, contentId);
        }
    });
    
    // Close modal when clicking the close button or cancel
    document.querySelector('#reportModal .close-modal').addEventListener('click', function() {
        hideReportModal();
    });
    
    document.getElementById('cancelReport').addEventListener('click', function() {
        hideReportModal();
    });
    
    // Handle report form submission
    document.getElementById('reportForm').addEventListener('submit', function(e) {
        e.preventDefault();
        submitReport();
    });
});

/**
 * Show the report modal
 * @param {string} contentType - Type of content (post, comment, user)
 * @param {number} contentId - ID of the content
 */
function showReportModal(contentType, contentId) {
    // Set the form values
    document.getElementById('reportContentType').value = contentType;
    document.getElementById('reportContentId').value = contentId;
    
    // Clear previous inputs
    document.getElementById('reportReason').value = '';
    document.getElementById('reportDescription').value = '';
    
    // Show the modal
    reportModal.style.display = 'flex';
}

/**
 * Hide the report modal
 */
function hideReportModal() {
    reportModal.style.display = 'none';
}

/**
 * Submit the report
 */
function submitReport() {
    const form = document.getElementById('reportForm');
    const formData = new FormData(form);
    formData.append('action', 'submit');
    
    // Show loading state
    const submitBtn = form.querySelector('button[type="submit"]');
    const originalBtnText = submitBtn.innerHTML;
    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';
    submitBtn.disabled = true;
    
    // Create a notification area if it doesn't exist
    let notificationArea = document.querySelector('.report-notification');
    if (!notificationArea) {
        notificationArea = document.createElement('div');
        notificationArea.className = 'report-notification';
        form.prepend(notificationArea);
    }
    
    fetch('Admin Features/report_api.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        // Reset button state
        submitBtn.innerHTML = originalBtnText;
        submitBtn.disabled = false;
        
        if (data.status === 'success') {
            // Show success message
            notificationArea.className = 'report-notification report-success';
            notificationArea.innerHTML = `<p>${data.message}</p>`;
            
            // Clear form and close modal after a delay
            setTimeout(() => {
                hideReportModal();
            }, 2000);
        } else {
            // Show error message
            notificationArea.className = 'report-notification report-error';
            notificationArea.innerHTML = `<p>${data.message}</p>`;
        }
    })
    .catch(error => {
        // Reset button state
        submitBtn.innerHTML = originalBtnText;
        submitBtn.disabled = false;
        
        // Show error message
        notificationArea.className = 'report-notification report-error';
        notificationArea.innerHTML = '<p>An error occurred while submitting your report. Please try again.</p>';
        
        console.error('Error submitting report:', error);
    });
}

/**
 * Check if the user has already reported content
 * @param {string} contentType - Type of content
 * @param {number} contentId - ID of the content
 * @param {function} callback - Callback function with result
 */
function checkIfReported(contentType, contentId, callback) {
    const formData = new FormData();
    formData.append('action', 'check');
    formData.append('content_type', contentType);
    formData.append('content_id', contentId);
    
    fetch('Admin Features/report_api.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            callback(data.has_reported, data.report_status || null);
        } else {
            callback(false, null);
        }
    })
    .catch(error => {
        console.error('Error checking report status:', error);
        callback(false, null);
    });
}

/**
 * Add report button to post or comment
 * @param {HTMLElement} container - Container to add the button to
 * @param {string} contentType - Type of content (post, comment, user)
 * @param {number} contentId - ID of the content
 */
function addReportButton(container, contentType, contentId) {
    // First, check if already reported
    checkIfReported(contentType, contentId, function(hasReported, status) {
        // Create button element
        const reportBtn = document.createElement('a');
        reportBtn.href = 'javascript:void(0);';
        reportBtn.className = 'report-btn';
        reportBtn.dataset.contentType = contentType;
        reportBtn.dataset.contentId = contentId;
        
        if (hasReported) {
            // User has already reported this content
            reportBtn.innerHTML = '<i class="fas fa-flag"></i> Reported';
            reportBtn.className += ' reported';
            reportBtn.title = 'You have reported this content';
            reportBtn.disabled = true;
        } else {
            // User has not reported this content
            reportBtn.innerHTML = '<i class="far fa-flag"></i> Report';
            reportBtn.title = 'Report this content';
        }
        
        // Add to container
        container.appendChild(reportBtn);
    });
} 