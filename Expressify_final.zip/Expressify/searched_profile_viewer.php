<?php
// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require 'session.php';
require 'config.php';
require 'theme.php';

// Check if a username or user ID is provided
if (!isset($_GET['username']) && !isset($_GET['user_id'])) {
    header('Location: explore.php');
    exit;
}

$current_user_id = $_SESSION['user_id'];

// Get the profile user id 
if (isset($_GET['user_id'])) {
    $profile_user_id = $_GET['user_id'];
    
    // Verify user exists
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->bind_param("i", $profile_user_id);
} else {
    $username = $_GET['username'];
    
    // Get user by username
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
}

$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header('Location: explore.php');
    exit;
}

$profile_user = $result->fetch_assoc();
$profile_user_id = $profile_user['id'];

// Get unread notifications count for the current user
$stmt = $conn->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0");
$stmt->bind_param("i", $current_user_id);
$stmt->execute();
$unread_count = $stmt->get_result()->fetch_assoc()['count'];

// Check if friend request table exists
$result = $conn->query("SHOW TABLES LIKE 'friend_requests'");
$friend_requests_table_exists = ($result->num_rows > 0);

// Determine the friendship status if friend_requests table exists
$friendship_status = 'none';
if ($friend_requests_table_exists) {
    $stmt = $conn->prepare("
        SELECT status, sender_id 
        FROM friend_requests 
        WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)
    ");
    $stmt->bind_param("iiii", $current_user_id, $profile_user_id, $profile_user_id, $current_user_id);
    $stmt->execute();
    $friend_result = $stmt->get_result();
    
    if ($friend_result->num_rows > 0) {
        $friend_data = $friend_result->fetch_assoc();
        
        if ($friend_data['status'] === 'pending') {
            $friendship_status = ($friend_data['sender_id'] == $current_user_id) 
                ? 'pending_sent' 
                : 'pending_received';
        } elseif ($friend_data['status'] === 'accepted') {
            $friendship_status = 'accepted';
        }
    }
}

// Get posts with media, like counts and comment counts
$query = "
    SELECT 
        posts.*,
        users.username,
        users.profile_picture,
        media.file_path,
        media.file_type,
        COUNT(DISTINCT likes.id) as like_count,
        COUNT(DISTINCT comments.id) as comment_count,
        MAX(CASE WHEN likes.user_id = ? THEN 1 ELSE 0 END) as user_liked
    FROM posts 
    JOIN users ON posts.user_id = users.id
    LEFT JOIN media ON posts.media_id = media.id
    LEFT JOIN likes ON posts.id = likes.post_id
    LEFT JOIN comments ON posts.id = comments.post_id
    WHERE posts.user_id = ?
    GROUP BY posts.id
    ORDER BY posts.created_at DESC
";

$stmt = $conn->prepare($query);
$stmt->bind_param("ii", $current_user_id, $profile_user_id);
$stmt->execute();
$posts_result = $stmt->get_result();

// Get friend count
$friendCountQuery = "SELECT COUNT(*) as friend_count 
                    FROM friend_requests 
                    WHERE status = 'accepted' AND (sender_id = ? OR receiver_id = ?)";
$friendStmt = $conn->prepare($friendCountQuery);
$friendStmt->bind_param("ii", $profile_user_id, $profile_user_id);
$friendStmt->execute();
$friendResult = $friendStmt->get_result();
$friendCount = $friendResult->fetch_assoc()['friend_count'];

// Get mutual friends count
$mutualQuery = "SELECT COUNT(*) as mutual_count
               FROM (
                   SELECT IF(sender_id = ?, receiver_id, sender_id) as friend_id
                   FROM friend_requests
                   WHERE status = 'accepted' AND (sender_id = ? OR receiver_id = ?)
               ) AS my_friends
               JOIN (
                   SELECT IF(sender_id = ?, receiver_id, sender_id) as friend_id
                   FROM friend_requests
                   WHERE status = 'accepted' AND (sender_id = ? OR receiver_id = ?)
               ) AS their_friends
               ON my_friends.friend_id = their_friends.friend_id";
$mutualStmt = $conn->prepare($mutualQuery);
$mutualStmt->bind_param("iiiiii", 
    $current_user_id, $current_user_id, $current_user_id,
    $profile_user_id, $profile_user_id, $profile_user_id
);
$mutualStmt->execute();
$mutualResult = $mutualStmt->get_result();
$mutualFriendsCount = $mutualResult->fetch_assoc()['mutual_count'];

// Get posts count
$stmt = $conn->prepare("SELECT COUNT(*) as count FROM posts WHERE user_id = ?");
$stmt->bind_param("i", $profile_user_id);
$stmt->execute();
$posts_count = $stmt->get_result()->fetch_assoc()['count'];

// Get theme preference
$theme = $_SESSION['theme'] ?? 'light';
?>
<!DOCTYPE html>
<html data-theme="<?php echo htmlspecialchars($theme); ?>">
<head>
    <title><?php echo htmlspecialchars($profile_user['username']); ?> - Expressify</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
    /* Profile Header Layout */
    .profile-header {
        display: grid;
        grid-template-columns: minmax(200px, 300px) 1fr;
        gap: 30px;
        margin-bottom: 30px;
        padding: 20px;
        background: var(--bg-secondary);
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

    .profile-left {
        display: flex;
        flex-direction: column;
        gap: 20px;
    }

    .profile-picture-container {
        width: 100%;
    }

    .profile-picture {
        position: relative;
        width: 100%;
        padding-bottom: 100%;
        border-radius: 8px;
        overflow: hidden;
    }

    .profile-picture img {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: cover;
        border-radius: 8px;
    }

    .profile-stats {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(100px, 1fr));
        gap: 10px;
        padding: 15px;
        background: var(--bg-primary);
        border-radius: 8px;
    }

    .stat {
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
        gap: 5px;
    }

    .stat i {
        font-size: 1.2em;
        color: var(--primary-color);
    }

    .profile-right {
        display: flex;
        flex-direction: column;
        gap: 20px;
    }

    .profile-details {
        height: 100%;
        padding: 20px;
        background: var(--bg-primary);
        border-radius: 8px;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }

    .profile-details h3 {
        color: var(--text-primary);
        margin-bottom: 20px;
        display: flex;
        align-items: center;
        gap: 10px;
        font-size: 1.5em;
    }

    .verified-badge {
        color: #3897f0;
        margin-left: 5px;
        font-size: 0.8em;
    }

    .details-content {
        display: flex;
        flex-direction: column;
        gap: 15px;
    }

    .detail-item {
        background: var(--bg-secondary);
        padding: 15px;
        border-radius: 8px;
        transition: transform 0.2s;
    }

    .detail-item:hover {
        transform: translateX(5px);
    }

    .detail-label {
        color: var(--text-secondary);
        font-size: 0.9em;
        display: flex;
        align-items: center;
        gap: 8px;
    }

    .detail-value {
        font-size: 1.1em;
        padding: 5px 0;
        color: var(--text-primary);
    }

    .bio-text {
        white-space: pre-line;
        line-height: 1.4;
        min-height: 60px;
    }

    .bio-text em {
        color: var(--text-secondary);
    }

    .bio-item {
        flex-grow: 1;
    }

    .website-link {
        color: var(--primary-color);
        text-decoration: none;
    }

    .website-link:hover {
        text-decoration: underline;
    }

    /* Friend Request Buttons */
    .friend-request-actions {
        display: flex;
        flex-direction: column;
        gap: 10px;
        width: 100%;
    }

    .friend-action-btn, .message-btn {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        padding: 10px 15px;
        border: none;
        border-radius: 8px;
        font-size: 14px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.2s ease;
        width: 100%;
    }

    .friend-action-btn {
        background-color: var(--primary-color);
        color: white;
    }

    .friend-action-btn:hover {
        background-color: var(--primary-color-dark);
    }

    .friend-action-btn.cancel-request,
    .friend-action-btn.reject-request,
    .friend-action-btn.unfriend {
        background-color: #e74c3c;
    }

    .friend-action-btn.cancel-request:hover,
    .friend-action-btn.reject-request:hover,
    .friend-action-btn.unfriend:hover {
        background-color: #c0392b;
    }

    .friend-request-options {
        display: flex;
        gap: 10px;
        width: 100%;
    }

    .friend-request-options .friend-action-btn {
        flex: 1;
    }

    .friend-request-options .accept-request {
        background-color: #2ecc71;
    }

    .friend-request-options .accept-request:hover {
        background-color: #27ae60;
    }

    .message-btn {
        background-color: var(--bg-primary);
        color: var(--text-primary);
        border: 1px solid var(--border-color);
    }

    .message-btn:hover {
        background-color: var(--bg-secondary);
    }

    /* Posts Section */
    .user-posts {
        margin-top: 30px;
    }

    .user-posts h3 {
        display: flex;
        align-items: center;
        gap: 10px;
        margin-bottom: 20px;
        color: var(--text-primary);
        font-size: 1.3em;
    }

    .posts-grid {
        display: grid;
        gap: 20px;
    }

    .post {
        background: var(--bg-secondary);
        border-radius: 8px;
        padding: 15px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        transition: transform 0.2s ease;
        cursor: pointer;
    }

    .post:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
    }

    .post-header {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-bottom: 15px;
    }

    .post-user {
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .post-avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        object-fit: cover;
    }

    .post-info {
        display: flex;
        flex-direction: column;
    }

    .username {
        color: var(--text-primary);
        font-weight: 500;
        margin-bottom: 2px;
    }

    .post-date {
        color: var(--text-secondary);
        font-size: 0.8em;
    }

    /* Add to existing styles */
    .report-btn {
        background: none;
        border: none;
        color: var(--text-secondary);
        cursor: pointer;
        padding: 8px 16px;
        font-size: 0.9em;
        transition: all 0.3s ease;
        opacity: 0.7;
        border-radius: 20px;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .report-btn:hover {
        color: var(--danger-color);
        background: rgba(var(--danger-color-rgb), 0.1);
        opacity: 1;
    }

    .profile-actions {
        display: flex;
        gap: 1rem;
        margin-top: 1rem;
    }

    /* Style for report confirmation modal */
    .report-modal {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.5);
        z-index: 1000;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .report-modal-content {
        background: var(--card-bg);
        padding: 2rem;
        border-radius: 12px;
        width: 90%;
        max-width: 500px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    </style>
</head>
<body>
<div class="container">
    <nav class="navbar">
        <div class="nav-brand">
            <h2>Expressify</h2>
        </div>
        <div class="nav-links">
            <a href="home.php" class="nav-item"><i class="fas fa-home"></i> Home</a>
            <a href="posts.php" class="nav-item"><i class="fas fa-pen"></i> Create Post</a>
            <a href="explore.php" class="nav-item active"><i class="fas fa-compass"></i> Explore</a>
            <div class="nav-item notifications-dropdown">
                <button class="notifications-btn">
                    <i class="fas fa-bell"></i> Notifications
                    <?php if ($unread_count > 0): ?>
                        <span class="notification-badge"><?php echo $unread_count; ?></span>
                    <?php endif; ?>
                </button>
                <div class="notifications-menu">
                    <div class="notifications-header">
                        <h3>Notifications</h3>
                        <button class="mark-all-read">Mark all as read</button>
                    </div>
                    <div class="notifications-list">
                        <!-- Notifications will be loaded here -->
                    </div>
                    <div class="notifications-footer">
                        <a href="notifications.php" class="view-all">View All Notifications</a>
                    </div>
                </div>
            </div>
            <a href="profile.php" class="nav-item"><i class="fas fa-user"></i> My Profile</a>
            <a href="friends.php" class="nav-item"><i class="fas fa-users"></i> Friends</a>
            <a href="settings.php" class="nav-item"><i class="fas fa-cog"></i> Settings</a>
            <a href="logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
        <div class="nav-toggle">
            <i class="fas fa-bars"></i>
        </div>
    </nav>

    <div class="content">
        <div class="profile-container">
            <div class="profile-header">
                <div class="profile-left">
                    <div class="profile-picture-container">
                        <div class="profile-picture">
                            <img src="<?php echo !empty($profile_user['profile_picture']) ? htmlspecialchars($profile_user['profile_picture']) : 'assets/default-avatar.png'; ?>" 
                                 alt="Profile Picture">
                        </div>
                    </div>
                    
                    <div class="profile-stats">
                        <div class="stat-item">
                            <span class="stat-value"><?php echo $posts_count; ?></span>
                            <span class="stat-label">Posts</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-value"><?php echo $friendCount; ?></span>
                            <span class="stat-label">Friends</span>
                        </div>
                        <div class="stat-item">
                            <span class="stat-value"><?php echo $mutualFriendsCount; ?></span>
                            <span class="stat-label">Mutual Friends</span>
                        </div>
                    </div>
                    
                    <!-- Friend request buttons -->
                    <div class="friend-request-actions">
                        <?php if ($profile_user_id != $current_user_id): ?>
                            <?php if ($friendship_status === 'none'): ?>
                                <button class="friend-action-btn add-friend" data-user-id="<?php echo $profile_user_id; ?>">
                                    <i class="fas fa-user-plus"></i> Add Friend
                                </button>
                            <?php elseif ($friendship_status === 'pending_sent'): ?>
                                <button class="friend-action-btn cancel-request" data-user-id="<?php echo $profile_user_id; ?>">
                                    <i class="fas fa-user-times"></i> Cancel Request
                                </button>
                            <?php elseif ($friendship_status === 'pending_received'): ?>
                                <div class="friend-request-options">
                                    <button class="friend-action-btn accept-request" data-user-id="<?php echo $profile_user_id; ?>">
                                        <i class="fas fa-check"></i> Accept
                                    </button>
                                    <button class="friend-action-btn reject-request" data-user-id="<?php echo $profile_user_id; ?>">
                                        <i class="fas fa-times"></i> Reject
                                    </button>
                                </div>
                            <?php elseif ($friendship_status === 'accepted'): ?>
                                <button class="friend-action-btn unfriend" data-user-id="<?php echo $profile_user_id; ?>">
                                    <i class="fas fa-user-minus"></i> Unfriend
                                </button>
                                
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="profile-right">
                    <div class="profile-details">
                        <h3>
                            <i class="fas fa-user-circle"></i> 
                            <?php echo htmlspecialchars($profile_user['username']); ?>
                            <?php if (isset($profile_user['verified']) && $profile_user['verified']): ?>
                                <span class="verified-badge" title="Verified User"><i class="fas fa-check-circle"></i></span>
                            <?php endif; ?>
                        </h3>
                        
                        <div class="details-content">
                            <?php if (!empty($profile_user['location'])): ?>
                                <div class="detail-item">
                                    <span class="detail-label"><i class="fas fa-map-marker-alt"></i> Location</span>
                                    <span class="detail-value"><?php echo htmlspecialchars($profile_user['location']); ?></span>
                                </div>
                            <?php endif; ?>
                            
                            <?php if (!empty($profile_user['website'])): ?>
                                <div class="detail-item">
                                    <span class="detail-label"><i class="fas fa-link"></i> Website</span>
                                    <a href="<?php echo htmlspecialchars($profile_user['website']); ?>" class="detail-value website-link" target="_blank" rel="noopener noreferrer">
                                        <?php echo htmlspecialchars($profile_user['website']); ?>
                                    </a>
                                </div>
                            <?php endif; ?>
                            
                            <div class="detail-item">
                                <span class="detail-label"><i class="fas fa-calendar-alt"></i> Joined</span>
                                <span class="detail-value">
                                    <?php echo date('F Y', strtotime($profile_user['created_at'] ?? 'now')); ?>
                                </span>
                            </div>
                            
                            <div class="detail-item bio-item">
                                <span class="detail-label"><i class="fas fa-info-circle"></i> Bio</span>
                                <div class="detail-value bio-text">
                                    <?php echo !empty($profile_user['bio']) ? nl2br(htmlspecialchars($profile_user['bio'])) : '<em>No bio added yet</em>'; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php if ($profile_user['id'] !== $_SESSION['user_id']): ?>
                <div class="profile-actions">
                    <button class="report-btn" onclick="reportContent('profile', <?php echo $profile_user['id']; ?>, <?php echo $profile_user['id']; ?>)">
                        <i class="fas fa-flag"></i> Report Profile
                    </button>
                </div>
                <?php endif; ?>
            </div>

            <div class="user-posts">
                <h3><i class="fas fa-pencil-alt"></i> <?php echo htmlspecialchars($profile_user['username']); ?>'s Posts</h3>
                <div class="posts-grid">
                    <?php if ($posts_result->num_rows > 0): ?>
                        <?php while ($post = $posts_result->fetch_assoc()): ?>
                            <div class="post" data-post-id="<?php echo $post['id']; ?>">
                                <div class="post-header">
                                    <div class="post-user">
                                        <img src="<?php echo !empty($post['profile_picture']) ? htmlspecialchars($post['profile_picture']) : 'assets/default-avatar.png'; ?>" 
                                             alt="Profile Picture" class="post-avatar">
                                        <div class="post-info">
                                            <span class="username"><?php echo htmlspecialchars($post['username']); ?></span>
                                            <span class="post-date"><?php echo date('M d, Y', strtotime($post['created_at'])); ?></span>
                                        </div>
                                    </div>
                                </div>

                                <div class="post-content">
                                    <p><?php echo nl2br(htmlspecialchars($post['content'])); ?></p>
                                    <?php if (!empty($post['file_path'])): ?>
                                        <div class="post-media">
                                            <?php if (strpos($post['file_type'], 'image/') !== false || in_array($post['file_type'], ['jpg', 'jpeg', 'png', 'gif'])): ?>
                                                <img src="<?php echo htmlspecialchars($post['file_path']); ?>" alt="Post image" class="post-image">
                                            <?php elseif (strpos($post['file_type'], 'video/') !== false || in_array($post['file_type'], ['mp4', 'mov'])): ?>
                                                <video controls class="post-video">
                                                    <source src="<?php echo htmlspecialchars($post['file_path']); ?>" type="video/<?php echo $post['file_type']; ?>">
                                                    Your browser does not support the video tag.
                                                </video>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <div class="post-actions">
                                    <button class="action-btn like-btn <?php echo $post['user_liked'] ? 'liked' : ''; ?>" 
                                            data-post-id="<?php echo $post['id']; ?>"
                                            data-liked="<?php echo $post['user_liked']; ?>">
                                        <i class="<?php echo $post['user_liked'] ? 'fas' : 'far'; ?> fa-heart"></i>
                                        <span class="like-count"><?php echo $post['like_count']; ?></span>
                                    </button>
                                    <button class="action-btn comment-btn" data-post-id="<?php echo $post['id']; ?>">
                                        <i class="far fa-comment"></i>
                                        <span class="comment-count"><?php echo $post['comment_count']; ?></span>
                                    </button>
                                    <?php if (isset($_SESSION['user_id'])): ?>
                                        <button class="action-btn save-btn" data-post-id="<?php echo $post['id']; ?>">
                                            <i class="far fa-bookmark"></i>
                                        </button>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="comments-section" id="comments-<?php echo $post['id']; ?>" style="display: none;">
                                    <form class="comment-form" data-post-id="<?php echo $post['id']; ?>">
                                        <input type="text" class="comment-input" placeholder="Write a comment...">
                                        <button type="submit" class="comment-submit">Post</button>
                                    </form>
                                    <div class="comments-list" id="comments-list-<?php echo $post['id']; ?>">
                                        <!-- Comments will be loaded here -->
                                         
                                    </div>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="no-posts">
                            <i class="fas fa-pencil-alt"></i>
                            <p>No posts yet</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="script.js"></script>
<script>
    // Make posts clickable to redirect to home.php with post_id
    document.querySelectorAll('.post').forEach(post => {
        post.addEventListener('click', function(e) {
            // Don't redirect if clicked on action buttons, links, or form elements
            if (
                e.target.closest('.action-btn') || 
                e.target.closest('a') || 
                e.target.closest('input') || 
                e.target.closest('button') ||
                e.target.closest('.comment-form') ||
                e.target.closest('.comments-section')
            ) {
                return;
            }
            
            const postId = this.getAttribute('data-post-id');
            window.location.href = `home.php?post_id=${postId}`;
        });
        
        // Add visual cue for clickable posts
        post.style.cursor = 'pointer';
    });
    
    // Notifications functionality
    document.addEventListener('DOMContentLoaded', function() {
        const notificationsBtn = document.querySelector('.notifications-btn');
        const notificationsMenu = document.querySelector('.notifications-menu');
        
        if (notificationsBtn) {
            notificationsBtn.addEventListener('click', function(e) {
                e.preventDefault();
                notificationsMenu.classList.toggle('show');
                if (notificationsMenu.classList.contains('show')) {
                    loadNotifications();
                }
            });
            
            // Close notifications menu when clicking outside
            document.addEventListener('click', function(e) {
                if (!e.target.closest('.notifications-dropdown')) {
                    notificationsMenu.classList.remove('show');
                }
            });
        }
        
        // Load notifications
        async function loadNotifications() {
            const notificationsList = document.querySelector('.notifications-list');
            
            try {
                notificationsList.innerHTML = '<div class="loading">Loading notifications...</div>';
                
                const response = await fetch('api/notifications.php');
                if (!response.ok) {
                    throw new Error(`Server responded with ${response.status}: ${response.statusText}`);
                }
                
                const data = await response.json();
                
                // If there's a message about the notifications table not found, show a friendly message
                if (data.message === 'Notifications table not found') {
                    notificationsList.innerHTML = `
                        <div class="notification-setup-needed">
                            <p>Notifications need to be set up</p>
                            <a href="notifications.php" class="btn btn-sm">Set Up Notifications</a>
                        </div>
                    `;
                    return;
                }
                
                if (data.success === false) {
                    throw new Error(data.error || 'Failed to load notifications');
                }
                
                if (data.notifications && data.notifications.length > 0) {
                    notificationsList.innerHTML = data.notifications.map(notification => `
                        <div class="notification-item ${notification.is_read ? '' : 'unread'}" 
                             data-notification-id="${notification.id}">
                            <img src="${notification.profile_picture || 'assets/default-avatar.png'}" 
                                 alt="Profile picture" class="notification-avatar">
                            <div class="notification-content">
                                <p>${notification.content || `${notification.username} interacted with your profile`}</p>
                                <small>${timeAgo(new Date(notification.created_at))}</small>
                            </div>
                            ${!notification.is_read ? '<div class="notification-status"></div>' : ''}
                        </div>
                    `).join('');
                } else {
                    notificationsList.innerHTML = '<div class="no-notifications">No notifications</div>';
                }
            } catch (error) {
                console.error('Error loading notifications:', error);
                notificationsList.innerHTML = `
                    <div class="error">
                        <p>Failed to load notifications: ${error.message}</p>
                        <a href="notifications.php" class="btn btn-sm">Set Up Notifications</a>
                    </div>
                `;
            }
        }
        
        // Mark all notifications as read
        const markAllReadBtn = document.querySelector('.mark-all-read');
        if (markAllReadBtn) {
            markAllReadBtn.addEventListener('click', async function() {
                try {
                    const response = await fetch('api/notifications.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: 'action=mark_all_read'
                    });
                    
                    if (response.ok) {
                        document.querySelectorAll('.notification-item').forEach(item => {
                            item.classList.remove('unread');
                            item.querySelector('.notification-status')?.remove();
                        });
                        document.querySelector('.notification-badge')?.remove();
                    }
                } catch (error) {
                    console.error('Error marking notifications as read:', error);
                }
            });
        }
        
        // Helper function for time ago format
        function timeAgo(timestamp) {
            const seconds = Math.floor((new Date() - timestamp) / 1000);
            
            let interval = Math.floor(seconds / 31536000);
            if (interval > 1) return interval + ' years ago';
            
            interval = Math.floor(seconds / 2592000);
            if (interval > 1) return interval + ' months ago';
            
            interval = Math.floor(seconds / 86400);
            if (interval > 1) return interval + ' days ago';
            
            interval = Math.floor(seconds / 3600);
            if (interval > 1) return interval + ' hours ago';
            
            interval = Math.floor(seconds / 60);
            if (interval > 1) return interval + ' minutes ago';
            
            return 'just now';
        }
    });

    function reportContent(contentType, contentId, reportedId) {
        const reason = prompt('Please provide a reason for reporting this profile:');
        if (!reason) return;

        fetch('includes/report_handler.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `content_type=${contentType}&content_id=${contentId}&reported_id=${reportedId}&reason=${encodeURIComponent(reason)}`
        })
        .then(response => response.json())
        .then(data => {
            alert(data.message);
            if (data.success) {
                // Optionally refresh the page or update UI
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while submitting the report.');
        });
    }
</script>
</body>
</html>
