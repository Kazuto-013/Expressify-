<?php
require 'session.php';
require 'config.php';
require_once 'includes/content_moderation.php';
$user_id = $_SESSION['user_id'];

// Get unread notifications count
$stmt = $conn->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$unread_count = $stmt->get_result()->fetch_assoc()['count'];

// Get posts with media, like counts and check if user liked each post
$result = $conn->query("
    SELECT 
        posts.*,
        users.username,
        users.profile_picture,
        media.file_path,
        media.file_type,
        COUNT(DISTINCT likes.id) as like_count,
        COUNT(DISTINCT comments.id) as comment_count,
        MAX(CASE WHEN likes.user_id = $user_id THEN 1 ELSE 0 END) as user_liked
    FROM posts 
    JOIN users ON posts.user_id = users.id
    LEFT JOIN media ON posts.media_id = media.id
    LEFT JOIN likes ON posts.id = likes.post_id
    LEFT JOIN comments ON posts.id = comments.post_id
    GROUP BY posts.id
    ORDER BY posts.created_at DESC
");

$theme = $_SESSION['theme'] ?? 'light';
?>
<!DOCTYPE html>
<html data-theme="<?php echo htmlspecialchars($theme ?? 'light'); ?>">
<head>
    <title>Home - Expressify</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
<div class="container">
    <nav class="navbar">
        <div class="nav-brand">
            <h2>Expressify</h2>
        </div>
        <div class="nav-links">
            <a href="home.php" class="nav-item active"><i class="fas fa-home"></i> Home</a>
            <a href="posts.php" class="nav-item"><i class="fas fa-pen"></i> Create Post</a>
            <a href="explore.php" class="nav-item"><i class="fas fa-compass"></i> Explore</a>
            <a href="notifications.php" class="nav-item" style="position: relative;">
                    <i class="fas fa-bell"></i> Notifications
                    <?php if ($unread_count > 0): ?>
                        <span class="notification-badge"><?php echo $unread_count; ?></span>
                    <?php endif; ?>
            </a>
            <a href="profile.php" class="nav-item"><i class="fas fa-user"></i> My Profile</a>
            <a href="friends.php" class="nav-item"><i class="fas fa-users"></i> Friends</a>
            <a href="settings.php" class="nav-item"><i class="fas fa-cog"></i> Settings</a>
            <a href="logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
        <div class="nav-toggle">
            <i class="fas fa-bars"></i>
        </div>
    </nav>
    
    <div class="content">
        <h3>Recent Posts</h3>
        <?php while ($row = $result->fetch_assoc()) { ?>
            <div class="post" data-post-id="<?php echo $row['id']; ?>">
                <div class="post-header">
                    <div class="post-user">
                        <img src="<?php echo htmlspecialchars($row['profile_picture'] ?? 'assets/default-avatar.png'); ?>" 
                             alt="<?php echo htmlspecialchars($row['username'] ?? ''); ?>" class="post-avatar">
                        <div class="post-user-info">
                            <strong><?php echo htmlspecialchars($row['username'] ?? ''); ?></strong>
                            <span class="post-date"><?php echo date('M d, Y', strtotime($row['created_at'] ?? '')); ?></span>
                        </div>
                    </div>
                    <?php if ($row['user_id'] == $_SESSION['user_id']): ?>
                        <div class="post-actions-menu">
                            <button class="delete-post-btn" data-post-id="<?php echo $row['id']; ?>">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
                <p class="post-content"><?php echo htmlspecialchars($row['content'] ?? ''); ?></p>
                <?php if (!empty($row['file_path'])) : ?>
                    <div class="post-media">
                        <?php if (strpos($row['file_type'] ?? '', 'image/') !== false || in_array($row['file_type'] ?? '', ['jpg', 'jpeg', 'png', 'gif'])) : ?>
                            <img src="<?php echo htmlspecialchars($row['file_path'] ?? ''); ?>" alt="Post image" class="post-image">
                        <?php elseif (strpos($row['file_type'] ?? '', 'video/') !== false || in_array($row['file_type'] ?? '', ['mp4', 'mov'])) : ?>
                            <video controls class="post-video">
                                <source src="<?php echo htmlspecialchars($row['file_path'] ?? ''); ?>" type="video/<?php echo htmlspecialchars($row['file_type'] ?? ''); ?>">
                                Your browser does not support the video tag.
                            </video>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
                <div class="post-actions">
                    <button class="post-action like-btn <?php echo $row['user_liked'] ? 'liked' : ''; ?>" 
                            data-post-id="<?php echo $row['id']; ?>"
                            onclick="likePost(<?php echo $row['id']; ?>)">
                        <i class="<?php echo $row['user_liked'] ? 'fas' : 'far'; ?> fa-heart"></i>
                        <span class="like-count"><?php echo $row['like_count']; ?></span>
                    </button>
                    <button class="post-action comment-btn" onclick="toggleComments(<?php echo $row['id']; ?>)">
                        <i class="far fa-comment"></i>
                        <span class="comment-count"><?php echo $row['comment_count']; ?></span>
                    </button>
                    <?php if ($row['user_id'] !== $_SESSION['user_id']): ?>
                    <button class="report-btn" onclick="reportContent('post', <?php echo $row['id']; ?>, <?php echo $row['user_id']; ?>)">
                        <i class="fas fa-flag"></i>
                    </button>
                    <?php endif; ?>
                </div>
                <div class="comments-section" id="comments-<?php echo $row['id']; ?>" style="display: none;">
                    <div class="comments-container" id="comments-container-<?php echo $row['id']; ?>">
                        <!-- Comments will be loaded here -->
                    </div>
                    <form class="comment-form" onsubmit="event.preventDefault(); addComment(<?php echo $row['id']; ?>);">
                        <textarea class="comment-input" id="comment-input-<?php echo $row['id']; ?>" 
                                  placeholder="Write a comment..." rows="1"></textarea>
                        <button type="submit" class="comment-submit">
                            <i class="fas fa-paper-plane"></i>
                        </button>
                    </form>
                </div>
            </div>
        <?php } ?>
    </div>
</div>

<style>
.post {
    background-color: var(--bg-secondary);
    border-radius: 8px;
    margin-bottom: 20px;
    overflow: hidden;
}

.post-header {
    display: flex;
    align-items: center;
    padding: 12px 15px;
    border-bottom: 1px solid var(--border-color);
}

.post-user {
    display: flex;
    align-items: center;
    gap: 10px;
    flex: 1;
    text-decoration: none;
    color: var(--text-primary);
}

.post-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    object-fit: cover;
}

.post-user-info {
    display: flex;
    flex-direction: column;
}

.post-username {
    font-weight: 600;
    color: var(--text-primary);
}

.post-date {
    font-size: 0.85em;
    color: var(--text-secondary);
}

.post-content {
    padding: 15px;
    color: var(--text-primary);
    white-space: pre-wrap;
    word-break: break-word;
}

.post-media {
    width: 100%;
    max-height: 500px;
    display: flex;
    justify-content: center;
    align-items: center;
    overflow: hidden;
    background-color: var(--bg-dark);
}

.post-image {
    max-width: 100%;
    max-height: 500px;
    object-fit: contain;
}

.post-actions {
    display: flex;
    align-items: center;
    padding: 8px 15px;
    gap: 15px;
    border-top: 1px solid var(--border-color);
}

.post-action {
    background: none;
    border: none;
    color: var(--text-secondary);
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 6px 8px;
    border-radius: 4px;
    cursor: pointer;
    transition: all 0.2s ease;
}

.post-action:hover {
    background-color: var(--bg-hover);
}

.post-action.liked {
    color: #ff4b4b;
}

.post-action.liked:hover {
    background-color: rgba(255, 75, 75, 0.1);
}

/* Comment Section Styles */
.comments-section {
    background-color: var(--bg-secondary);
    border-top: 1px solid var(--border-color);
}

.comments-container {
    padding: 0;
}

.comment {
    display: flex;
    padding: 10px 15px;
    gap: 10px;
    border-bottom: 1px solid var(--border-color);
    background-color: var(--bg-dark);
}

.comment:last-child {
    border-bottom: none;
}

.comment-avatar {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    object-fit: cover;
}

.comment-content-wrapper {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 4px;
}

.comment-header {
    display: flex;
    align-items: center;
    gap: 8px;
}

.comment-username {
    font-weight: 600;
    color: var(--text-primary);
    text-decoration: none;
}

.comment-time {
    font-size: 0.85em;
    color: var(--text-secondary);
}

.comment-content {
    color: var(--text-primary);
    word-break: break-word;
    white-space: pre-wrap;
    line-height: 1.4;
}

.comment-form {
    display: flex;
    padding: 12px 15px;
    gap: 10px;
    background-color: var(--bg-secondary);
    border-top: 1px solid var(--border-color);
}

.comment-input {
    flex: 1;
    padding: 8px 15px;
    border: 1px solid var(--border-color);
    border-radius: 20px;
    background-color: var(--bg-dark);
    color: var(--text-primary);
    resize: none;
    min-height: 36px;
    transition: all 0.3s ease;
}

.comment-input:focus {
    outline: none;
    border-color: var(--primary-color);
}

.comment-submit {
    background-color: var(--primary-color);
    color: white;
    border: none;
    border-radius: 50%;
    width: 36px;
    height: 36px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.2s ease;
}

.comment-submit:hover:not(:disabled) {
    background-color: var(--primary-color-dark);
    transform: scale(1.05);
}

.comment-submit:disabled {
    background-color: var(--border-color);
    cursor: not-allowed;
    opacity: 0.7;
}

/* Post Menu Styles */
.post-menu {
    position: relative;
    margin-left: auto;
}

.post-menu-toggle {
    background: none;
    border: none;
    color: var(--text-secondary);
    padding: 4px 8px;
    cursor: pointer;
    border-radius: 4px;
}

.post-menu-toggle:hover {
    background-color: var(--bg-hover);
}

.post-dropdown-menu {
    position: absolute;
    top: 100%;
    right: 0;
    background-color: var(--bg-secondary);
    border: 1px solid var(--border-color);
    border-radius: 8px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
    min-width: 150px;
    z-index: 1000;
    display: none;
}

.post-dropdown-menu.active {
    display: block;
}

.post-dropdown-menu ul {
    list-style: none;
    margin: 0;
    padding: 5px 0;
}

.post-dropdown-menu li {
    padding: 8px 15px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
    color: var(--text-primary);
    transition: background-color 0.2s;
}

.post-dropdown-menu li:hover {
    background-color: var(--bg-hover);
}

.post-dropdown-menu li i {
    color: var(--text-secondary);
    width: 16px;
    text-align: center;
}

.modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5);
    z-index: 1000;
}

.modal-content {
    position: relative;
    background-color: var(--bg-color);
    margin: 15% auto;
    padding: 20px;
    border-radius: 8px;
    width: 80%;
    max-width: 500px;
}

.modal-header {
    margin-bottom: 20px;
}

.modal-footer {
    margin-top: 20px;
    text-align: right;
}

.modal-btn {
    padding: 8px 16px;
    margin-left: 10px;
    border-radius: 4px;
    cursor: pointer;
}

.modal-btn.cancel {
    background-color: var(--bg-color);
    color: var(--text-color);
    border: 1px solid var(--border-color);
}

.modal-btn.delete {
    background-color: #ff4444;
    color: white;
    border: none;
}

.modal-btn:hover {
    opacity: 0.8;
}

/* Add these styles for better comment functionality */
.comments-section {
    margin-top: 15px;
    padding-top: 15px;
    border-top: 1px solid var(--border-color);
}

.comments-container {
    max-height: 300px;
    overflow-y: auto;
    margin-bottom: 15px;
    padding-right: 10px;
}

.loading-comments {
    text-align: center;
    padding: 20px;
    color: var(--text-secondary);
}

.loading-comments i {
    margin-right: 8px;
    animation: spin 1s linear infinite;
}

.no-comments {
    text-align: center;
    padding: 20px;
    color: var(--text-secondary);
    font-style: italic;
}

.error {
    color: #ff4444;
    text-align: center;
    padding: 10px;
    margin: 10px 0;
    background-color: rgba(255, 68, 68, 0.1);
    border-radius: 8px;
}

.notification {
    position: fixed;
    bottom: 20px;
    right: 20px;
    padding: 12px 20px;
    border-radius: 8px;
    background-color: var(--bg-secondary);
    color: var(--text-primary);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    display: flex;
    align-items: center;
    gap: 10px;
    z-index: 1000;
    opacity: 0;
    transform: translateY(20px);
    transition: all 0.3s ease;
}

.notification.show {
    opacity: 1;
    transform: translateY(0);
}

.notification.fade-out {
    opacity: 0;
    transform: translateY(20px);
}

.notification i {
    font-size: 1.2em;
}

.notification.success {
    background-color: #4CAF50;
    color: white;
}

.notification.error {
    background-color: #f44336;
    color: white;
}

.notification.warning {
    background-color: #ff9800;
    color: white;
}

/* Scrollbar styling */
.comments-container::-webkit-scrollbar {
    width: 6px;
}

.comments-container::-webkit-scrollbar-track {
    background: var(--bg-secondary);
    border-radius: 3px;
}

.comments-container::-webkit-scrollbar-thumb {
    background: var(--primary-color);
    border-radius: 3px;
}

.comments-container::-webkit-scrollbar-thumb:hover {
    background: var(--primary-color-dark);
}

/* Add notification badge */
.notification-badge {
    position: absolute;
    top: -8px;
    right: -8px;
    background-color: #ff4b4b;
    color: white;
    font-size: 0.7rem;
    padding: 2px 6px;
    border-radius: 10px;
    font-weight: bold;
}

.report-btn {
    background: none;
    border: none;
    color: var(--text-secondary);
    cursor: pointer;
    padding: 5px 10px;
    font-size: 0.9em;
    transition: all 0.3s ease;
    opacity: 0.7;
}

.report-btn:hover {
    color: var(--danger-color);
    opacity: 1;
}

.post-actions, .comment-actions {
    display: flex;
    align-items: center;
    gap: 1rem;
    margin-top: 0.5rem;
}
</style>

<!-- Add this at the bottom of the body tag -->
<div id="deleteModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Delete Post</h3>
        </div>
        <p>Are you sure you want to delete this post? This action cannot be undone.</p>
        <div class="modal-footer">
            <button class="modal-btn cancel" onclick="closeDeleteModal()">Cancel</button>
            <button class="modal-btn delete" onclick="confirmDelete()">Delete</button>
        </div>
    </div>
</div>

<script>
document.querySelector('.nav-toggle').addEventListener('click', function() {
    document.querySelector('.nav-links').classList.toggle('active');
});

// Like/Unlike functionality
window.likePost = async function(postId) {
    if (!postId) {
        showNotification('Invalid post ID', 'error');
        return;
    }
    
    const likeBtn = document.querySelector(`[data-post-id="${postId}"] .like-btn`);
    if (!likeBtn) {
        showNotification('Like button not found', 'error');
        return;
    }
    
    const isLiked = likeBtn.classList.contains('liked');
    const action = isLiked ? 'unlike' : 'like';
    
    try {
        const response = await fetch(`api/likes.php?action=${action}&post_id=${postId}`);
        if (!response.ok) throw new Error('Failed to update like status');
        
                const data = await response.json();
        if (data.success) {
            // Toggle like button state
            likeBtn.classList.toggle('liked');
            const heartIcon = likeBtn.querySelector('i');
            heartIcon.classList.toggle('fas');
            heartIcon.classList.toggle('far');
            
            // Update like count
            const likeCount = likeBtn.querySelector('.like-count');
            likeCount.textContent = data.count;
            
            showNotification(`Post ${action}d successfully`, 'success');
        } else {
            throw new Error(data.message || `Failed to ${action} post`);
            }
        } catch (error) {
            console.error('Error:', error);
        showNotification(error.message, 'error');
    }
};

// Delete post functionality
let currentPostId = null;
const deleteModal = document.getElementById('deleteModal');

document.querySelectorAll('.delete-post-btn').forEach(button => {
    button.addEventListener('click', function() {
        currentPostId = this.dataset.postId;
        deleteModal.style.display = 'block';
    });
});

function closeDeleteModal() {
    deleteModal.style.display = 'none';
    currentPostId = null;
}

async function confirmDelete() {
    if (!currentPostId) return;
    
    try {
        const formData = new FormData();
        formData.append('post_id', currentPostId);
        
        const response = await fetch('api/delete_post.php', {
                    method: 'POST',
            body: formData
        });
        
            const data = await response.json();
                
                if (response.ok) {
            // Remove the post from the DOM
            const post = document.querySelector(`.post[data-post-id="${currentPostId}"]`);
            post.remove();
            closeDeleteModal();
        } else {
            alert(data.error || 'Failed to delete post');
                }
            } catch (error) {
                console.error('Error:', error);
        alert('An error occurred while deleting the post');
    }
}

// Close modal when clicking outside
window.addEventListener('click', function(event) {
    if (event.target === deleteModal) {
        closeDeleteModal();
    }
});

document.addEventListener('DOMContentLoaded', function() {
    // Create comment HTML helper function - Moved to top level scope
    window.createCommentHtml = function(comment) {
        if (!comment || typeof comment !== 'object') {
            console.error('Invalid comment object:', comment);
            return '';
        }

        const commentText = comment.comment || comment.content || '';
        const username = comment.username || 'Unknown User';
        const userId = comment.user_id || 0;
        const commentId = comment.id || 0;
        const postId = comment.post_id || 0;
        const profilePic = comment.profile_picture || 'assets/default-avatar.png';
        const createdAt = comment.created_at || 'just now';
        const canDelete = comment.can_delete || false;

        const escapedComment = commentText
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');

        return `
            <div class="comment" data-comment-id="${commentId}">
                <img src="${profilePic}" alt="${username}'s profile picture" class="comment-avatar">
                <div class="comment-content-wrapper">
                <div class="comment-header">
                        <a href="profile.php?id=${userId}" class="comment-username">${username}</a>
                        <span class="comment-time">${timeAgo(createdAt)}</span>
                    ${canDelete ? `
                        <button class="delete-comment" data-comment-id="${commentId}" data-post-id="${postId}">
                            <i class="fas fa-trash"></i>
                        </button>
                    ` : ''}
                        <div class="post-menu">
                            <button class="post-menu-toggle">
                                <i class="fas fa-ellipsis-v"></i>
                            </button>
                            <div class="post-dropdown-menu">
                                <ul>
                                    <li onclick="reportContent('comment', ${commentId}, ${userId})">
                                        <i class="fas fa-flag"></i> Report Comment
                                    </li>
                                </ul>
                            </div>
                        </div>
                </div>
                <div class="comment-content">${escapedComment}</div>
                </div>
            </div>
        `;
    };

    // Initialize comment functionality
    initializeComments();
});

// Initialize all comment-related functionality
function initializeComments() {
    // Auto-expand comment inputs
    document.querySelectorAll('.comment-input').forEach(input => {
        input.addEventListener('focus', function() {
            this.style.height = 'auto';
            this.style.height = (this.scrollHeight) + 'px';
        });
        
        input.addEventListener('input', function() {
            this.style.height = 'auto';
            this.style.height = (this.scrollHeight) + 'px';
        });
        
        input.addEventListener('blur', function() {
            if (!this.value.trim()) {
                this.style.height = '40px';
            }
        });
    });

    // Handle delete comment buttons
    document.addEventListener('click', function(e) {
        if (e.target.closest('.delete-comment')) {
            const button = e.target.closest('.delete-comment');
            const commentId = button.dataset.commentId;
            const postId = button.dataset.postId;
            if (commentId && postId) {
                deleteComment(commentId, postId);
            }
        }
    });
}

// Toggle comments section
window.toggleComments = async function(postId) {
    if (!postId) {
        console.error('No post ID provided');
        return;
    }

    const commentsSection = document.getElementById(`comments-${postId}`);
    const commentsContainer = document.getElementById(`comments-container-${postId}`);
    
    if (!commentsSection || !commentsContainer) {
        console.error('Comments section elements not found');
        return;
    }

    if (commentsSection.style.display === 'none' || commentsSection.style.display === '') {
        commentsSection.style.display = 'block';
        
        // Show loading indicator
        commentsContainer.innerHTML = '<div class="loading-comments"><i class="fas fa-spinner fa-spin"></i> Loading comments...</div>';
        
        try {
            const response = await fetch(`api/get_comments.php?post_id=${postId}`);
            
            // Check if the response is JSON
            const contentType = response.headers.get('content-type');
            if (!contentType || !contentType.includes('application/json')) {
                throw new Error('Server returned an invalid response. Please try again later.');
            }
            
            const data = await response.json();
            if (data.success) {
                if (!Array.isArray(data.comments) || data.comments.length === 0) {
                    commentsContainer.innerHTML = '<p class="no-comments">No comments yet. Be the first to comment!</p>';
                } else {
                    const commentsHtml = data.comments
                        .map(comment => createCommentHtml(comment))
                        .filter(html => html) // Remove any empty strings from failed comment creation
                        .join('');
                    commentsContainer.innerHTML = commentsHtml || '<p class="no-comments">No comments to display.</p>';
                }
            } else {
                throw new Error(data.message || 'Failed to load comments');
            }
        } catch (error) {
            console.error('Error loading comments:', error);
            commentsContainer.innerHTML = `<div class="error">An error occurred: ${error.message}</div>`;
        }
    } else {
        commentsSection.style.display = 'none';
    }
};

// Add comment
window.addComment = async function(postId) {
    if (!postId) {
        showNotification('Invalid post ID', 'error');
        return;
    }

    const commentInput = document.getElementById(`comment-input-${postId}`);
    if (!commentInput) {
        showNotification('Comment input not found', 'error');
        return;
    }

    const comment = commentInput.value.trim();
    if (!comment) {
        showNotification('Please enter a comment', 'warning');
        return;
    }
    
    const submitButton = document.querySelector(`#comments-${postId} .comment-submit`);
    if (!submitButton) {
        showNotification('Submit button not found', 'error');
        return;
    }

    submitButton.disabled = true;
    submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
    
    try {
        const formData = new FormData();
        formData.append('comment', comment);

        // Use URL parameter instead of FormData for post_id
        const response = await fetch(`api/comments.php?action=add&post_id=${postId}`, {
                method: 'POST',
            body: formData
        });
        
        // Check if the response is JSON
        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            throw new Error('Server returned an invalid response. Please try again later.');
        }
        
        const data = await response.json();
        if (data.success && data.comment) {
            // Clear input
            commentInput.value = '';
            commentInput.style.height = '40px';
            
            // Update comments container
            const commentsContainer = document.getElementById(`comments-container-${postId}`);
            if (commentsContainer) {
                const noCommentsMsg = commentsContainer.querySelector('.no-comments');
                if (noCommentsMsg) {
                    commentsContainer.innerHTML = '';
                }
                
                // Add new comment at the top
                const commentHtml = createCommentHtml(data.comment);
                if (commentHtml) {
                    commentsContainer.insertAdjacentHTML('afterbegin', commentHtml);
                }
                
                // Update comment count
                const commentCount = document.querySelector(`[data-post-id="${postId}"] .comment-count`);
                if (commentCount) {
                    commentCount.textContent = parseInt(commentCount.textContent || '0') + 1;
                }
                
                showNotification('Comment added successfully', 'success');
            }
                        } else {
            throw new Error(data.message || 'Failed to add comment');
            }
        } catch (error) {
        console.error('Error adding comment:', error);
        showNotification(error.message, 'error');
    } finally {
        if (submitButton) {
            submitButton.disabled = false;
            submitButton.innerHTML = '<i class="fas fa-paper-plane"></i>';
        }
    }
};

// Delete comment
window.deleteComment = async function(commentId, postId) {
    if (!commentId || !postId) {
        showNotification('Invalid comment or post ID', 'error');
        return;
    }

    if (!confirm('Are you sure you want to delete this comment?')) return;
    
    try {
        const response = await fetch(`api/comments.php?action=delete&comment_id=${commentId}&post_id=${postId}`);
        if (!response.ok) throw new Error('Failed to delete comment');
        
        const data = await response.json();
        if (data.success) {
            // Remove comment element
            const commentElement = document.querySelector(`[data-comment-id="${commentId}"]`);
            if (commentElement) {
                commentElement.remove();
            }
            
            // Update comment count
            const commentCount = document.querySelector(`[data-post-id="${postId}"] .comment-count`);
            if (commentCount) {
                const newCount = Math.max(0, parseInt(commentCount.textContent || '0') - 1);
                commentCount.textContent = newCount;
            }
            
            // Show no comments message if no comments left
            const commentsContainer = document.getElementById(`comments-container-${postId}`);
            if (commentsContainer && !commentsContainer.children.length) {
                commentsContainer.innerHTML = '<p class="no-comments">No comments yet. Be the first to comment!</p>';
            }
            
            showNotification('Comment deleted successfully', 'success');
        } else {
            throw new Error(data.message || 'Failed to delete comment');
                }
            } catch (error) {
        console.error('Error deleting comment:', error);
        showNotification(error.message, 'error');
    }
};

// Show notification
window.showNotification = function(message, type = 'info') {
    if (!message) return;

    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    
    const icon = document.createElement('i');
    switch (type) {
        case 'success': icon.className = 'fas fa-check-circle'; break;
        case 'error': icon.className = 'fas fa-exclamation-circle'; break;
        case 'warning': icon.className = 'fas fa-exclamation-triangle'; break;
        default: icon.className = 'fas fa-info-circle';
    }
    
    notification.appendChild(icon);
    notification.insertAdjacentText('beforeend', ` ${message}`);
    document.body.appendChild(notification);
    
    // Add show class after a small delay to trigger animation
    setTimeout(() => notification.classList.add('show'), 10);
    
    setTimeout(() => {
        notification.classList.add('fade-out');
        setTimeout(() => notification.remove(), 300);
    }, 3000);
};

// Helper function for time ago format
function timeAgo(timestamp) {
    const seconds = Math.floor((new Date() - new Date(timestamp)) / 1000);
    
    let interval = Math.floor(seconds / 31536000);
    if (interval > 1) return interval + ' years ago';
    
    interval = Math.floor(seconds / 2592000);
    if (interval > 1) return interval + ' months ago';
    
    interval = Math.floor(seconds / 86400);
    if (interval > 1) return interval + ' days ago';
    
    interval = Math.floor(seconds / 3600);
    if (interval > 1) return interval + ' hours ago';
    
    interval = Math.floor(seconds / 60);
    if (interval > 1) return interval + ' minutes ago';
    
    return 'just now';
}

// Add report functionality
window.reportContent = function(contentType, contentId, reportedId) {
    const reason = prompt('Please provide a reason for reporting this ' + contentType + ':');
    if (!reason) return;

    fetch('includes/report_handler.php', {
            method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `content_type=${contentType}&content_id=${contentId}&reported_id=${reportedId}&reason=${encodeURIComponent(reason)}`
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
        if (data.success) {
            // Optionally refresh the page or update UI
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred while submitting the report.');
    });
};

// Modify post template to include report option
document.addEventListener('DOMContentLoaded', function() {
    // Add CSS for report modal
    const style = document.createElement('style');
    style.textContent = `
        .report-modal {
            display: flex;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.7);
            align-items: center;
            justify-content: center;
        }
        
        .report-modal-content {
            background-color: var(--bg-secondary);
            margin: auto;
            padding: 20px;
            border-radius: 10px;
            width: 90%;
            max-width: 500px;
            position: relative;
            animation: modalAnimation 0.3s ease;
        }
        
        @keyframes modalAnimation {
            from {opacity: 0; transform: translateY(-20px);}
            to {opacity: 1; transform: translateY(0);}
        }
        
        .close-modal {
            color: var(--text-secondary);
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        
        .close-modal:hover {
            color: var(--accent-color);
        }
        
        .report-modal h2 {
            margin-top: 0;
            color: var(--text-primary);
        }
        
        .report-modal .form-group {
            margin-bottom: 15px;
        }
        
        .report-modal select, .report-modal textarea {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid var(--border-color);
            background-color: var(--bg-primary);
            color: var(--text-primary);
        }
        
        .submit-report {
            background-color: var(--accent-color);
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        
        .submit-report:hover {
            background-color: var(--accent-hover);
        }
        
        .post-dropdown-menu {
            position: absolute;
            top: 40px;
            right: 10px;
            background-color: var(--bg-secondary);
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
            z-index: 10;
            display: none;
        }
        
        .post-dropdown-menu.active {
            display: block;
        }
        
        .post-dropdown-menu ul {
            list-style: none;
            margin: 0;
            padding: 0;
        }
        
        .post-dropdown-menu li {
            padding: 10px 15px;
            cursor: pointer;
            transition: background-color 0.2s;
        }
        
        .post-dropdown-menu li:hover {
            background-color: var(--bg-tertiary);
        }
        
        .post-dropdown-menu li i {
            margin-right: 8px;
        }
        
        .post-actions .post-menu-toggle {
            background: none;
            border: none;
            color: var(--text-secondary);
            cursor: pointer;
            padding: 5px;
        }
        
        .comment-actions .comment-menu-toggle {
            background: none;
            border: none;
            color: var(--text-secondary);
            cursor: pointer;
            padding: 5px;
            margin-left: 10px;
        }
    `;
    document.head.appendChild(style);
    
    // Add dropdown toggles to posts
    document.querySelectorAll('.post').forEach(post => {
        const postId = post.dataset.postId;
        const postHeader = post.querySelector('.post-header');
        const postActions = post.querySelector('.post-actions');
        
        if (postActions) {
            // Create menu toggle button
            const menuToggle = document.createElement('button');
            menuToggle.className = 'post-menu-toggle';
            menuToggle.innerHTML = '<i class="fas fa-ellipsis-v"></i>';
            postActions.appendChild(menuToggle);
            
            // Create dropdown menu
            const dropdownMenu = document.createElement('div');
            dropdownMenu.className = 'post-dropdown-menu';
            dropdownMenu.innerHTML = `
                <ul>
                    <li onclick="reportContent('post', ${postId}, ${post.dataset.userId})"><i class="fas fa-flag"></i> Report Post</li>
                </ul>
            `;
            postHeader.appendChild(dropdownMenu);
            
            // Toggle menu on click
            menuToggle.addEventListener('click', function(e) {
                e.stopPropagation();
                dropdownMenu.classList.toggle('active');
            });
            
            // Close menu when clicking elsewhere
            document.addEventListener('click', function() {
                dropdownMenu.classList.remove('active');
            });
        }
    });
    
    // Add comment reporting functionality
    document.addEventListener('click', function(e) {
        if (e.target.closest('.comment-menu-toggle')) {
            e.preventDefault();
            e.stopPropagation();
            const toggle = e.target.closest('.comment-menu-toggle');
            const menu = toggle.nextElementSibling;
            if (menu) {
                menu.classList.toggle('active');
            }
        }
    });
});
</script>
</body>
</html>
