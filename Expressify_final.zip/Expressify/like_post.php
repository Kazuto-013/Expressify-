<?php
require 'session.php';
require 'config.php';
require 'functions.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$post_id = $data['post_id'];
$user_id = $_SESSION['user_id'];

try {
    $conn->begin_transaction();

    // Check if user already liked the post
    $stmt = $conn->prepare("SELECT id FROM likes WHERE user_id = ? AND post_id = ?");
    $stmt->bind_param("ii", $user_id, $post_id);
    $stmt->execute();
    $existing_like = $stmt->get_result()->fetch_assoc();

    // Get post author and user info for notification
    $stmt = $conn->prepare("
        SELECT p.user_id as post_author_id, u.username 
        FROM posts p 
        JOIN users u ON u.id = ? 
        WHERE p.id = ?
    ");
    $stmt->bind_param("ii", $user_id, $post_id);
    $stmt->execute();
    $info = $stmt->get_result()->fetch_assoc();

    if ($existing_like) {
        // Unlike
        $stmt = $conn->prepare("DELETE FROM likes WHERE user_id = ? AND post_id = ?");
        $stmt->bind_param("ii", $user_id, $post_id);
        $stmt->execute();
        $action = 'unlike';
    } else {
        // Like
        $stmt = $conn->prepare("INSERT INTO likes (user_id, post_id) VALUES (?, ?)");
        $stmt->bind_param("ii", $user_id, $post_id);
        $stmt->execute();
        
        // Create notification for the post author
        if ($info['post_author_id'] != $user_id) { // Don't notify if user likes their own post
            createNotification(
                $conn,
                $info['post_author_id'],
                'post_like',
                "{$info['username']} liked your post",
                $post_id
            );
        }
        $action = 'like';
    }

    // Get updated like count
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM likes WHERE post_id = ?");
    $stmt->bind_param("i", $post_id);
    $stmt->execute();
    $like_count = $stmt->get_result()->fetch_assoc()['count'];

    $conn->commit();
    echo json_encode([
        'success' => true,
        'action' => $action,
        'like_count' => $like_count
    ]);

} catch (Exception $e) {
    $conn->rollback();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

$conn->close();
?>