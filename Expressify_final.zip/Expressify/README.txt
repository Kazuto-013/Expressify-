
# Expressify Social Media Platform

## Features
- User registration and login (session-based)
- Post creation, likes, comments
- Profile and settings management
- Friend requests
- Admin panel
- Theme switching

## Deployment Instructions (WampServer)
1. Place the `expressify` folder in `www` directory of WampServer.
2. Create a MySQL database named `expressify`.
3. Import `expressify_schema.sql` and `expressify_seed.sql` into the database using phpMyAdmin.
4. Start Apache and MySQL from WampServer.
5. Visit `http://localhost/expressify` in your browser.

## Admin Access
Login with:
- Email: john@example.com
- Password: john123
(Only user ID 1 is considered admin)
