<?php
require 'session.php';
require 'config.php';
require 'theme.php';
require 'functions.php';

$user_id = $_SESSION['user_id'];

// Get unread notifications count
$stmt = $conn->prepare("SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$unread_count = $stmt->get_result()->fetch_assoc()['count'];

// Get all notifications with related user and post information
$stmt = $conn->prepare("
    SELECT 
        n.*,
        u.username,
        u.profile_picture,
        p.content as post_content,
        p.user_id as post_user_id
    FROM notifications n
    LEFT JOIN users u ON n.related_user_id = u.id
    LEFT JOIN posts p ON n.post_id = p.id
    WHERE n.user_id = ?
    ORDER BY n.created_at DESC
    LIMIT 50
");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$notifications = $stmt->get_result();

// Mark all as read
$stmt = $conn->prepare("UPDATE notifications SET is_read = 1 WHERE user_id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
?>

<!DOCTYPE html>
<html data-theme="<?php echo htmlspecialchars($current_theme); ?>">
<head>
    <title>Notifications - Expressify</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
<div class="container">
    <nav class="navbar">
        <div class="nav-brand">
            <h2>Expressify</h2>
        </div>
        <div class="nav-links">
            <a href="home.php" class="nav-item"><i class="fas fa-home"></i> Home</a>
            <a href="posts.php" class="nav-item"><i class="fas fa-pen"></i> Create Post</a>
            <a href="explore.php" class="nav-item"><i class="fas fa-compass"></i> Explore</a>
            <a href="notifications.php" class="nav-item active">
                <i class="fas fa-bell"></i> Notifications
                <?php if ($unread_count > 0): ?>
                    <span class="notification-badge"><?php echo $unread_count; ?></span>
                <?php endif; ?>
            </a>
            <a href="profile.php" class="nav-item"><i class="fas fa-user"></i> My Profile</a>
            <a href="friends.php" class="nav-item"><i class="fas fa-users"></i> Friends</a>
            <a href="settings.php" class="nav-item"><i class="fas fa-cog"></i> Settings</a>
            <a href="logout.php" class="nav-item"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
        <div class="nav-toggle">
            <i class="fas fa-bars"></i>
        </div>
    </nav>

    <div class="content">
        <div class="notifications-container">
            <h2><i class="fas fa-bell"></i> Notifications</h2>
            
            <?php if ($notifications->num_rows === 0): ?>
                <div class="no-notifications">
                    <i class="fas fa-bell-slash"></i>
                    <p>No notifications yet</p>
                </div>
            <?php else: ?>
                <div class="notifications-list">
                    <?php while ($notification = $notifications->fetch_assoc()): ?>
                        <div class="notification-item <?php echo $notification['is_read'] ? '' : 'unread'; ?>"
                             data-notification-id="<?php echo $notification['id']; ?>">
                            <div class="notification-avatar">
                                <img src="<?php echo !empty($notification['profile_picture']) ? 
                                    htmlspecialchars($notification['profile_picture']) : 
                                    'assets/default-avatar.png'; ?>" 
                                    alt="User avatar">
                            </div>
                            <div class="notification-content">
                                <p class="notification-text">
                                    <?php echo htmlspecialchars($notification['message']); ?>
                                </p>
                                <?php if (!empty($notification['post_content'])): ?>
                                    <div class="notification-preview">
                                        <?php echo htmlspecialchars(substr($notification['post_content'], 0, 100)) . '...'; ?>
                                    </div>
                                <?php endif; ?>
                                <span class="notification-time">
                                    <?php echo timeAgo($notification['created_at']); ?>
                                </span>
                            </div>
                            <?php if (!$notification['is_read']): ?>
                                <div class="notification-status"></div>
                            <?php endif; ?>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
document.querySelector('.nav-toggle').addEventListener('click', function() {
    document.querySelector('.nav-links').classList.toggle('active');
});

// WebSocket connection for real-time notifications
const ws = new WebSocket('ws://' + window.location.hostname + ':8080');

ws.onmessage = function(event) {
    const notification = JSON.parse(event.data);
    if (notification.user_id == <?php echo $user_id; ?>) {
        showNotificationPopup(notification);
        updateNotificationBadge(1);
    }
};

function showNotificationPopup(notification) {
    const popup = document.createElement('div');
    popup.className = 'notification-popup';
    popup.innerHTML = `
        <div class="notification-popup-content">
            <i class="fas fa-bell"></i>
            <p>${notification.message}</p>
        </div>
    `;
    document.body.appendChild(popup);
    
    setTimeout(() => {
        popup.classList.add('show');
        setTimeout(() => {
            popup.classList.remove('show');
            setTimeout(() => popup.remove(), 300);
        }, 5000);
    }, 100);
}

function updateNotificationBadge(count) {
    let badge = document.querySelector('.notification-badge');
    if (!badge && count > 0) {
        badge = document.createElement('span');
        badge.className = 'notification-badge';
        document.querySelector('.nav-item[href="notifications.php"] i').after(badge);
    }
    if (badge) {
        const currentCount = parseInt(badge.textContent || '0');
        badge.textContent = currentCount + count;
    }
}

// Helper function for time ago format
function timeAgo(timestamp) {
    const seconds = Math.floor((new Date() - new Date(timestamp)) / 1000);
    
    let interval = Math.floor(seconds / 31536000);
    if (interval > 1) return interval + ' years ago';
    
    interval = Math.floor(seconds / 2592000);
    if (interval > 1) return interval + ' months ago';
    
    interval = Math.floor(seconds / 86400);
    if (interval > 1) return interval + ' days ago';
    
    interval = Math.floor(seconds / 3600);
    if (interval > 1) return interval + ' hours ago';
    
    interval = Math.floor(seconds / 60);
    if (interval > 1) return interval + ' minutes ago';
    
    return 'just now';
}
</script>
</body>
</html>
